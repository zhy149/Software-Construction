package applications;

import centralobject.CentralObject;
import circularorbit.ConcreteCircularOrbit;
import org.apache.log4j.Logger;

import physicalobject.Electron;
import physicalobject.PhysicalObject;
import track.Track;

public class AtomStructure<L extends CentralObject, E extends PhysicalObject>
    extends ConcreteCircularOrbit<L, E> {

  
  /**
   * Check representation.
   */
  public void checkRep() {
    assert centralObject != null; // ��֤ԭ�Ӻ˲�Ϊ��

    for (Track track : orbitMap.keySet()) {
      assert track.getRadius() == orbitMap.get(track).get(0).getOrbitRadius();
      // ��֤ÿ�����ӵİ뾶�������ڹ���İ뾶
    }
  }

  /**
   * This function delete electron from source track and add electron to target track.
   */
  @SuppressWarnings("unchecked")
  public void transit(int sourceRadius, int targetRadius) {
    if (sourceRadius > 0 && targetRadius > 0 && sourceRadius <= orbitMap.size()
        && targetRadius <= orbitMap.size() && sourceRadius != targetRadius) {
      Track sourcTrack = null;
      Track tarTrack = null;
      int i = 0;
      for (Track track : orbitMap.keySet()) {
        i++;
        if (i == sourceRadius) {
          sourcTrack = track;
        }
        if (i == targetRadius) {
          tarTrack = track;
        }
      }
      if (sourcTrack != null && tarTrack != null && sourcTrack != tarTrack) {
        if (!orbitMap.get(sourcTrack).isEmpty()) {
          orbitMap.get(sourcTrack).remove(0);
          orbitMap.get(tarTrack).add((E) (new Electron(tarTrack.getRadius())));
          Logger logger = Logger.getLogger(AtomStructure.class);
          logger.info("eletron transic from radius:" + sourceRadius + " to radius:" + targetRadius);
        }
      }
    }
  }

  @Override
  public void refresh(double milisecond) {
    resetAngle();
  }

  @Override
  public void print() {
    if (centralObject != null) {
      System.out.println(centralObject.toString());
      System.out.println();
    }

    int count = 0;
    for (Track track : orbitMap.keySet()) {
      System.out.println(
          ++count + " " + track.toString() + " has " + orbitMap.get(track).size() + " electron.");
      System.out.println();
    }
  }

  public static void main(String[] args) {

  }

}
