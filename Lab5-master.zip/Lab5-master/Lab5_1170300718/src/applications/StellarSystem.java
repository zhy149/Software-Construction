package applications;

import centralobject.CentralObject;
import centralobject.Stellar;
import circularorbit.ConcreteCircularOrbit;

import parsers.StellarParser;
import physicalobject.PhysicalObject;
import physicalobject.Planet;
import track.Track;

public class StellarSystem<L extends CentralObject, E extends PhysicalObject>
    extends ConcreteCircularOrbit<L, E> {

  /**
   * check representation. 
   */
  public void checkRep() {
    assert centralObject != null; // ��֤�м����岻Ϊ��

    for (Track track : orbitMap.keySet()) {
      assert orbitMap.get(track).size() <= 1; // ��֤ÿһ����������ֻ��һ������
    }

    for (Track track : orbitMap.keySet()) {
      assert track.getRadius() == orbitMap.get(track).get(0).getRadius();
      // ��֤ÿ�����ǵİ뾶�������ڹ���İ뾶
    }

    assert this.getSurObjectNumber() == this.getSurNameSet().size();
    // ��֤û�������ظ�������

  }
  
  
  public void outPut() {
    
    if(centralObject != null) {
      
    }
  }


  /**
   * Main.
   */
  public static void main(String[] args) {
    try {
      StellarSystem<Stellar, Planet> stellarSystem = StellarParser.parse(
          "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
          + "\\src\\txt\\StellarSystem.txt");
      stellarSystem.checkRep();
    } catch (Exception e) {
      e.printStackTrace();
    }

  }

}
