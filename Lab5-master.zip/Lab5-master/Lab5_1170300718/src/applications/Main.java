package applications;

import apis.AtomPanel;
import apis.CircularorbitApis;
import apis.SocialNetworkPanel;
import apis.StellarSystemPanel;
import centralobject.Nucleus;
import centralobject.Person;
import centralobject.Stellar;
import java.awt.Dimension;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.apache.log4j.Logger;

import parsers.AtomParser;
import parsers.SocialNetworkParser;
import parsers.StellarParser;
import physicalobject.Electron;
import physicalobject.Planet;
import track.Track;

public class Main {
  private void print(String content) {
    System.out.println(content);
  }

  /**
   * This function paint the stellar system. 
   * 
   */
  public void stellarVisualize(StellarSystem<Stellar, Planet> stellarSystem) {
    StellarSystemPanel stellarSystemPanel = new StellarSystemPanel(stellarSystem);
    JFrame myFrame = new JFrame();
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    stellarSystemPanel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(stellarSystemPanel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);

    new Thread(new Runnable() {
      @Override
      public void run() {
        while (true) {
          stellarSystemPanel.refresh(1);
          stellarSystemPanel.repaint();
          try {
            Thread.sleep(100);
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      }
    }).start();
  }
  
  
  
  /**
   * Generate a menu to operate stellar system.
   */
  public void stellarSystemMenu() {
    StellarSystem<Stellar, Planet> stellarSystem;
    Logger logger = Logger.getLogger(StellarSystem.class);

    @SuppressWarnings("resource")
    Scanner inputScnScanner = new Scanner(System.in);
    print("Choose one to generate: 1,Normal 2,Medium 3,Large 4,Custom");
    try {
      switch (inputScnScanner.nextLine()) {
        case "1":
          stellarSystem = StellarParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
                  +  "\\src\\txt\\StellarSystem.txt");
          break;
        case "2":
          stellarSystem = StellarParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211" 
          + "\\src\\txt\\StellarSystem_Medium.txt");
          break;
        case "3":
          System.out.println("wait");
          String temp = inputScnScanner.nextLine();
          stellarSystem = StellarParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\StellarSystem_Larger.txt");
          break;
        case "4":
          print("Input the path of the input file");
          stellarSystem = StellarParser.parse(inputScnScanner.nextLine());
          break;
        default:
          stellarSystem = StellarParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\StellarSystem.txt");
          break;
      }
    } catch (Exception e) {
      print(e.toString());
      return;
    }

    while (true) {
      print(
          "choose function to perform: 1,add oribt 2,add subject 3,delete subject 4,delete orbit "
          + "5,calculate entropy 6,print information 7,get change by time 8,visualize 9,quit");
      switch (inputScnScanner.nextLine()) {
        case "1":
          print("input the radius of track");
          double radius = Double.parseDouble(inputScnScanner.nextLine());
          if (radius > 0) {
            stellarSystem.addOrbit(new Track(radius));
            print("Track with " + radius + " successfully added.");
          }
          break;
        case "2":
          String name;
          print("input the name of the planet");
          name = inputScnScanner.nextLine();
          print("input the radius of the planet");
          radius = Double.parseDouble(inputScnScanner.nextLine());
          stellarSystem.addSurObject(new Planet(name, "solic", "blue", 1, radius, 100, true, 0));
          print("Planet with " + radius + " successfully added.");
          break;
        case "3":
          print("input the name of planet to delete");
          name = inputScnScanner.nextLine();
          stellarSystem.deleteSurObjectByName(name);
          break;
        case "4":
          print("input the radius of track you want to delete");
          radius = Double.parseDouble(inputScnScanner.nextLine());
          stellarSystem.deleteOrbitByRadius(radius);
          break;
        case "5":
          print("the entropy is " + CircularorbitApis.getDistributionEntropy(stellarSystem));
          logger.info("calculate entropy, equals to:"
              + CircularorbitApis.getDistributionEntropy(stellarSystem));
          break;
        case "6":
          stellarSystem.print();
          logger.info("print system information");
          break;
        case "7":
          print("input the time offset");
          double milisecond = Double.parseDouble(inputScnScanner.nextLine());
          if (milisecond > 0) {
            stellarSystem.refresh(milisecond);
          }
          logger.info("calculate the angle of planets after " + milisecond + " seconds");
          break;
        case "8":
          stellarVisualize(stellarSystem);
          logger.info("visualize the system");
          break;
        case "9":
          return;
        default:
          break;
      }
      print("");
    }
  }

  /**
   * This function paint the given Atom Structure. 
   */
  public void atomVisualize(AtomStructure<Nucleus, Electron> atomStructure) {
    AtomPanel atomPanel = new AtomPanel(atomStructure);
    JFrame myFrame = new JFrame();
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    atomPanel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(atomPanel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);

    atomPanel.refresh(0);
    atomPanel.repaint();
  }
  
  /**
   * Generate a menu to manipulate atom structure.
   */
  public void atomMenu() {
    AtomStructure<Nucleus, Electron> atomStructure;
    Logger logger = Logger.getLogger(AtomStructure.class);

    @SuppressWarnings("resource")
    Scanner inputScnScanner = new Scanner(System.in);
    print("Choose one to generate: 1,Normal 2,Medium 3,Custom");
    try {
      switch (inputScnScanner.nextLine()) {
        case "1":
          atomStructure = AtomParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\AtomicStructure.txt");
          break;
        case "2":
          atomStructure = AtomParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\AtomicStructure_Medium.txt");
          break;
        case "3":
          print("Input the path of the input file");
          atomStructure = AtomParser.parse(inputScnScanner.nextLine());
          break;
        default:
          atomStructure = AtomParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\AtomicStructure.txt");
          break;
      }
    } catch (Exception e) {
      print(e.toString());
      return;
    }

    while (true) {
      print(
          "choose function to perform: 1,transic electron 2,print information 3,visualize 4,quit");
      switch (inputScnScanner.nextLine()) {
        case "1":
          print("input the radius of sorce electron track");
          int sourceRadius = Integer.parseInt(inputScnScanner.nextLine());
          print("input the radius of target electron track");
          int targetRadius = Integer.parseInt(inputScnScanner.nextLine());
          atomStructure.transit(sourceRadius, targetRadius);
          break;
        case "2":
          atomStructure.print();
  
          logger.info("print system information");
          break;
        case "3":
          atomVisualize(atomStructure);
          logger.info("visualize system");
          break;
        case "4":
          return;
        default:
          break;
      }
      print("");
    }
  }

  /**
   * Paint the given social network circle. 
   */
  public void socialNetworkVisualize(SocialNetworkCircle<Person, Person> networkCircle) {
    JFrame myFrame = new JFrame();
    SocialNetworkPanel myPenel = new SocialNetworkPanel(networkCircle);
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    myPenel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(myPenel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);
    myPenel.refresh(0);
    myPenel.repaint();
  }

  /**
   * Generate a menu to manipulate social network circle.
   */
  public void socialNetworkMenu() {
    SocialNetworkCircle<Person, Person> socialNetworkCircle;
    Logger logger = Logger.getLogger(SocialNetworkCircle.class);

    @SuppressWarnings("resource")
    Scanner inputScnScanner = new Scanner(System.in);
    print("Choose one to generate: 1,Normal 2,Medium 3,Large 4,Custom");
    try {
      switch (inputScnScanner.nextLine()) {
        case "1":
          socialNetworkCircle = SocialNetworkParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\SocialNetworkCircle.txt");
          break;
        case "2":
          socialNetworkCircle = SocialNetworkParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\SocialNetworkCircle_Medium.txt");
          break;
        case "3":
          socialNetworkCircle = SocialNetworkParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\SocialNetworkCircle_Larger.txt");
          break;
        case "4":
          print("Input the path of the input file");
          socialNetworkCircle = SocialNetworkParser.parse(inputScnScanner.nextLine());
          break;
        default:
          socialNetworkCircle = SocialNetworkParser.parse(
              "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211"
              + "\\src\\txt\\SocialNetworkCircle.txt");
          break;
      }
    } catch (Exception e) {
      print(e.toString());
      return;
    }

    while (true) {
      print(
          "choose function to perform: 1,add person 2,delete person 3,set relation "
          + "4,delete relation 5,calculate entropy 6,print information 7,refresh orbitSystem "
          + "8,visualize 9,quit");
      switch (inputScnScanner.nextLine()) {
        case "1":
          print("input the name of person");
          String name = inputScnScanner.nextLine();
          socialNetworkCircle.addPerson(name);
          logger.info("add person:" + name);
          break;
        case "2":
          print("input the name of person");
          name = inputScnScanner.nextLine();
          socialNetworkCircle.deletePerson(name);
          logger.info("delete person:" + name);
          break;
        case "3":
          print("input the name and weight of relation to set");
          String sourceName = inputScnScanner.nextLine();
          String targetName = inputScnScanner.nextLine();
          double weight = Double.parseDouble(inputScnScanner.nextLine());
          socialNetworkCircle.setRelationship(sourceName, targetName, weight);
          logger.info("set relation with " + sourceName
              + " and " + targetName + ", weight equals to:"
              + weight);
          break;
        case "4":
          print("input the name of relation to delete");
          sourceName = inputScnScanner.nextLine();
          targetName = inputScnScanner.nextLine();
          socialNetworkCircle.deleteRelationship(sourceName, targetName);
          logger.info("delete relation with " + sourceName + " and " + targetName);
          break;
        case "5":
          print("the entropy is " + CircularorbitApis.getDistributionEntropy(socialNetworkCircle));
          logger.info("calculate entropy, equals to:"
              + CircularorbitApis.getDistributionEntropy(socialNetworkCircle));
          break;
        case "6":
          socialNetworkCircle.print();
          logger.info("print system information");
          break;
        case "7":
          socialNetworkCircle.refresh(0);
          logger.info("refresh system");
          break;
        case "8":
          socialNetworkVisualize(socialNetworkCircle);
          logger.info("visualize system");
          break;
        case "9":
          return;
        default:
          break;
      }
      print("");
    }
  }
  
  /**
   * Entrance of whole application. 
   */
  public static void main(String[] args) {
    Main menu = new Main();
    @SuppressWarnings("resource")
    Scanner inputScanner = new Scanner(System.in);
    while (true) {
      System.out.println(
          "Choose one game to play:\n1,StellarSystem 2,AtomStructure 3,SocialNetworkCircle 4,quit");
      switch (inputScanner.nextLine()) {
        case "1":
          menu.stellarSystemMenu();
          break;
  
        case "2":
          menu.atomMenu();
          break;
  
        case "3":
          menu.socialNetworkMenu();
          break;
  
        case "4":
          return;
  
        default:
          break;
      }
    }
  }
}
