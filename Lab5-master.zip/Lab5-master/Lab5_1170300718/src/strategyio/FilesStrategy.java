package strategyio;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class FilesStrategy implements IoStrategy {

  @Override
  public void doIO(File in, File out) {
    try {
      if(in.exists()) {
        out.createNewFile();
        
        List<String> stringList = new ArrayList<String>();
        long start;
        long end;
        
        start = System.currentTimeMillis();
        byte[] content = Files.readAllBytes(Paths.get(in.getPath()));
        end = System.currentTimeMillis();
        System.out.println("Input time is:" + (end - start) + " miliseconds");
        
        start = System.currentTimeMillis();
        Files.write(Paths.get(out.getPath()), content, StandardOpenOption.CREATE);
        end = System.currentTimeMillis();
        System.out.println("Output time is:" + (end - start) + " miliseconds");
        
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
