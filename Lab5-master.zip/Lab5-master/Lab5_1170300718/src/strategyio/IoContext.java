package strategyio;

import java.io.File;


public class IoContext {
  private IoStrategy strategy;
  
  public IoContext(IoStrategy strategy) {
    this.strategy = strategy;
  }
  
  public void setStrategy(IoStrategy strategy) {
    this.strategy = strategy;
  }
  
  public void doIO(File in, File out){
    strategy.doIO(in, out);
  }
  
  public static void main(String[] args) {
    // Reader/Writer Strategy
    System.out.println("Reader/Writer Strategy");
    IoContext context;
    context = new IoContext(new ReaderWriterStrategy());
    context.doIO(new File("text//SocialNetworkCircle.txt"), new File("text//output.txt"));
    context.doIO(new File("text//StellarSystem.txt"), new File("text//output.txt"));
    System.out.println();
    
    //nio Files Strategy
    System.out.println("nio.file.Files Strategy");
    context = new IoContext(new FilesStrategy());
    context.doIO(new File("text//SocialNetworkCircle.txt"), new File("text//output.txt"));
    context.doIO(new File("text//StellarSystem.txt"), new File("text//output.txt"));
    System.out.println();
    
    //Stream Files Strategy
    System.out.println("Stream Strategy");
    context = new IoContext(new StreamStrategy());
    context.doIO(new File("text//SocialNetworkCircle.txt"), new File("text//output.txt"));
    context.doIO(new File("text//StellarSystem.txt"), new File("text//output.txt"));
    System.out.println();
    
  }

}
