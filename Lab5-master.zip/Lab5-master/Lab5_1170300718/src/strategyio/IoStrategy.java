package strategyio;

import java.io.File;

public interface IoStrategy {
  public void doIO(File in, File out);
}
