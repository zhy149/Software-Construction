package strategyio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class StreamStrategy implements IoStrategy {

  @Override
  public void doIO(File in, File out) {
    try {
      if(in.exists()) {
        out.createNewFile();
        
        List<String> stringList = new ArrayList<String>();
        long start;
        long end;
        int ch;
        byte[] bytes = new byte[1024];
        ArrayList<byte[]> list = new ArrayList<>();
        
        start = System.currentTimeMillis();
        FileInputStream fis = new FileInputStream(in);
        while((ch=fis.read(bytes)) != -1) {
          list.add(bytes);
        }
        end = System.currentTimeMillis();
        System.out.println("Input time is:" + (end - start) + " miliseconds");
        
        start = System.currentTimeMillis();
        FileOutputStream fos = new FileOutputStream(out);
        for(byte[] temp : list) {
          fos.write(temp);
        }
        end = System.currentTimeMillis();
        System.out.println("Output time is:" + (end - start) + " miliseconds");
        
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

  }

}
