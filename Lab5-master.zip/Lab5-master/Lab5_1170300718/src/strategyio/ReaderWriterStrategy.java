package strategyio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;


public class ReaderWriterStrategy implements IoStrategy {

  
  
  @Override
  public void doIO(File in, File out) {
    try {
      if(in.exists()) {
        FileReader fileReader = new FileReader(in);
        BufferedReader reader = new BufferedReader(fileReader);
        ArrayList<String> content = new ArrayList<>();
        long start;
        long end;
        start = System.currentTimeMillis();
        String temp;
        while((temp = reader.readLine()) != null) {
          content.add(temp);
        }
        end = System.currentTimeMillis();
        System.out.println("Input time is:" + (end - start) + " miliseconds");
        
        out.createNewFile();
        FileWriter fileWriter = new FileWriter(out);
        BufferedWriter writer = new BufferedWriter(fileWriter);
        start = System.currentTimeMillis();
        for(String s : content) {
          writer.write(s + "\n");
        }
        end = System.currentTimeMillis();
        System.out.println("Output time is:" + (end - start) + " miliseconds");
        
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }



}
