package exception;

public class DuplicateElementException extends Exception {
  public DuplicateElementException(String msg) {
    super(msg);
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
