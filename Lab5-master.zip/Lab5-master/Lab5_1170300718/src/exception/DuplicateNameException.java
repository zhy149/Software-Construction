package exception;

public class DuplicateNameException extends Exception {
  public DuplicateNameException(String msg) {
    super(msg);
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
