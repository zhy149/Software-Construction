package exception;

public class DuplicateCentralObjectException extends Exception {
  public DuplicateCentralObjectException(String msg) {
    super(msg);
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
