package relation;

public class Relation<S, T> {

  S source;
  T target;
  double number;

  public Relation(S source, T target, double number) {
    this.source = source;
    this.target = target;
    this.number = number;
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
