package otherdirectory;

public class Edge<L> {
  private L source;
  private L target;
  private double weight;

  // Abstraction function:
  // TODO
  // Representation invariant:
  // TODO
  // Safety from rep exposure:
  // TODO

  // TODO constructor
  public Edge(L source, L target, double weight) {
    this.source = source;
    this.target = target;
    this.weight = weight;
  }

  // TODO checkRep

  // TODO methods
  public L getSource() {
    return source;
  }

  public L getTarget() {
    return target;
  }

  public double getWeight() {
    return weight;
  }

  public void setWeight(double weight) {
    this.weight = weight;
  }

  // TODO toString()
  @Override
  public String toString() {
    return "source:" + source + " target:" + target + " weight: " + weight;
  }
}
