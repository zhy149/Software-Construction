package track;

public class Track implements Comparable<Track> {
  double radius;

  public Track(double radius) {
    this.radius = radius;

  }

  @Override
  public String toString() {
    return "track radius: " + this.radius;
  }

  public double getRadius() {
    return radius;
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

  @Override
  public int compareTo(Track o) {
    if (this.radius < o.radius) {
      return -1;
    } else if (this.radius > o.radius) {
      return 1;
    } else {
      return 0;
    }
  }

}
