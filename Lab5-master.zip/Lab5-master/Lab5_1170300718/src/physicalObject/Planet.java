package physicalobject;

public class Planet implements PhysicalObject {
  String name;
  String state;
  String color;
  double planetRadius;
  double orbitRadius;
  double angVelocity;
  boolean rotSense;
  double initAngle;
  double curAngle;

  @Override
  public void setCurAngle(double curAngle) {
    this.curAngle = curAngle % 360;
  }

  @Override
  public double getCurAngle() {
    return curAngle;
  }

  @Override
  public double getNextAngle(double milisecond) {
    return (curAngle + ((rotSense == true) ? -1 : 1) * angVelocity * milisecond / 1000) % 360;
  }

  @Override
  public void setNextAngle(double milisecond) {
    curAngle = (curAngle + ((rotSense == true) ? -1 : 1) * angVelocity * milisecond / 1000) % 360;
  }

  public Planet(String name, String state, String color, double planetRadius, double orbitRadius,
      double angVelocity, boolean rotSense, double initAngle) {
    this.name = name;
    this.state = state;
    this.color = color;
    this.planetRadius = planetRadius;
    this.orbitRadius = orbitRadius;
    this.angVelocity = angVelocity;
    this.rotSense = rotSense;
    this.initAngle = initAngle;
    this.curAngle = initAngle;
  }

  public double getOrbitRadius() {
    return this.orbitRadius;
  }

  @Override
  public String toString() {
    return this.name + " " + state + " " + color + " " + planetRadius + " " + orbitRadius + " "
        + angVelocity + " " + rotSense + " " + initAngle + " " + curAngle;
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public void setOrbitRadius(double radius) {
    this.orbitRadius = radius;

  }

  @Override
  public double getRadius() {
    return planetRadius;
  }

  @Override
  public void setRadius(double radius) {
    this.planetRadius = radius;
  }

}
