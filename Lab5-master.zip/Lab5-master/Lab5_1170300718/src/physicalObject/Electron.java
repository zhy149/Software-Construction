package physicalobject;

public class Electron implements PhysicalObject {
  double orbitRadius;
  double curAngle;

  public Electron(double orbitRadius) {
    super();
    this.orbitRadius = orbitRadius;
  }

  public Electron(double orbitRadius, double curAngle) {
    this.orbitRadius = orbitRadius;
    this.curAngle = curAngle;
  }

  @Override
  public void setCurAngle(double curAngel) {
    this.curAngle = curAngel;
  }

  @Override
  public double getCurAngle() {
    return curAngle;
  }

  @Override
  public double getOrbitRadius() {
    return this.orbitRadius;
  }

  public void setOrbitRadius(double orbitRadius) {
    this.orbitRadius = orbitRadius;
  }

  @Override
  public String toString() {
    return orbitRadius + " " + curAngle;
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

  @Override
  public void setNextAngle(double milisecond) {
  }

  @Override
  public double getNextAngle(double milisecond) {
    return 0;
  }

  @Override
  public String getName() {
    return "Electron";
  }

  @Override
  public double getRadius() {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public void setRadius(double radius) {
    // TODO Auto-generated method stub

  }

}
