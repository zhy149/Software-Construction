package centralobject;

public interface CentralObject {
}
