package centralobject;

public class Stellar implements CentralObject {
  String name;
  double radius;
  double mass;

  /**
   * Constructs a stellar with given information.
   */
  public Stellar(String name, double radius, double mass) {
    super();
    this.name = name;
    this.radius = radius;
    this.mass = mass;
  }

  @Override
  public String toString() {
    return name + " " + radius + " " + mass;
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
