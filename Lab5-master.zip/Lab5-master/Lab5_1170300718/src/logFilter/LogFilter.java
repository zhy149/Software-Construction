package logfilter;

import java.awt.desktop.SystemEventListener;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.scene.chart.PieChart.Data;
import parsers.Parser;

public class LogFilter {
  private Date startDate;
  private Date endDate;
  boolean filtDate;

  private String methodString;
  boolean filtMethod;

  private String classString;
  boolean filtClass;

  private String logString;
  boolean filtLog;

  private static String logRegex = "^(.*?),\\d*-\\[TS\\]\\s(\\w*)\\s\\w*\\s([\\w.]*)\\s-\\s(.*)$";
  private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  
  /**
   * Generate log filter.
   */
  public LogFilter() {
    filtDate = false;
    filtMethod = false;
    filtClass = false;
    filtLog = false;
  }

  private void setDate(String startDateString, String endDateString) {
    try {
      this.startDate = simpleDateFormat.parse(startDateString);
      this.endDate = simpleDateFormat.parse(endDateString);
      filtDate = true;
    } catch (ParseException e) {
      System.out.println("Wrong date format.");
      filtDate = false;
    }
  }

  private void setMethod(String methodString) {
    if (!methodString.isEmpty()) {
      this.methodString = methodString;
      filtMethod = true;
    } else {
      filtMethod = false;
    }
  }

  private void setClass(String classString) {
    if (!classString.isEmpty()) {
      this.classString = classString;
      filtClass = true;
    } else {
      filtClass = false;
    }
  }

  private void setLog(String logString) {
    if (!logString.isEmpty()) {
      this.logString = logString;
      filtLog = true;
    } else {
      filtLog = false;
    }
  }

  private void clearFiltSet() {
    filtDate = false;
    filtMethod = false;
    filtClass = false;
    filtLog = false;
  }

  public void printLog() throws IOException, ParseException {
    String content = Parser.getContent("target//test.log.2019-05-22");
    Pattern pattern = Pattern.compile(logRegex, Pattern.MULTILINE);
    Matcher matcher = pattern.matcher(content);
    String tempString;
    while (matcher.find()) {
      tempString = matcher.group(0);
      if (filtDate) {
        Date date = simpleDateFormat.parse(matcher.group(1));
        if (!date.after(startDate) || !date.before(endDate)) {
          continue;
        }

      }
      if (filtMethod) {
        if (!matcher.group(4).contains(methodString)) {
          continue;
        }
      }
      if (filtClass) {
        if (!matcher.group(3).contains(classString)) {
          continue;
        }
      }
      if (filtLog) {
        if (!matcher.group(2).contains(logString)) {
          continue;
        }
      }
      System.out.println(matcher.group(0));
    }
  }

  public static void main(String[] args) throws IOException, ParseException {
    LogFilter logFilter = new LogFilter();
    Scanner inputScanner = new Scanner(System.in);
    while (true) {
      System.out.println(
          "Choose function to perform: 1,Set Date 2,Set Method 3,Set Class 4,Set Log 5,Clear Set 6,Print Log 7,quit");
      switch (inputScanner.nextLine()) {
        case "1":
          System.out.println("Input start Date and end Date: (yyyy-MM-dd HH:mm:ss)");
          logFilter.setDate(inputScanner.nextLine(), inputScanner.nextLine());
          break;
        case "2":
          System.out.println("Input the method name");
          logFilter.setMethod(inputScanner.nextLine());
          break;
        case "3":
          System.out.println("Input the class name");
          logFilter.setClass(inputScanner.nextLine());
          break;
        case "4":
          System.out.println("Input the log type");
          logFilter.setLog(inputScanner.nextLine());
          break;
        case "5":
          logFilter.clearFiltSet();
          break;
        case "6":
          logFilter.printLog();
          break;
        case "7":
          return;
        default:
          break;
      }
    }

  }

}
