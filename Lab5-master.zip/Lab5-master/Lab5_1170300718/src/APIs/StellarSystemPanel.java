package apis;

import applications.StellarSystem;
import centralobject.Stellar;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JPanel;

import parsers.StellarParser;
import physicalobject.Planet;
import track.Track;

public class StellarSystemPanel extends JPanel {
  private StellarSystem<Stellar, Planet> stellarSystem;
  private int orbitDistance = 10;

  public void setOrbitDistance(int distance) {
    this.orbitDistance = distance;
  }

  public StellarSystemPanel(StellarSystem<Stellar, Planet> stellarSystem) {
    this.stellarSystem = stellarSystem;
  }

  public void refresh(double milisecond) {
    stellarSystem.refresh(milisecond);
  }

  private void paintOrbit(int orbitNumber, Graphics g) {
    g.setColor(Color.black);
    for (int i = 0; i < orbitNumber; i++) {
      g.drawOval(i * orbitDistance, i * orbitDistance, 2 * orbitDistance * (orbitNumber - i),
          2 * orbitDistance * (orbitNumber - i));
    }
  }

  private void paintStellar(int orbitNumber, Graphics g) {
    g.setColor(Color.red);
    g.fillOval(orbitNumber * orbitDistance - (int) (orbitDistance / 2),
        orbitNumber * orbitDistance - (int) (orbitDistance / 2), orbitDistance, orbitDistance);
  }

  private void paintPlanet(int orbitNumer, int orbitIndex, double angle, Graphics g) {
    int x = orbitNumer * orbitDistance
        + (int) (orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 4);
    int y = orbitNumer * orbitDistance
        + (int) (-orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI) - orbitDistance / 4);
    int planetDiameter = (int) (orbitDistance / 2);
    g.setColor(Color.blue);
    g.fillOval(x, y, planetDiameter, planetDiameter);
  }

  private void paintSystem(StellarSystem<Stellar, Planet> stellarSystem, Graphics g) {
    int orbitNumber = stellarSystem.getOrbitNumber();
    TreeMap<Track, ArrayList<Planet>> treeMap = stellarSystem.getOrbitMap();

    paintStellar(orbitNumber, g);
    paintOrbit(orbitNumber, g);
    int i = 0;
    for (Track track : treeMap.keySet()) {
      ++i;
      for (Planet planet : treeMap.get(track)) {
        paintPlanet(orbitNumber, i, planet.getCurAngle(), g);
      }
    }
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    paintSystem(stellarSystem, g);
  }

  public static void main(String[] args) {
  }

}
