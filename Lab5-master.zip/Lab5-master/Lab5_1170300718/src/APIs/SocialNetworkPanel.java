package apis;

import applications.SocialNetworkCircle;
import centralobject.Person;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JPanel;
import otherdirectory.Edge;
import track.Track;

public class SocialNetworkPanel extends JPanel {

  private SocialNetworkCircle<Person, Person> networkCircle;
  private int orbitDistance = 100;

  public SocialNetworkPanel(SocialNetworkCircle<Person, Person> networkCircle) {
    this.networkCircle = networkCircle;
  }

  public void refresh(double milisecond) {
    networkCircle.refresh(milisecond);
  }

  private void paintOrbit(int orbitNumber, Graphics g) {
    g.setColor(Color.black);
    for (int i = 0; i < orbitNumber; i++) {
      g.drawOval(i * orbitDistance, i * orbitDistance, 2 * orbitDistance * (orbitNumber - i),
          2 * orbitDistance * (orbitNumber - i));
    }
  }

  private int getXPosition(int orbitNumber, Person person) {
    if (person.equals(networkCircle.centralObject)) {
      return orbitNumber * orbitDistance;
    } else {
      return (int) (orbitNumber * orbitDistance + orbitDistance * person.getOrbitRadius()
          * Math.cos(person.getCurAngle() * Math.PI / 180));
    }
  }

  private int getYPosition(int orbitNumber, Person person) {
    if (person.equals(networkCircle.centralObject)) {
      return orbitNumber * orbitDistance;
    } else {
      return (int) (orbitNumber * orbitDistance - orbitDistance * person.getOrbitRadius()
          * Math.sin(person.getCurAngle() * Math.PI / 180));
    }
  }

  private void paintRelation(int orbitNumber, Graphics g) {
    g.setColor(Color.red);
    for (Edge edge : networkCircle.graph.getEdges()) {
      if (networkCircle.containPerson((Person) edge.getSource())
          && networkCircle.containPerson((Person) edge.getTarget())) {
        g.drawLine(getXPosition(orbitNumber, (Person) edge.getSource()),
            getYPosition(orbitNumber, (Person) edge.getSource()),
            getXPosition(orbitNumber, (Person) edge.getTarget()),
            getYPosition(orbitNumber, (Person) edge.getTarget()));
      }

    }
  }

  private void paintStellar(int orbitNumber, Graphics g) {
    g.setColor(Color.gray);
    g.fillOval(orbitNumber * orbitDistance - (int) (orbitDistance / 4),
        orbitNumber * orbitDistance - (int) (orbitDistance / 4), orbitDistance / 2,
        orbitDistance / 2);
  }

  private void paintPlanet(int orbitNumer, int orbitIndex, double angle, Graphics g) {
    int x = orbitNumer * orbitDistance
        + (int) (orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 20);
    int y = orbitNumer * orbitDistance
        + (int) (-orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI)
            - orbitDistance / 20);
    int planetDiameter = (int) (orbitDistance / 10);
    g.setColor(Color.blue);
    g.fillOval(x, y, planetDiameter, planetDiameter);
  }

  private void paintSystem(SocialNetworkCircle<Person, Person> networkCircle, Graphics g) {
    int orbitNumber = networkCircle.getOrbitNumber();
    TreeMap<Track, ArrayList<Person>> treeMap = networkCircle.getOrbitMap();

    paintStellar(orbitNumber, g);
    paintOrbit(orbitNumber, g);
    int i = 0;
    for (Track track : treeMap.keySet()) {
      ++i;
      for (Person person : treeMap.get(track)) {
        paintPlanet(orbitNumber, i, person.getCurAngle(), g);
      }
    }
    paintRelation(orbitNumber, g);
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(Color.gray);
    paintSystem(networkCircle, g);

  }

}
