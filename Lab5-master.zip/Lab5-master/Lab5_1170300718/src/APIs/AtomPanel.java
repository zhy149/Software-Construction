package apis;

import applications.AtomStructure;
import centralobject.Nucleus;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JPanel;
import physicalobject.Electron;
import track.Track;

public class AtomPanel extends JPanel {
  private AtomStructure<Nucleus, Electron> atomStructure;
  private static int orbitDistance = 40;
  private static double timeOffSet = 10;

  public AtomPanel(AtomStructure<Nucleus, Electron> atomStructure) {
    this.atomStructure = atomStructure;
  }

  public void refresh(double milisecond) {
    atomStructure.refresh(milisecond);
  }

  private void paintOrbit(int orbitNumber, Graphics g) {
    g.setColor(Color.black);
    for (int i = 0; i < orbitNumber; i++) {
      g.drawOval(i * orbitDistance, i * orbitDistance, 2 * orbitDistance * (orbitNumber - i),
          2 * orbitDistance * (orbitNumber - i));
    }
  }

  private void paintStellar(int orbitNumber, Graphics g) {
    g.setColor(Color.black);
    g.fillOval(orbitNumber * orbitDistance - (int) (orbitDistance / 4),
        orbitNumber * orbitDistance - (int) (orbitDistance / 4), orbitDistance / 2,
        orbitDistance / 2);
  }

  private void paintPlanet(int orbitNumer, int orbitIndex, double angle, Graphics g) {
    int x = orbitNumer * orbitDistance
        + (int) (orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 8);
    int y = orbitNumer * orbitDistance
        + (int) (-orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI) - orbitDistance / 8);
    int planetDiameter = (int) (orbitDistance / 4);
    g.setColor(Color.green);
    g.fillOval(x, y, planetDiameter, planetDiameter);
  }

  private void paintSystem(AtomStructure<Nucleus, Electron> atomStructure, Graphics g) {
    int orbitNumber = atomStructure.getOrbitNumber();
    TreeMap<Track, ArrayList<Electron>> treeMap = atomStructure.getOrbitMap();

    paintStellar(orbitNumber, g);
    paintOrbit(orbitNumber, g);
    int i = 0;
    for (Track track : treeMap.keySet()) {
      ++i;
      for (Electron electron : treeMap.get(track)) {
        paintPlanet(orbitNumber, i, electron.getCurAngle(), g);
      }
    }
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(Color.gray);
    paintSystem(atomStructure, g);

  }

  public static void main(String[] args) {

  }

}
