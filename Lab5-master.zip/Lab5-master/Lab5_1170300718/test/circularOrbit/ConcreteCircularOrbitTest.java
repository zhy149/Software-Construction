package circularorbit;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

import centralobject.CentralObject;
import centralobject.Person;
import centralobject.Stellar;
import circularorbit.ConcreteCircularOrbit;
import physicalobject.Electron;
import physicalobject.PhysicalObject;
import track.Track;

public class ConcreteCircularOrbitTest {

  @Test
  public void testGetOrbitMap() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.orbitMap.put(new Track(10), new ArrayList<PhysicalObject>());
    assertEquals(1, test.orbitMap.keySet().size());
  }

  @Test
  public void resetAngle() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addSurObject(new Electron(10));
    test.resetAngle();
  }

  @Test
  public void testRefresh() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addSurObject(new Electron(10));
    test.refresh(10);

  }

  @Test
  public void testGetSurObjectNumber() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addSurObject(new Electron(10));
    test.addSurObject(new Electron(10));
    test.addSurObject(new Electron(10));
    assertEquals(3, test.getSurObjectNumber());
  }

  @Test
  public void testEmptyCircularOrbit() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test2 = test.emptyCircularOrbit();
  }

  @Test
  public void testAddOrbit() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addOrbit(new Track(10));
    test.addOrbit(new Track(20));
    assertEquals(2, test.orbitMap.size());
    test.addOrbit(new Track(20));
    assertEquals(2, test.orbitMap.size());
  }

  @Test
  public void testDeleteOrbit() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addOrbit(new Track(10));
    test.addOrbit(new Track(20));
    test.deleteOrbit(new Track(20));
    assertEquals(1, test.orbitMap.size());
  }

  @Test
  public void testDeleteOrbitByRadius() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addOrbit(new Track(10));
    test.addOrbit(new Track(20));
    test.deleteOrbitByRadius(10);
    assertEquals(1, test.orbitMap.size());
  }

  @Test
  public void testAddCentralObject() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addCenObject(new Stellar("a", 10, 20));
    assertTrue(test.centralObject != null);
  }

  @Test
  public void DeleteSurObjectByName() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addSurObject(new Person("aa", 10, true));
    test.addSurObject(new Person("bb", 1, false));
    test.deleteSurObjectByName("aa");
    assertEquals(test.getSurNameSet().contains("bb"), true);
    assertEquals(test.getSurNameSet().contains("aa"), false);
  }

  @Test
  public void testAddSurObject() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addSurObject(new Track(10), new Electron(10));
    assertEquals(1, test.getSurObjectNumber());
    test.addSurObject(new Electron(20));
    assertEquals(2, test.getSurObjectNumber());
  }

  @Test
  public void testOrbitNumber() {
    ConcreteCircularOrbit<CentralObject, PhysicalObject> test = new ConcreteCircularOrbit<CentralObject, PhysicalObject>();
    test.addOrbit(new Track(10));
    test.addOrbit(new Track(20));
    assertEquals(2, test.getOrbitNumber());
    test.addOrbit(new Track(20));
    assertEquals(2, test.getOrbitNumber());
  }

}
