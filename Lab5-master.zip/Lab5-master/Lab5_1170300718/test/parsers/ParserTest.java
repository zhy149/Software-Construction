package parsers;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Test;

public class ParserTest {

  @Test
  public void testIsNumber() {
    assertTrue(Parser.isNumber("0"));
    assertTrue(Parser.isNumber("0.001"));
    assertTrue(Parser.isNumber("9999.9999"));
    assertTrue(Parser.isNumber("1"));
    assertTrue(Parser.isNumber("1.51e4"));
  }

  @Test
  public void testGetContent() throws IOException {
    assertTrue(Parser.getContent(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt")
        .equals(Parser.getContent(
            "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt")));
  }

}
