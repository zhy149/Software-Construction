package applications;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import centralobject.Nucleus;
import parsers.AtomParser;
import parsers.Parser;
import physicalobject.Electron;

public class AtomStructureTest {
  @Test
  public void testAtomStructure() throws Exception {
    AtomStructure<Nucleus, Electron> atomStructure = AtomParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure.txt");
    atomStructure.checkRep();
    atomStructure.transit(1, 2);
    assertEquals(1,
        atomStructure.getOrbitMap().get(atomStructure.getOrbitMap().keySet().toArray()[0]).size());
    assertEquals(9,
        atomStructure.getOrbitMap().get(atomStructure.getOrbitMap().keySet().toArray()[1]).size());
    atomStructure.refresh(10);
    atomStructure.print();
  }
}
