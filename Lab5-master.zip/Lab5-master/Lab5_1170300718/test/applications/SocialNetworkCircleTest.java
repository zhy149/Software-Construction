package applications;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import centralobject.Person;
import parsers.SocialNetworkParser;

public class SocialNetworkCircleTest {

  public SocialNetworkCircle<Person, Person> getNetwork() throws Exception {
    return SocialNetworkParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
  }

  @Test
  public void testRefresh() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = getNetwork();
    socialNetworkCircle.refresh(100);
  }

  @Test
  public void testAddPerson() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = getNetwork();
    socialNetworkCircle.refresh(0);
    int personNumber = socialNetworkCircle.getSurObjectNumber();
    socialNetworkCircle.addPerson("pp");
    socialNetworkCircle.setRelationship("pp", "TommyWong", 3);
    socialNetworkCircle.refresh(0);
    assertEquals(personNumber + 1, socialNetworkCircle.getSurObjectNumber());

  }

  @Test
  public void testContainPerson() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = getNetwork();
    socialNetworkCircle.addPerson("pp");
    socialNetworkCircle.setRelationship("pp", "TommyWong", 3);
    socialNetworkCircle.refresh(0);
    socialNetworkCircle.containPerson(new Person("dsfsd", 10, true));
    assertTrue(socialNetworkCircle.getSurNameSet().contains("pp"));
  }

  @Test
  public void testDeletePerson() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = getNetwork();
    socialNetworkCircle.refresh(0);
    socialNetworkCircle.deletePerson("FrankLee");
    socialNetworkCircle.refresh(0);
    assertFalse(socialNetworkCircle.getSurNameSet().contains("FrankLee"));
  }

  @Test
  public void testDeleteRelationship() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = getNetwork();
    socialNetworkCircle.deleteRelationship("TommyWong", "FrankLee");
    socialNetworkCircle.getPerson("TommyWong");
    socialNetworkCircle.setRelationship("TommyWong", "FrankLee", 3);
    socialNetworkCircle.deletePerson("FrankLee");
    socialNetworkCircle.hasVertix("TommyWong");
    socialNetworkCircle.addCenObject(new Person("sdf", 10, true));
    socialNetworkCircle.addSurObject(new Person("dfsdf", 10, true));
  }

}
