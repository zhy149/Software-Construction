package applications;

import org.junit.Test;

import centralobject.Stellar;
import parsers.Parser;
import parsers.StellarParser;
import physicalobject.Planet;

public class StellarSystemTest {

  @Test
  public void testStellarSystem() throws Exception {
    StellarSystem<Stellar, Planet> stellarSystem = StellarParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt");
  }

}
