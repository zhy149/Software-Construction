package track;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class TrackTest {
  @Test
  public void testTrack() {
    Track track = new Track(100);
    assertEquals("track radius: " + track.radius, track.toString());
    assertEquals(100, track.getRadius());
    assertEquals(-1, track.compareTo(new Track(200)));
  }
}
