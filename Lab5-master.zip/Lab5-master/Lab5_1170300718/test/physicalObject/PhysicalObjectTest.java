package physicalobject;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import physicalobject.Electron;
import physicalobject.Planet;

public class PhysicalObjectTest {
  @Test
  public void testElectron() {
    Electron electron1 = new Electron(10);
    Electron electron2 = new Electron(10, 0);
    electron1.setCurAngle(100);
    assertEquals(100, electron1.getCurAngle());
    electron1.setOrbitRadius(20);
    assertEquals(20, electron1.getOrbitRadius());
    assertEquals(electron2.orbitRadius + " " + electron2.curAngle, electron2.toString());
    electron1.setNextAngle(10);
    assertEquals(0, electron1.getNextAngle(10));
    assertEquals("Electron", electron1.getName());
    electron1.setRadius(10);
    assertEquals(0, electron1.getRadius());
  }

  @Test
  public void testPlanet() {
    Planet planet = new Planet("a", "b", "c", 10, 100, 10, true, 5);
    planet.setCurAngle(10);
    assertEquals(10, planet.getCurAngle());
    planet.setNextAngle(0);
    assertEquals(9.0, planet.getNextAngle(100));
    planet.setOrbitRadius(100);
    assertEquals(100, planet.getOrbitRadius());
    assertEquals(planet.name, planet.getName());
    planet.setRadius(5);
    assertEquals(5, planet.getRadius());

  }
}
