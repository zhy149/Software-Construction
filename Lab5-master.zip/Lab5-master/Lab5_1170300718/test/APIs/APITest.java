package apis;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import apis.CircularorbitApis;
import applications.StellarSystem;
import centralobject.Stellar;
import parsers.StellarParser;
import physicalobject.Planet;

public class APITest {
  @Test
  public void testAPI() throws Exception {
    StellarSystem<Stellar, Planet> stellarSystem = StellarParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\"
        + "Lab3_1170300211\\src\\txt\\StellarSystem.txt");
    assertEquals(3, CircularorbitApis.getDistributionEntropy(stellarSystem));
    assertEquals(1377773, CircularorbitApis.getPhysicalDistance(stellarSystem,
        stellarSystem.getOrbitMap().get(stellarSystem.getOrbitMap().keySet().toArray()[0]).get(0),
        stellarSystem.getOrbitMap().get(stellarSystem.getOrbitMap().keySet().toArray()[1]).get(0)));
    assertEquals(0, CircularorbitApis.getLogicalDistance(stellarSystem,
        stellarSystem.getOrbitMap().get(stellarSystem.getOrbitMap().keySet().toArray()[0]).get(0),
        stellarSystem.getOrbitMap().get(stellarSystem.getOrbitMap().keySet().toArray()[1]).get(0)));
  }

}
