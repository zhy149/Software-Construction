package apis;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.junit.Test;

import apis.AtomPanel;
import apis.SocialNetworkPanel;
import apis.StellarSystemPanel;
import applications.AtomStructure;
import applications.SocialNetworkCircle;
import applications.StellarSystem;
import centralobject.Nucleus;
import centralobject.Person;
import centralobject.Stellar;
import parsers.AtomParser;
import parsers.SocialNetworkParser;
import parsers.StellarParser;
import physicalobject.Electron;
import physicalobject.Planet;

public class PanelTest {

  @Test
  public void testStellarPanel() throws Exception {
    StellarSystem<Stellar, Planet> stellarSystem = StellarParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt");
    StellarSystemPanel stellarSystemPanel = new StellarSystemPanel(stellarSystem);
    JFrame myFrame = new JFrame();
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    stellarSystemPanel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(stellarSystemPanel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);

    new Thread(new Runnable() {
      @Override
      public void run() {
        while (true) {
          stellarSystemPanel.refresh(1);
          stellarSystemPanel.repaint();
          try {
            Thread.sleep(100);
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      }
    }).start();
  }

  @Test
  public void testAtomPanel() throws Exception {
    AtomStructure<Nucleus, Electron> atomStructure = AtomParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure.txt");
    AtomPanel atomPanel = new AtomPanel(atomStructure);
    JFrame myFrame = new JFrame();
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    atomPanel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(atomPanel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);
    atomPanel.refresh(0);
    atomPanel.repaint();
  }

  @Test
  public void testSocialPanel() throws Exception {
    SocialNetworkCircle<Person, Person> socialNetworkCircle = SocialNetworkParser.parse(
        "C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
    JFrame myFrame = new JFrame();
    SocialNetworkPanel myPenel = new SocialNetworkPanel(socialNetworkCircle);
    Dimension preferSizeDimension = new Dimension(100000, 100000);
    myPenel.setPreferredSize(preferSizeDimension);
    JScrollPane myPane = new JScrollPane(myPenel);
    myPane.setSize(800, 800);
    myFrame.setSize(900, 900);
    myFrame.add(myPane);
    myFrame.setVisible(true);
    myPenel.refresh(0);
    myPenel.repaint();
  }
}
