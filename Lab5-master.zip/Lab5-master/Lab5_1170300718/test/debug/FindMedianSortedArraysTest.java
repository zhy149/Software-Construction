package debug;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class FindMedianSortedArraysTest {
  /**
   * Tests that assertions are enabled.
   */
  int a1[] = { 1, 3 };
  int b1[] = { 2 };
  int a2[] = { 1, 2 };
  int b2[] = { 3, 4 };
  int a3[] = { 1, 1, 1 };
  int b3[] = { 5, 6, 7 };

  @Test
  public void FindMedianSortedtest() {
    FindMedianSortedArrays find = new FindMedianSortedArrays();
    int[] num11 = { 1, 3 };
    int[] num12 = { 2 };
    int[] num21 = { 1, 2 };
    int[] num22 = { 3, 4 };
    int[] num31 = { 1, 1, 1 };
    int[] num32 = { 5, 6, 7 };
    int[] num41 = { 1, 1 };
    int[] num42 = { 1, 2, 3 };

    double ans1 = find.findMedianSortedArrays(num11, num12);
    double ans2 = find.findMedianSortedArrays(num21, num22);
    double ans3 = find.findMedianSortedArrays(num31, num32);
    double ans4 = find.findMedianSortedArrays(num41, num42);
    assertEquals(2, ans1);
    assertEquals(2.5, ans2);
    assertEquals(3, ans3);
    assertEquals(1, ans4);

  }

}
