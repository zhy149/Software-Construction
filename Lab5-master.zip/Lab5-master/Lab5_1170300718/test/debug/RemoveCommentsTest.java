package debug;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

public class RemoveCommentsTest {
  @Test
  public void removeTest() {
    // String[] teString= {"/*Test program ","*/","aaa","//bbb"};
    String[] teString = { "a/*comment", "line", "//assdasdasd", "more_comment*/b", "//assdasdasd" };
    RemoveComments testComments = new RemoveComments();
    List<String> anStrings = testComments.removeComments(teString);
    for (String i : anStrings) {
      System.out.println(i);
    }
    assertTrue(anStrings.iterator().next().equalsIgnoreCase("ab"));
  }

}
