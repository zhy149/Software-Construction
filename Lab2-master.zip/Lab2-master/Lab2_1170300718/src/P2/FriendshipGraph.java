package P2;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

import P1.graph.*;
import P2.Person;
//Abstraction function:
//AF(Graphvertex, Graphedges) client can get a graph from the class,
//    for instance:
/////////////////////////////////////////////////////////////////////
//For example, given this corpus:
//    FriendshipGraph graph = new FriendshipGraph();
//Person rachel = new Person("Rachel");
//Person ross = new Person("Ross");
//Person ben = new Person("Ben");
//Person kramer = new Person("Kramer");
//graph.addVertex(rachel);
//graph.addVertex(ross);
//graph.addVertex(ben);
//graph.addVertex(kramer);
//graph.addEdge(rachel, ross, 2);
//graph.addEdge(ross, rachel, 3);
//graph.addEdge(ross, ben, 4);
//graph.addEdge(ben, ross, 1);
//System.out.println(graph.getDistance(rachel, ross)); // should print 1
//System.out.println(graph.getDistance(rachel, ben)); // should print 2
//System.out.println(graph.getDistance(rachel, rachel)); // should print 0
//System.out.println(graph.getDistance(rachel, kramer)); // should print -1
///////////////////////////////////////////////////////
// Representation invariant: 
//   vertices is a non-repeated set and the HashSet has satisfy it, 
//       so it doesn't have limitation
//       edges contains a list of Edge<L>, any two of it 
//       are different(the definition of difference)
//////////////////////////////////////////////////////////
// Safety from rep exposure:  
//    the vertices and edges are modified by "private final", 
//    and I use Defensive copy to protect it
//    in function which may return reps.
//
//////////////////////////////////////////////////////////
public class FriendshipGraph {
 Graph<Person> graph = new ConcreteEdgesGraph<Person>();
 public boolean addVertex(Person name) {
	 return graph.add(name);
 }
 public int addEdge(Person name1, Person name2, int weight) {
	 graph.set(name2, name1, weight);
	 return graph.set(name1, name2, weight);
 }
 public int getDistance(Person name1,  Person name2) {//������֮����������·��
	 Set<Person> haSet = graph.vertices();
		
		for (Person xPerson2 : haSet) {
			xPerson2.distance=0;
			xPerson2.visited = false;
		}
		Queue<Person> queue = new LinkedList<Person>();
		queue.add(name1);
		if (name1.getname().equals(name2.getname())) {
			return 0;
		}
		while (!queue.isEmpty()) {
			for(Person a : graph.targets(queue.peek()).keySet()) {
				if (!a.visited) {
					a.visited = true;
					queue.add(a);
					a.distance = queue.peek().distance + graph.targets(queue.peek()).get(a);
					if (a.getname().equals(name2.getname()))
						return a.distance;
				}
			}
			queue.remove();
		}
		
		return -1;

 }
// public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		FriendshipGraph graph = new FriendshipGraph();
//		Person rachel = new Person("Rachel");
//		Person ross = new Person("Ross");
//		Person ben = new Person("Ben");
//		Person kramer = new Person("Kramer");
//		graph.addVertex(rachel);
//		graph.addVertex(ross);
//		graph.addVertex(ben);
//		graph.addVertex(kramer);
//		graph.addEdge(rachel, ross, 2);
//		graph.addEdge(ross, rachel, 3);
//		graph.addEdge(ross, ben, 4);
//		graph.addEdge(ben, ross, 1);
//		System.out.println(graph.getDistance(rachel, ross)); // should print 1
//		System.out.println(graph.getDistance(rachel, ben)); // should print 2
//		System.out.println(graph.getDistance(rachel, rachel)); // should print 0
//		System.out.println(graph.getDistance(rachel, kramer)); // should print -1
//	}
// 
}
