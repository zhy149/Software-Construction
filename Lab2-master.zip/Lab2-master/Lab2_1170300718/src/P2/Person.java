package P2;

public class Person {
    private String name;
    protected boolean visited;
    protected int distance = 0;
    public Person(String person)
    {
    	this.name = person;
    }
    public String getname() {
		return this.name;
	}
}
