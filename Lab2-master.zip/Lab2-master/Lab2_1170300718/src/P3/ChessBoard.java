package P3;
/**
 * this class is the board for the chess game and implement the interface Board
 *
 */
public class ChessBoard implements Board{
	
	private final Position[][] map = new Position[8][8];
	
	//RI:
	//	map: every block is a position that bind to the game
	//
	//AF:
	//	a 8*8 square matrix which a unit is a position
	//
	//RE:
	//	Because the operation is to change the layout of the board, so the map need to change
	//  the rep has been protect by the modifier of private final
	public ChessBoard() {
		for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) {
				map[i][j] = new Position(i, j);
			}
		}
	}

	@Override
	public Position[][] getMap() {
		return map;
	}

	@Override
	public void setBoard(Piece p, int x, int y) {
		map[x][y].setPiece(p);
		
	}

	@Override
	public void resetBoard(int x, int y) {
		map[x][y].resetPiece();
		
	}
	
}
