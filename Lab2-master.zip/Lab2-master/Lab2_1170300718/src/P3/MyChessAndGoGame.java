package P3;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * this class is the client end of the piece game, the player can input their information and 
 * then begin to play the game
 *
 */
public class MyChessAndGoGame {

	public static void main(String[] args) {
		System.out.println("Please input the game type: (Go or Chess)");
	    Scanner scanner = new Scanner(System.in);
		String typeString = scanner.nextLine();
		if(!(typeString.equals("Go")||typeString.equals("Chess"))) {
			System.err.println("the type you input is invalid!Game over.");
			System.exit(0);
		}
		System.out.println("Please input the Player1 name:");
		String name1 = scanner.nextLine();
		System.out.println("Please input the Player2 name:");
		String name2 = scanner.nextLine();
		Game game = new Game(typeString, name1, name2);
		System.out.println("Help:\n"
				+ "set Player piece x-cor y-cor\n"
				+ "move Player source_x source_y target_x target_y\n"
				+ "lift Player target_x target_y\n"
				+ "over Player source_x source_y target_x target_y\n"
				+ "inquire Player target_x target_y\n"
				+ "sum Player");
		String roundString = new String();
		Action action = game.getAction();
		Pattern pattern = Pattern.compile("[0-9]*");  
		
		do {
			System.out.print("input=> ");
			roundString = scanner.nextLine();
			String[] orderStrings = roundString.split(" ");
			
			if(orderStrings[0].equals("set")) {
				if(typeString.equals("Chess")) {
					System.out.println("Chess don't have the set method!");
					continue;
				}
				else if(orderStrings.length!=5) {
					System.out.println("set usage:set Player piece x-cor y-cor");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				else if(!(pattern.matcher(orderStrings[3]).matches()&&
						pattern.matcher(orderStrings[4]).matches())) {
					System.out.println("the input of your position have invalid char!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				if(action.set(game.getBoard(), new Player(orderStrings[1],num), 
						new Piece(new Player(orderStrings[1],num),orderStrings[2]), 
								Integer.parseInt(orderStrings[3]), Integer.parseInt(orderStrings[4]))) {
					if(num==0) {
						game.P1add(roundString);
					}
					else {
						game.P2add(roundString);
					}
					
					
				}
			}
			else if(orderStrings[0].equals("move")) {
				if(typeString.equals("Go")) {
					System.out.println("Go don't have the set method!");
					continue;
				}
				else if(orderStrings.length!=6) {
					System.out.println("move usage: move Player source_x source_y target_x target_y");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				else if(!(pattern.matcher(orderStrings[2]).matches()&&
						pattern.matcher(orderStrings[3]).matches()&&
						pattern.matcher(orderStrings[4]).matches()&&
						pattern.matcher(orderStrings[5]).matches())) {
					System.out.println("the input of your position have invalid char!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				if(action.move(game.getBoard(), new Player(orderStrings[1],num), 
						new Position(Integer.parseInt(orderStrings[2]), 
								Integer.parseInt(orderStrings[3])), 
						new Position(Integer.parseInt(orderStrings[4]), 
										Integer.parseInt(orderStrings[5])))) {
					if(num==0) {
						game.P1add(roundString);
					}
					else {
						game.P2add(roundString);
					}
				}
				
			}
			else if(orderStrings[0].equals("lift")) {
				if(typeString.equals("Chess")) {
					System.out.println("Chess don't have the set method!");
					continue;
				}
				else if(orderStrings.length!=4) {
					System.out.println("lift usage: lift Player target_x target_y");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				else if(!(pattern.matcher(orderStrings[2]).matches()&&
						pattern.matcher(orderStrings[3]).matches())) {
					System.out.println("the input of your position have invalid char!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				if(action.lift(game.getBoard(), new Player(orderStrings[1],num),
						new Position(Integer.parseInt(orderStrings[2]), 
								Integer.parseInt(orderStrings[3])))) {
					if(num==0) {
						game.P1add(roundString);
					}
					else {
						game.P2add(roundString);
					}
				}
					
			}
			else if(orderStrings[0].equals("over")) {
				if(typeString.equals("Go")) {
					System.out.println("Go don't have the set method!");
					continue;
				}
				else if(orderStrings.length!=6) {
					System.out.println("over usage: over Player source_x source_y target_x target_y");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				else if(!(pattern.matcher(orderStrings[2]).matches()&&
						pattern.matcher(orderStrings[3]).matches()&&
						pattern.matcher(orderStrings[4]).matches()&&
						pattern.matcher(orderStrings[5]).matches())) {
					System.out.println("the input of your position have invalid char!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				if(action.over(game.getBoard(), new Player(orderStrings[1],num), 
						new Position(Integer.parseInt(orderStrings[2]), 
								Integer.parseInt(orderStrings[3])), 
						new Position(Integer.parseInt(orderStrings[4]), 
										Integer.parseInt(orderStrings[5])))) {
					if(num==0) {
						game.P1add(roundString);
					}
					else {
						game.P2add(roundString);
					}
				}
			}
			else if(orderStrings[0].equals("inquire")) {
			    if(orderStrings.length!=4) {
					System.out.println("inquire usage: inquire Player target_x target_y");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				else if(!(pattern.matcher(orderStrings[2]).matches()&&
						pattern.matcher(orderStrings[3]).matches())) {
					System.out.println("the input of your position have invalid char!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				if(action.inquire(game.getBoard(),
						new Position(Integer.parseInt(orderStrings[2]), 
								Integer.parseInt(orderStrings[3])))) {
					if(num==0) {
						game.P1add(roundString);
					}
					else {
						game.P2add(roundString);
					}
				}
			}
			else if(orderStrings[0].equals("sum")) {
			    if(orderStrings.length!=2) {
					System.out.println("sum usage: sum Player");
					continue;
				}
				else if(!(orderStrings[1].equals(name1)||orderStrings[1].equals(name2))){
					System.out.println("Please input the correct player name!");
					continue;
				}
				int num = orderStrings[1].equals(name1)?0:1;
				List<Integer> list = game.getPlayerPiece();
				System.out.println("the number of piece are:\n"
						+"player1: "+list.get(0)+"\n"
						+"player2: "+list.get(1));
 				if(num==0) {
					game.P1add(roundString);
				}
				else {
					game.P2add(roundString);
				}
			}
			else if(orderStrings[0].equals("end")) {
				System.out.println("Gameover!");
				break;
			}
			else {
				System.out.println("the order you input is invaild");
				continue;
			}
		}while(true);
		System.out.println("the path of player:");
		System.out.println(name1+":");
		for(String s:game.getPlay1Path()) {
			System.out.println(s);
		}
		System.out.println(name2+":");
		for(String s:game.getPlay2Path()) {
			System.out.println(s);
		}
		scanner.close();
	}

}
