package P3;
/**
 * this class is to describe the piece of the game
 *
 */
public class Piece {

	private final Player player;
	private final String type;
	
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Abstraction function:
    // client will get a graph in the following format:
    // "the piece is a "rook" of the playerX" ,X = 1, 2
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Representation invariant:
    // Player's name is either player1 or player2
	// type:
	// "w": the white piece of the gopiece
	// "b": the black piece of the gopiece
	// "rook": the rook piece of the chesspiece
	// "knight": the knight piece of the chesspiece
	// "bishop": the bishop piece of the chesspiece
	// "queen": the queen piece of the chesspiece
	// "king": the king piece of the chesspiece
	// "pawn": the pawn piece of the chesspiece
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Safety from rep exposure:
    // the rep are modified with the private final and the @return of all the method are immutable or 
    // use the defensive copy
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * the constructor
	 * @param p the owner of the piece
	 * @param t the type of the piece
	 */
	public Piece(Player p, String t) {
		this.player = p;
		this.type = t;
	}
	
	/**
	 * the constructor
	 * @param p the other p which you want to copy
	 */
	public Piece(Piece p) {
		this.player = p.getPlayer();
		this.type = p.getType();
	}
	
	/**
	 * to observe the type of this piece
	 * 
	 * @return a string which reflect the type;
	 * "w": the white piece of the gopiece
	 * "b": the black piece of the gopiece
	 * "rook": the rook piece of the chesspiece
	 * "knight": the knight piece of the chesspiece
	 * "bishop": the bishop piece of the chesspiece
	 * "queen": the queen piece of the chesspiece
	 * "king": the king piece of the chesspiece
	 * "pawn": the pawn piece of the chesspiece
	 */
	public String getType() {
		return new String(type);
	}

	/**
	 * to observe the player which is the piece owner 
	 * @return the player of this.player
	 */
	public Player getPlayer() {
		return new Player(player);
	}

}
