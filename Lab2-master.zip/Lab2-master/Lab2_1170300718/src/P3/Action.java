package P3;


/**
 * 
 * this interface is the abstract class of all the implementation-action which define all
 * the api that the chess games will be use, and in the ChessAction and the GoAction, they will
 * implement it.
 *
 */
public interface Action {
	/**
	 * this method implement the function that the player can set the piece which has not
	 * locate on the board on the board
	 * @param board: a Board which is the platform of the player execution
	 * @param player: a Player who execute the order
	 * @param piece: a Piece which is operated by the player
	 * @param x: the x-coordinate of the position of target position
	 * @param y: the y-coordinate of the position of target position
	 * @return a boolean that, true if the piece can be settled on the board;
	 * 		   otherwise, the piece can't be settled on the board because of some reasons,
	 *         for example, there have been already a piece or the position is out of the bound
	 *         ,etc.
	 */
	public boolean set(Board board,Player player,Piece piece,int x,int y);
	
	/**this method implement the function that the player can move the piece from position to
	 * position on the board
	 * 
	 * @param board: a Board which is the platform of the player execution
	 * @param player a Player who execute the order
	 * @param source a position which is the move operate source
	 * @param target a position which is the move operation target
	 * @return a boolean that, true if the move operation can be execute
	 * 		   otherwise, the piece can't be move on the board because of some reasons,
	 *         for example, there have been already a piece on the target
	 *         or the position is out of the bound,etc.
	 */
	public boolean move(Board board,Player player,Position source,Position target);
	
	/**this method implement the function that the player can lift the piece which has been on
	 * the board now
	 * 
	 * 
	 * @param board a Board which is the platform of the player execution
	 * @param player a Player who execute the order
	 * @param target a position which is the lift operation target
	 * @return a boolean that, true if the piece can be lifted on the board;
	 * 		   otherwise, the piece can't be lifted on the board because of some reasons,
	 *         for example, there have not been a piece on the target position
	 *         or the position is out of the bound,etc.
	 */
	public boolean lift(Board board,Player player,Position target);
	
	/**this method implement the function that the player can over the piece from the source
	 * to the target on the board and lift the opponent piece on the target
	 * 
	 * @param board a Board which is the platform of the player execution
	 * @param player a Player who execute the order
	 * @param source a position which is the over operate source
	 * @param targeta a position which is the over operation target
	 * @return a boolean that, true if the over operation can be execute successfully
	 *         on the board;
	 * 		   otherwise, the over operation can't be executed on the board because of some reasons,
	 *         for example, there have not been a piece on the source position, the piece on
	 *         the target are the player's piece or the position is out of the bound,etc.
	 *         
	 */
	public boolean over(Board board,Player player,Position source, Position target);
	
	/**this method implement the function that the player can inquire the piece's information
	 *  which is on the target position
	 *
	 * @param board a Board which is the platform of the player execution
	 * @param target a position which is the inquire operation target
	 * @return a boolean that, true if the over operation can be execute successfully
	 *         on the board;
	 * 		   otherwise, the over operation can't be executed on the board because of some reasons,
	 *         for example, there have not been a piece on the source position, 
	 *          or the position is out of the bound,etc.
	 */
	public boolean inquire(Board board,Position target);
}