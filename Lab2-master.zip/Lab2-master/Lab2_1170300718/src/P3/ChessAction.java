package P3;
/**
 * the class implements the interface Action, Specifically for chess services
 *
 */
public class ChessAction implements Action{
	
	//No rep
	//No rep defined, so No RI
	//No AF
	//
	
	// Safety from rep exposure:No rep are defined on this class,so no RE
	public boolean set(Board board, Player player, Piece piece, int x, int y) {
		System.out.println("ChessPiece don't have the set action!");
		return false;
	}

	@Override
	public boolean move(Board board, Player player, Position source, Position target) {
		int size = board.getMap().length;
		int x1 = source.getX();
		int y1 = source.getY();
		int x2 = target.getX();
		int y2 = target.getY();
		if(source.isOutofBound(size)) {
			System.out.println("the position of source is out of bound!");
			return false;
		}
		else if(board.getMap()[x1][y1].getPiece()==null) {
			System.out.println("there aren't piece on the source position!");
			return false;
		}
		else if(!board.getMap()[x1][y1].getPiece().getPlayer().getName().equals(player.getName())) {
			System.out.println("the piece on the source doesn't belong to you!");
			return false;
		}
		else if(target.isOutofBound(size)) {
			System.out.println("the position of target is out of bound!");
			return false;
		}
		else if(source.isEquals(target)) {
			System.out.println("the source and the target is the same position!");
			return false;
		}
		else if(board.getMap()[x2][y2].getPiece()!=null) {
			System.out.println("There are already pieces on the target position!");
			return false;
		}
		board.getMap()[x2][y2].setPiece(board.getMap()[x1][y1].getPiece());
		board.getMap()[x1][y1].resetPiece();
		return true;
	}

	@Override
	public boolean lift(Board board, Player player, Position target) {
		System.err.println("ChessPiece doesn't have the lift action!");
		return false;
	}

	@Override
	public boolean over(Board board, Player player, Position source, Position target) {
		int size = board.getMap().length;
		int x1 = source.getX();
		int y1 = source.getY();
		int x2 = target.getX();
		int y2 = target.getY();
		if(source.isOutofBound(size)) {
			System.out.println("the position of source is out of bound!");
			return false;
		}
		else if(board.getMap()[x1][y1].getPiece()==null) {
			System.out.println("there aren't piece on the source position!");
			return false;
		}
		else if(target.isOutofBound(size)) {
			System.out.println("the position of target is out of bound!");
			return false;
		}
		else if(source.isEquals(target)) {
			System.out.println("the source and the target is the same position!");
			return false;
		}
		else if(board.getMap()[x2][y2].getPiece()==null) {
			System.out.println("there aren't piece on the target position!");
			return false;
		}
		else if(board.getMap()[x2][y2].getPiece().getPlayer().isEquals(player)) {
			System.out.println("the piece on the target belongs to you!");
			return false;
		}
		else if(!board.getMap()[x1][y1].getPiece().getPlayer().getName().equals(player.getName())) {
			System.out.println("the piece on the source doesn't belong to you!");
			return false;
		}
		board.getMap()[x2][y2].resetPiece();
		board.getMap()[x2][y2].setPiece(board.getMap()[x1][y1].getPiece());
		board.getMap()[x1][y1].resetPiece();
		return true;
	}

	@Override
	public boolean inquire(Board board,Position target) {
		int size = board.getMap().length;
		if(target.isOutofBound(size)) {
			System.out.println("the position of target is out of bound!");
			return false;
		}
		if(board.getMap()[target.getX()][target.getY()].isEmpty()) {
			System.out.println("the target you inquire is empty");
		}
		else {
			System.out.println("the piece on this position is "+
		board.getMap()[target.getX()][target.getY()].getPiece().getType()+" of "+
		board.getMap()[target.getX()][target.getY()].getPiece().getPlayer().getName());
		}
		return true;
	}
}
