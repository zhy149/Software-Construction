package P3;
/**
 * 
 * this interface is the abstract class of all the implementation-board which define all
 * the api that support to the board of the game, and in the ChessBoard and the GoBoard, they will
 * implement it.
 */
public interface Board {
	/** this method return the whole board of the game
	 * 
	 * @return a Position[][] which return the whole board position information
	 * 
	 */
	public Position[][] getMap();
	
	/**Bind a position on the map to a specific piece(put a piece on the position)
	 * 
	 * @param p a Piece which you want to put
	 * @param x the x-coordinate of the position
	 * @param y the y-coordinate of the position
	 */
	public void setBoard(Piece p,int x,int y);
	
	/**Unbind the position on the map from the specific piece(take out the piece on the position)
	 * 
	 * @param x the x-coordinate of the position
	 * @param y the y-coordinate of the position
	 */
	public void resetBoard(int x,int y);
}
