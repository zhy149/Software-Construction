package P3;


/**
 * this class is defined to depict the player in the piece game
 *
 */
public class Player {

	private final String name;
	private final int num;
	
	 ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Abstraction function:
    // AF(Player) = Player.name
    // 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Representation invariant:
    // name is a non-empty String
	// num is in {0,1}
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Safety from rep exposure:
    // the rep are modified with the private final and the @return of all the method are immutable or 
    // use the defensive copy
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * constructor
	 * @param myname the name of the player 
	 * @param n the number of the player:
	 * 		  0 if is the player1 or 1 is the player2
	 */
	public Player(String myname,int n) {
		this.name = myname;
		this.num = n;
	}
	
	/**constructor
	 *
	 * @param p is the other player which you will copy
	 */
	public Player(Player p) {
		this.name = p.getName();
		this.num = p.getNum();
	}
	
	/**
	 * to observe this.name
	 * @return a String which is the player's name
	 */
	public String getName() {
		return new String(this.name);
	}
	
	/**
	 * to observe this player's number
	 * @return a int represent the number
	 */
	public int getNum() {
		return this.num;
	}
	
	/**
	 * to judge whether the two player is equal
	 * @param p is the other player which you want to judge
	 * @return true if the two player are equal;
	 * 		   false otherwise
	 */
	public boolean isEquals(Player p) {
		return this.name.equals(p.getName());
	}
}
