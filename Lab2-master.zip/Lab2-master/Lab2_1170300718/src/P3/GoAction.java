package P3;
/**
 * the class implements the interface Action, Specifically for go services
 *
 */
public class GoAction implements Action{
	//No rep
		//No rep defined, so No RI
		//No AF
		//
		// Safety from rep exposure:No rep are defined on this class,so no RE

	@Override
	public boolean set(Board board, Player player, Piece piece, int x, int y) {
		int size = board.getMap().length;
		if(piece.getType().equals("b")==false&&piece.getType().equals("w")==false) {
			System.out.println("the piece are not GoPiece!");
			return false;
		}
		else if(player.getNum()==0&&piece.getType().equals("b") 
				||player.getNum()==1&&piece.getType().equals("w")) {
			System.out.println("the player and the piece don't match!");
			return false;
	    }
		else if(x<0||x>=size||y<0||y>=size) {
			System.out.println("the position is out of bound!");
			return false;
		}
		else if(!board.getMap()[x][y].isEmpty()){
			System.out.println("the position have already been set!");
			return false;
		}
		else {
			board.setBoard(piece, x, y);
			return true;
		}
	}

	@Override
	public boolean move(Board board, Player player, Position source, Position target) {
		System.out.println("Gopiece doesn't have the move action!");
		return true;
	}

	@Override
	public boolean lift(Board board, Player player, Position target) {
		int size = board.getMap().length;
		if(target.isOutofBound(size)) {
			System.out.println("the position of target is out of bound!");
			return false;
		}
		else if(board.getMap()[target.getX()][target.getY()].isEmpty()) {
			System.out.println("there aren't piece on the target position!");
			return false;
		}
		else if(board.getMap()[target.getX()][target.getY()].getPiece().getPlayer().isEquals(player)) {
			System.out.println("the piece on the target belongs to you!");
			return false;
		}
		board.resetBoard(target.getX(), target.getY());
		return true;
	}

	@Override
	public boolean over(Board board, Player player, Position source, Position target) {
		System.out.println("Gopiece doesn't have the over action!");
		return false;
	}

	@Override
	public boolean inquire(Board board, Position target) {
		int size = board.getMap().length;
		if(target.isOutofBound(size)) {
			System.out.println("the position of target is out of bound!");
			return false;
		}
		if(board.getMap()[target.getX()][target.getY()].isEmpty()) {
			System.out.println("the target you inquire is empty");
		}
		else {
			System.out.println("the piece on this position is "+
		board.getMap()[target.getX()][target.getY()].getPiece().getType()+" of "+
		board.getMap()[target.getX()][target.getY()].getPiece().getPlayer().getName());
		}
		return true;
	}
}
