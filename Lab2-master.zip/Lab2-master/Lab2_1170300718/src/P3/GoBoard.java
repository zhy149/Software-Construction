package P3;
/**
 * this class is the board for the chess game and implement the interface Board
 *
 */
public class GoBoard implements Board{
	private final Position[][] map;
	//RI:
	//	map: every block is a position that bind to the game
	//
	//AF:
	//	a 18*18 square matrix which a unit is a position
	//
	//RE:
	//	Because the operation is to change the layout of the board, so the map need to change
	//  the rep has been protect by the modifier of private final
	public GoBoard() {
		map = new Position[19][19];
		for(int i=0;i<19;i++) {
			for(int j=0;j<19;j++) {
				map[i][j] = new Position(i, j);
			}
		}
	}
	@Override
	public Position[][] getMap() {
		return map;
	}
	
	@Override
	public void setBoard(Piece p, int x,int y) {
		map[x][y].setPiece(p);
	}
	@Override
	public void resetBoard(int x, int y) {
		map[x][y].resetPiece();
		
	}
}
