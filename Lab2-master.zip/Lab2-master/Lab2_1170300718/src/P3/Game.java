package P3;

import java.util.ArrayList;
import java.util.List;
/**
 * this class is the main manager of the whole game, the Client-end should use it to produce
 * a game
 *
 */
public class Game {
	
    private final Player p1;
    private final Player p2;
    private final Board board;
    private final Action action;
    private final List<String> p1_action;
    private final List<String> p2_action;

    ///////////////////////////////////////////////////////////////////////////
    //
    //  Abstraction function:
    //  a specific game
    //
    ///////////////////////////////////////////////////////////////////////////////////////////
    //
    // Representation invariant:
    // the p1,p2 should be Players with different name which is defined in this lab
    // the board should be either chessboard or goboard defined in this lab
    // the action should be either chessaction or goaction defined in this lab
    // the two String-list should be save two player's historic orders
    // 
    //
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Safety from rep exposure:
    // all the rep has modified by private final and the non-change rep in logic have use the 
    // defensive copy
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    /**constructor of this class
     * 
     * @param gameType the type of the game, "Go" or "Chess"
     * @param p1Name the name of the Player1
     * @param p2Name the name of the Player2
     */
    public Game(String gameType, String p1Name, String p2Name) {
    	p1=new Player(p1Name,0);
    	p2=new Player(p2Name,1);
    	if(gameType.equals("Go")) {
    		board=new GoBoard();
    		action = new GoAction();
    	}
    	else{
    		board = new ChessBoard();
    		action = new ChessAction();
    		ChessGameInit();
    	}
    	
    	p1_action = new ArrayList<String>();
    	p2_action = new ArrayList<String>();
    }
    
    /**
     * to observe the player1
     * @return the copy of player1
     */
    public Player getPlayer1() {
    	return new Player(p1);
    }
    
    /**
     * to observe the player2
     * @return the copy of player2
     */
    public Player getPlayer2() {
    	return new Player(p2);
    }
    
    /**to get the game board
     * 
     * @return the board
     */
    public Board getBoard() {
    	return this.board;
    }
    
    /**to get the historic order of the player1
     * 
     * @return a list of the order
     */
    public List<String> getPlay1Path(){
    	return new ArrayList<String>(p1_action);
    }
    
    /**to get the historic order of the player2
     * 
     * @return a list of the order
     */
    public List<String> getPlay2Path(){
    	return new ArrayList<String>(p2_action);
    }
    
    /**to get the action of this game
     * 
     * @return a action
     */
    public Action getAction() {
    	return this.action;
    }
    
    /**to get the pieces number of two player
     * 
     * @return a list, which list.get(0) is the number piece of player1 and the list.get(1) is
     * the number of piece of player2
     */
    public List<Integer> getPlayerPiece() {
    	int size = this.board.getMap().length;
    	int p1_sum=0;
    	int p2_sum=0;
    	for(int i=0;i<size;i++) {
    		for(int j=0;j<size;j++) {
    			if(this.board.getMap()[i][j].isEmpty()==false&&
    					this.board.getMap()[i][j].getPiece().getPlayer().isEquals(this.p1)) {
    				p1_sum++;
    			}
    			else if(this.board.getMap()[i][j].isEmpty()==false&&
    					this.board.getMap()[i][j].getPiece().getPlayer().isEquals(this.p2)) {
    				p2_sum++;
    			}
    		}
    	}
    	List<Integer> list = new ArrayList<Integer>();
    	list.add(p1_sum);
    	list.add(p2_sum);
    	return new ArrayList<Integer>(list);
    }
    
    /**
     *  to initiate the chess game
     */
    private void ChessGameInit() {
    	board.getMap()[0][0].setPiece(new Piece(p1,"rook"));
    			
    	board.getMap()[7][0].setPiece(new Piece(p1,"rook"));
    	board.getMap()[1][0].setPiece(new Piece(p1,"knight"));
    	board.getMap()[6][0].setPiece(new Piece(p1,"knight"));
    	board.getMap()[2][0].setPiece(new Piece(p1,"bishop"));
    	board.getMap()[5][0].setPiece(new Piece(p1,"bishop"));
    	board.getMap()[3][0].setPiece(new Piece(p1,"queen"));
    	board.getMap()[4][0].setPiece(new Piece(p1,"king"));
    	for(int i=0;i<8;i++) {
    		board.getMap()[i][1].setPiece(new Piece(p1,"pawn"));
    	}
    	
    	for(int i=0;i<8;i++) {
    		board.getMap()[i][6].setPiece(new Piece(p2,"pawn"));
    	}
     	board.getMap()[0][7].setPiece(new Piece(p2,"rook"));
    	board.getMap()[7][7].setPiece(new Piece(p2,"rook"));
    	board.getMap()[1][7].setPiece(new Piece(p2,"knight"));
    	board.getMap()[6][7].setPiece(new Piece(p2,"knight"));
    	board.getMap()[2][7].setPiece(new Piece(p2,"bishop"));
    	board.getMap()[5][7].setPiece(new Piece(p2,"bishop"));
    	board.getMap()[3][7].setPiece(new Piece(p2,"queen"));
    	board.getMap()[4][7].setPiece(new Piece(p2,"king"));
    }
    
    /**
     * to add the newest order in the player1's list
     * @param path a order of the player1
     */
    public void P1add(String path) {
    	p1_action.add(path);
    }
    
    /**
     * to add the newest order in the player2's list
     * @param path a order of the player2
     */
    public void P2add(String path) {
    	p2_action.add(path);
    }
}
