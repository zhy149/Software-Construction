package P3;
/**
 * this class is depict the position of the game
 *
 */
public class Position {
	private final int X;
	private final int Y;
	private boolean isEmpty;
	private Piece piece;
	 ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Abstraction function:
    // AF(position) = (x,y),where the x is the x-coordinate of the position,
	//							  the x is the x-coordinate of the position
    // 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Representation invariant:
    // x, y > 0
	// piece should be the piece which is defined in this lab
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Safety from rep exposure:
    // the rep are modified with the private final and the @return of all the method are immutable or 
    // use the defensive copy
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * constructor
	 * @param x the x-coordinate of the position
	 * @param y the y-coordinate of the position
	 */
	public Position(int x, int y) {
		this.X = x;
		this.Y = y;
		this.isEmpty = true;
		piece = null;
	}
	
	/**
	 * to observe the x-coordinate of the position
	 * @return the x-coordinate of the position
	 */
	public int getX() {
		return this.X;
	}
	
	/**
	 * to observe the y-coordinate of the position
	 * @return the y-coordinate of the position
	 */
	public int getY() {
		return this.Y;
	}
	
	/**to bind this position to a offered piece 
	 * (put the piece on this position)
	 * @param p the piece you want to layout
	 * @return boolean
	 *         true: if the setPiece can access
	 *         false: otherwise
	 */
	public boolean setPiece(Piece p) {
		if(!isEmpty) return false;
		this.piece = p;
		isEmpty = false;
		return true;
	}
	
	/**
	 * to unbind this position and its piece
	 * @return boolean
	 * 		   true: is the resetPiece can be execute
	 *         false: otherwise
	 */
	public boolean resetPiece() {
		if(isEmpty) return false;
		this.piece = null;
		isEmpty = true;
		return true;
	}
	
	/**
	 * to get the piece on this position
	 * @return a piece which is on this position
	 */
	public Piece getPiece() {
		if(this.isEmpty) {
			//System.out.println("There are no piece on this position!");
			return null;
		}
		return piece;
	}
	
	/**
	 * to judge whether the position is empty
	 * @return a boolean
	 *         true: is empty:
	 *         false: otherwise
	 */
	public boolean isEmpty() {
		return this.isEmpty;
	}
	
	/**
	 *  to judge whether the two position are equal
	 * @param p the other position you want to judge
	 * @return boolean
	 * 		   true: if the two position are equal
	 * 		   false: otherwise
	 */
	public boolean isEquals(Position p) {
		return this.X==p.getX()&&this.Y==p.getY();
	}
	
	/**
	 * to judge whether the position is out of bound of the board
	 * @param size the board's size
	 * @return boolean
	 * 		   true: if isn't out of bound
	 * 		   false: otherwise
	 */
	public boolean isOutofBound(int size) {
		return this.X<0||this.X>=size||this.Y<0||this.Y>=size;
	}
}
