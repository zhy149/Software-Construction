/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * An implementation of Graph.
 * 
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteVerticesGraph<L> implements Graph<L> {
    
    private final List<Vertex<L>> vertices = new ArrayList<Vertex<L>>();
    
    // Abstraction function:
    //   client can get a graph from this class
    //     for an example
    ///////////////////////////////////////////////////////////
    //    set an edge(a1, a2, 5)
    //    means set an edge from a1 to a2, and the edge weight is 5
    //    and theres is a (a2, 5) in the mapfrom of a1, and a (a1, 5)
    //    in the mapto.
    ///////////////////////////////////////////////////////////
    // Representation invariant:
    //   vertices is a non-repeated set and the HashSet has satisfy it, 
    //       so it doesn't have limitation
    /////////////////////////////////////////////////////////////////
    // Safety from rep exposure:
    //   the vertices are modified by "private final", and I use Defensive copy to protect it
    // in function which may return reps.
    //
    // TODO constructor
    public ConcreteVerticesGraph() {
    	vertices.clear();
    	checkRep();
		// TODO Auto-generated constructor stub
	}
    // TODO checkRep
    private void checkRep() {
		// TODO Auto-generated method stub
         int size = vertices.size();
         for(int i = 0; i < size-1; i++) {
        	 for(int j = i+1; j < size-1; j++) {
        		 assert !vertices.get(i).equals(vertices.get(j));
        	 }
         }
         if(size != 0) {
        	 for (int i1 = 0; i1 < size-1; i1++) {
				for (int j1 = i1+1; j1 < size-1; j1++) {
					if(vertices.get(i1).mapfrom().containsKey(vertices.get(j1).getname())){
//						int a1 = vertices.get(i1).mapfrom().get(j1);
						assert vertices.get(j1).mapto().containsKey(vertices.get(i1).getname())&&(vertices.get(i1).mapfrom().get(j1)==vertices.get(j1).mapto().get(i1));
					}
				}
			}
         }
	}
    @Override public boolean add(L vertex) {//vertices�����Ԫ����vertex���͵�
    	boolean add = true;
        for(Vertex<L> k: vertices)
        {
        	if((k.getname()).equals(vertex))
        	{
        		add = false;
        		break;
        	}
        }
        if(add == true) {
        	Vertex<L> a = new Vertex<L>(vertex);
        	vertices.add(a);
        }
        checkRep();
        return add;
    }
    
    @Override public int set(L source, L target, int weight) {
        int setans = 0;
        int flag1 = 0, flag2 = 0;
        if(vertices.size() == 0) {
        	Vertex<L> x1 = new Vertex<L>(source);
        	Vertex<L> x2 = new Vertex<L>(target);
        	if(weight != 0) {
        		Map<L, Integer> m1 = new HashMap<L, Integer>();
            	Map<L, Integer> m2 = new HashMap<L, Integer>();
            	m1.put(source, weight);
            	m2.put(target, weight);
            	x1.putmapfrom(m2);
            	x2.putmapto(m1);
        	}
        	vertices.add(x1);
        	vertices.add(x2);
        }
        else {
        	for(Vertex<L> x1 : vertices) {
            	if(x1.getname().equals(source)) {
            		flag1 = 1;
            	}
            	if(x1.getname().equals(target)) {
            		flag2 = 1;
            	}
            }
        	if(flag1 == 0 && flag2 == 0) {
        		Vertex<L> x1 = new Vertex<L>(source);
            	Vertex<L> x2 = new Vertex<L>(target);
            	if(weight != 0) {
            		Map<L, Integer> m1 = new HashMap<L, Integer>();
                	Map<L, Integer> m2 = new HashMap<L, Integer>();
                	m1.put(source, weight);
                	m2.put(target, weight);
                	x1.putmapfrom(m2);
                	x2.putmapto(m1);
            	}
            	vertices.add(x1);
            	vertices.add(x2);
        	}
        	else if(flag1 == 0 && flag2 == 1) {
        		for(int i1 = 0; i1 < vertices.size(); i1++) {
        			if(vertices.get(i1).getname().equals(target)) {
        				Vertex<L> sou = new Vertex<L>(source);
        				if(weight != 0) {
        					Map<L, Integer> m1 = new HashMap<L, Integer>();
        					Map<L, Integer> m2 = vertices.get(i1).mapto();
        					m1.put(vertices.get(i1).getname(), weight);
        					m2.put(source, weight);
        					vertices.get(i1).putmapto(m2);
        					sou.putmapfrom(m1);
        					
        				}
        				vertices.add(sou);
        			}
        		}
        	}
        	else if(flag1 == 1 && flag2 == 0) {
        		for(int i1 = 0; i1 < vertices.size(); i1++) {
        			if(vertices.get(i1).getname().equals(source)) {
        				Vertex<L> tar = new Vertex<L>(target);
        				if(weight != 0) {
        					Map<L, Integer> m1 = new HashMap<L, Integer>();
        					Map<L, Integer> m2 = vertices.get(i1).mapfrom();
        					m1.put(vertices.get(i1).getname(), weight);
        					m2.put(target, weight);
        					vertices.get(i1).putmapfrom(m2);
        					tar.putmapto(m1);
        				}
        				vertices.add(tar); //�ӵ������
        			}
        		}
        	}
        	else if(flag1 == 1 && flag2 == 1) {
        		int flag = 0; //flag�ж��Ƿ�Ȩֵ�Ѿ�����
                for(int i1 = 0; i1 < vertices.size(); i1++) {
                	if(flag == 1) {
                		break;  //to see if it can be converged?
                	}
                	if(vertices.get(i1).getname().equals(source)) {
                		for(int i2 = 0; i2 < vertices.size(); i2++) {
                			if(flag == 1) {
                				break; //to see if it can be converged?
                			}
            				if(vertices.get(i2).getname().equals(target)) {
            					flag = 1; //this is to notify that the weight has changed already
            					if(vertices.get(i1).mapfrom().containsKey(target)) {
            						setans = vertices.get(i2).mapto().get(source);
            					}
            					if(weight == 0) {
            						Map<L, Integer> m1 = vertices.get(i1).mapfrom();
                					Map<L, Integer> m2 = vertices.get(i2).mapto();
                					m1.remove(target);
                					m2.remove(source);
            						vertices.get(i1).putmapfrom(m1);
            						vertices.get(i2).putmapto(m2);
            					}
            					else {
            						Map<L, Integer> m1 = vertices.get(i1).mapfrom();
                					Map<L, Integer> m2 = vertices.get(i2).mapto();
                					m1.put(target, weight);
                					m2.put(source, weight);
                					vertices.get(i1).putmapfrom(m1);
                					vertices.get(i2).putmapto(m2);
            					}
            				}
            			}
                	}
        		}
        	}
        }
        checkRep();
        return setans;
        
    }
    
    @Override public boolean remove(L vertex) {
        boolean remcons = false;
        for(Vertex<L> k : vertices) {
        	if((k.getname()).equals(vertex))
        	{
        		remcons = true;
        		for(L to : k.mapfrom().keySet()) {
        			for(Vertex<L> k1 : vertices) {
        				if(k1.getname().equals(to)) {
        					Map<L, Integer> m1 = k1.mapto();
        					m1.remove(vertex);
        					k1.putmapto(m1);
        				}
        			}
        		}
        		for(L from : k.mapto().keySet()) {
        			for(Vertex<L> k2 : vertices) {
        				if(k2.getname().equals(from)) {
        					Map<L, Integer> m2 = k2.mapfrom();
        					m2.remove(vertex);
        					k2.putmapfrom(m2);
        				}
        			}
        		}
        		vertices.remove(k);		
        		break;
        	}
        }
        checkRep();
        return remcons;
        
    }
    
    @Override public Set<L> vertices() {
        Set<L> anset = new HashSet<L>();
        for(Vertex<L> k : vertices) {
        	anset.add(k.getname());
        }
        checkRep();
        return anset;
        
    }
    
    @Override public Map<L, Integer> sources(L target) {
        Map<L, Integer> sourceMap = new HashMap<L, Integer>();
        for(Vertex<L> k1 : vertices) {
        	if(k1.mapfrom().containsKey(target)) {
        		sourceMap.put(k1.getname(), k1.mapfrom().get(target));
        	}
        }
        checkRep();
        return sourceMap;
        
    }
    
    @Override public Map<L, Integer> targets(L source) {
        Map<L, Integer> targetMap = new HashMap<L, Integer>();
        for(Vertex<L> k2 : vertices) {
        	if(k2.mapto().containsKey(source)) {
        		targetMap.put(k2.getname(), k2.mapto().get(source));
        	}
        }
        checkRep();
        return targetMap;
    }
    
    // TODO toString()
    @Override
    public String toString() {
    	// TODO Auto-generated method stub
    	String a1 = new String();
    	for(Vertex<L> k : vertices) {
    		a1 = a1+k.toString();
    	}
    	checkRep();
    	return a1;
    			
    }
 
}

/**
 * TODO specification
 * Mutable.
 * This class is internal to the rep of ConcreteVerticesGraph.
 * 
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Vertex<L> {
    
    // TODO fields
	private L name = null;
	private Map<L, Integer> mapfrom_me = new HashMap<L, Integer>();
	private Map<L, Integer> mapto_me = new HashMap<L, Integer>();
    // Abstraction function:
	////////////////////////////////////////////////////////////////////////////////////
    //   name��vertex�����е�label������ΪString
	//   mapfrom_me��һ����ϣ�����洢�ĵ����Դ�vertexΪ���������з���ߵ��յ�
	//   mapto_meҲ��һ����ϣ��������һ����ͬ�ĵط������Ա�vertexΪ�յ�������з���ߵ������ɵ�
	//   Ҫ��weight����Ҫ����0
	/////////////////////////////////////////////////////////////////////////////////////
    // Representation invariant:
    //name is stable and invariant because it's string, and Mapfrom and Mapto are also
	//invariant since we set them as private
	/////////////////////////////////////////////////////////////////////////////////////
    // Safety from rep exposure:
    //   the vertices are modified by "private final", and I use Defensive copy to protect it
    // in function which may return reps.
    //
    // TODO constructor
	public Vertex(L name)
	{
		this.name = name;
	}
    // TODO checkRep
    private void checkRep() {
		// TODO Auto-generated method stub
       assert !mapfrom_me.containsValue(0)&&!mapto_me.containsValue(0);
	}
    // TODO methods
	public L getname() {
		checkRep();
		return name;
	}
	public void putmapfrom(Map<L, Integer> m) {
		checkRep();
		this.mapfrom_me = m;
	}
	public void putmapto(Map<L, Integer> m) {
		checkRep();
		this.mapto_me = m;
	}
	public Map<L, Integer> mapfrom(){
		checkRep();
		return mapfrom_me;
	}
	public Map<L, Integer> mapto(){
		checkRep();
		return mapto_me;
	}
    // TODO toString()
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String tostring = new String();
		for(L k : mapfrom_me.keySet()) {
			tostring += name+" "+k+":"+mapfrom_me.get(k)+"\n";
		}
		checkRep();
		return tostring;
	}
	
    
}
