/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;


import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * An implementation of Graph.
 * 
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteEdgesGraph<L> implements Graph<L> {
    
    private final Set<L> vertices = new HashSet<>();
    private final List<Edge<L>> edges = new ArrayList<>();
    
    // Abstraction function:
    //    AF(vertices, edges) client can get a graph from the class,
    //    for instance:
    /////////////////////////////////////
    //      vertices (a1,a2,a3)
    //
    //      edges: a1->a2:3,a1->a3:4
    //////////////////////////////////////////////
    //      these two infos mean there are three vertices in the graph:
    //      a1,a2,a3. and there are 2 edges in the graph, they are a1 to
    //      a2, the weight is 3. another is a1 to a3, and the weight is 4
    //////////////////////////////////////////////////////////////////////////
    // Representation invariant:
    //       vertices is a non-repeated set and the HashSet has satisfy it, 
    //       so it doesn't have limitation
    //       edges contains a list of Edge<L>, any two of it 
    //       are different(the definition of difference)
    /////////////////////////////////////////////////////////////////////////////       
    //
    // Safety from rep exposure:
    //   the vertices and edges are modified by "private final", and I use Defensive copy to protect it
    // in function which may return reps.
    //
    // TODO constructor: 
    public ConcreteEdgesGraph(){
    	vertices.clear();
    	edges.clear();
    	checkRep();
    }
    // TODO checkRep
    private void checkRep() {
		// TODO Auto-generated method stub
     int size = edges.size();
     for(int i = 0; i < size-1; i++)
     {
    	 for(int j = i+1; j < size-1; j++) {
    		 assert !edges.get(i).equals(edges.get(j));
    	 }
    	 Edge<L> e1Edge = edges.get(i);
    	 assert vertices.contains(e1Edge.getsource())&&vertices.contains(e1Edge.gettarget());
     }
     if(size != 0) {
    	 Edge<L> e2Edge = edges.get(size-1);
    	 assert vertices.contains(e2Edge.getsource())&&vertices.contains(e2Edge.gettarget());
     }
	}
    @Override public boolean add(L vertex) {
        boolean addans = true;
        for(L k : vertices) {
        	if(k.equals(vertex)) {
        		addans = false;
        		checkRep();
                return addans;
        	}
        }
        vertices.add(vertex);
        checkRep();
        return addans;
    }
    
    @Override public int set(L source, L target, int weight) { //set�������࣬�ú��ܽ�һ��set���߼�
        int setans = 0;
        if(edges.size() == 0) {
        	if(weight != 0) {
        	Edge<L> e1 = new Edge<L>(source, target, weight);
        	edges.add(e1);
        	vertices.add(source);
        	vertices.add(target);
        	}
        }
        else {
        	int flag = 0; //flag����Ϊ0��1��2����������Ǻ��������
        	for(Edge<L> e : edges) {  //ͬ������Ҫ���ۣ�Ȼ��дtoString����ز���
            	if(e.getsource().equals(source)&&e.gettarget().equals(target)) {
            		flag = 1;
            		setans = e.getweight();
            		e.changeweight(weight);
            		break;
            	}
            }
        	if(flag == 0) {
        		if(!vertices.contains(source)) {
        			vertices.add(source);
        		}
        		if(!vertices.contains(target)) {
        			vertices.add(target);
        		}
        		Edge<L> e1 = new Edge<L>(source, target, weight);
        		edges.add(e1);
        	}
        }
        checkRep();
        return setans;
    }
    
    @Override public boolean remove(L vertex) {
    	Iterator<L> iterator = vertices.iterator();
        int flag=0;
        while(iterator.hasNext()) {
        	L tmpString = iterator.next();
        	if(tmpString.equals(vertex)) {
        		iterator.remove();
        		flag=1;
        		break;
        	}
        }
        if(flag==0) {
        	checkRep();
        	return false;
        }
        Iterator<Edge<L>> iterator2 = edges.iterator();
        while(iterator2.hasNext()) {
        	Edge<L> tmpEdge = iterator2.next();
        	if(tmpEdge.getsource().equals(vertex)||tmpEdge.gettarget().equals(vertex)) {
        		iterator2.remove();
        	}
        }
        checkRep(); //remove��checkRep������
        return true;
    }
    
    @Override public Set<L> vertices() {    //error happened�����ؼ��ϴ���
        checkRep();
        return vertices;
    }
    
    @Override public Map<L, Integer> sources(L target) {
        Map<L, Integer> souMap = new HashMap<L, Integer>();
        for(Edge<L> e : edges) {
        	if(e.gettarget().equals(target)) {
        		souMap.put(e.getsource(), e.getweight());
        	}
        }
        checkRep();
        return souMap;
    }
    
    @Override public Map<L, Integer> targets(L source) {
        Map<L, Integer> tarMap = new HashMap<L, Integer>();
        for(Edge<L> e : edges) {
        	if(e.getsource().equals(source)) {
        		tarMap.put(e.gettarget(), e.getweight());
        	}
        }
        checkRep();
        return tarMap;
    }
    
    // TODO toString()
    @Override
    public String toString() {
    	// TODO Auto-generated method stub
    	String a0 = new String();
    	for(L a1 : vertices) {
    		a0 = a0+a1;
    	}
    	for(Edge<L> k : edges) {
    		a0 = a0+k.toString();
    	}
    	checkRep();
    	return a0;
    			
    }
}

/**
 * TODO specification
 * Immutable.
 * This class is internal to the rep of ConcreteEdgesGraph.
 * 
 * <p>PS2 instructions: the specification and implementation of this class is
 * up to you.
 */
class Edge<L> {
    
    // TODO fields
    private L source = null;  //�����µĿ��ַ��������Ը�ֵ�ķ���
    private L target = null;   //���������vertex����string��
    private int weight = 0;
    // Abstraction function:
    //   AF: client can get an edge from this class, for an example:
    /////////////////////////////////////////////////////////////
    //   Edge(a, b, 2) : this means this edge is from a and is to b, weight is 2
    ////////////////////////////////////////////////////////////////////////
    // Representation invariant:
    //   source and target should be invariant because they are stable
    //   and which have been already satisfied by it's type of String
    /////////////////////////////////////////////////////////////////////
    // Safety from rep exposure:
    //   the vertices and edges are modified by "private final", and I use Defensive copy to protect it
    // in function which may return reps.
    //
    // TODO constructor
    public Edge(L source, L target, int weight) { //constructor
    	if(weight != 0) { 
    		this.source = source;
        	this.target = target;
        	this.weight = weight;
    	}
    	checkRep();
    }
    // TODO checkRep
    private void checkRep() {
    	assert weight >= 0;
    }
    // TODO methods
    public void changeweight(int weight) {
    	checkRep();
    	this.weight = weight;
    }
    public L getsource() {
    	checkRep();
    	return this.source;
    }
    public L gettarget() {
    	checkRep();
    	return this.target;
    }
    public int getweight() {
    	checkRep();
    	return this.weight;
    }
    // TODO toString()
    @Override
	public String toString() {
		// TODO Auto-generated method stub
		String tostring = new String(source+" "+target+":"+weight);
		checkRep();
		return tostring;
	}
}
