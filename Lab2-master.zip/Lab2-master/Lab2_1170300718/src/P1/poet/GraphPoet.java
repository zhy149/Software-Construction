/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.poet;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import P1.graph.*;

/**
 * A graph-based poetry generator.
 * 
 * <p>GraphPoet is initialized with a corpus of text, which it uses to derive a
 * word affinity graph.
 * Vertices in the graph are words. Words are defined as non-empty
 * case-insensitive strings of non-space non-newline characters. They are
 * delimited in the corpus by spaces, newlines, or the ends of the file.
 * Edges in the graph count adjacencies: the number of times "w1" is followed by
 * "w2" in the corpus is the weight of the edge from w1 to w2.
 * 
 * <p>For example, given this corpus:
 * <pre>    Hello, HELLO, hello, goodbye!    </pre>
 * <p>the graph would contain two edges:
 * <ul><li> ("hello,") -> ("hello,")   with weight 2
 *     <li> ("hello,") -> ("goodbye!") with weight 1 </ul>
 * <p>where the vertices represent case-insensitive {@code "hello,"} and
 * {@code "goodbye!"}.
 * 
 * <p>Given an input string, GraphPoet generates a poem by attempting to
 * insert a bridge word between every adjacent pair of words in the input.
 * The bridge word between input words "w1" and "w2" will be some "b" such that
 * w1 -> b -> w2 is a two-edge-long path with maximum-weight weight among all
 * the two-edge-long paths from w1 to w2 in the affinity graph.
 * If there are no such paths, no bridge word is inserted.
 * In the output poem, input words retain their original case, while bridge
 * words are lower case. The whitespace between every word in the poem is a
 * single space.
 * 
 * <p>For example, given this corpus:
 * <pre>    This is a test of the Mugar Omni Theater sound system.    </pre>
 * <p>on this input:
 * <pre>    Test the system.    </pre>
 * <p>the output poem would be:
 * <pre>    Test of the system.    </pre>
 * 
 * <p>PS2 instructions: this is a required ADT class, and you MUST NOT weaken
 * the required specifications. However, you MAY strengthen the specifications
 * and you MAY add additional methods.
 * You MUST use Graph in your rep, but otherwise the implementation of this
 * class is up to you.
 */
public class GraphPoet {
    
    private final Graph<String> graph = Graph.empty();
    // Abstraction function:
    //AF(Graphvertex, Graphedges) client can get a graph from the class,
    //    for instance:
    /////////////////////////////////////////////////////////////////////
    //For example, given this corpus:
    //    <pre>    Hello, HELLO, hello, goodbye!    </pre>
    //    <p>the graph would contain two edges:
    //    <ul><li> ("hello,") -> ("hello,")   with weight 2
    //    <li> ("hello,") -> ("goodbye!") with weight 1 </ul>
    //    <p>where the vertices represent case-insensitive {@code "hello,"} and
    //    {@code "goodbye!"}.
    //    Testing Strategy
    //    poem();
    //    1. input is empty
    //    2. input is one word and txt contains it
    //    3. input is one word and txt doesn't contain it
    //    4. input is two words both in txt and can't be inserted
    //    5. input is two words both in txt and can be insert
    //    6. input is two words neither in txt
    //    7. input is two words both i txt and have uppercase
    //    8. input is two words neither in txt and have uppercase
    //    9. input is two words both in txt, can be insert and have uppercase
    //    10. there are one more path from source and target, one max-weight path
    //    11. there are one more path from source and target, two max-weight path
    ///////////////////////////////////////////////////////
    // Representation invariant: 
    //   vertices is a non-repeated set and the HashSet has satisfy it, 
    //       so it doesn't have limitation
    //       edges contains a list of Edge<L>, any two of it 
    //       are different(the definition of difference)
    //////////////////////////////////////////////////////////
    // Safety from rep exposure:  
    //    the vertices and edges are modified by "private final", 
    //    and I use Defensive copy to protect it
    //    in function which may return reps.
    //
    //////////////////////////////////////////////////////////
    
    /**
     * Create a new poet with the graph from corpus (as described above).
     * 
     * @param corpus text file from which to derive the poet's affinity graph
     * @throws IOException if the corpus file cannot be found or read
     */
    public GraphPoet(File corpus) throws IOException {
        List<String> list = new ArrayList<>();
        String lineString = new String();
        try {
        	FileReader coReader = new FileReader(corpus);
        	BufferedReader bfBufferedReader = new BufferedReader(coReader);
        	try {
        		while((lineString=bfBufferedReader.readLine())!=null) {
        			list.add(lineString);
        	}
        }catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		
	}
        String tmpString = new String();
       for(int i = 0; i < list.size(); i++) {
    	   
    	   String [] rowStrings = list.get(i).split(" ");
    	   String [] rowStrings1 = new String[rowStrings.length];
    	   for (int j = 0; j < rowStrings1.length; j++) {
			rowStrings1[j] = rowStrings[j].toLowerCase();
		}
    	   for(int j = 0; j < rowStrings1.length; j++) {   //rowStrings��ԭ����δ�ı��Сд�ģ�rowStrings��ȫ��תСд��
    		   if(j == rowStrings1.length - 1) {
        		   tmpString = rowStrings1[j];
        	   }
    		   else if(j == 0 && i != 0){
    			   if(!graph.targets(tmpString).containsKey(rowStrings1[j])) {
    				   graph.set(tmpString, rowStrings1[j], 1);
    			   }
    			   else {
    				   graph.set(tmpString, rowStrings1[j], 1+graph.targets(tmpString).get(rowStrings1[j]));
    			   }
        		   if(!graph.targets(rowStrings1[j]).containsKey(rowStrings1[j+1])) {
        			   graph.set(rowStrings1[j], rowStrings1[j+1], 1);
        		   }
        		   else {
        			   graph.set(rowStrings1[j], rowStrings1[j+1], 1+graph.targets(rowStrings1[j]).get(rowStrings1[j+1]));
        		   }
        	   }
    		   else{
    			   if(!graph.targets(rowStrings1[j]).containsKey(rowStrings1[j+1])) {
        			   graph.set(rowStrings1[j], rowStrings1[j+1], 1);
        		   }
    			   else {
    				   graph.set(rowStrings1[j], rowStrings1[j+1], 1+graph.targets(rowStrings1[j]).get(rowStrings1[j+1]));
    			   }
    		   }
    	   }
       }
       checkRep();
  }
//     TODO checkRep
    private void checkRep() { //checkRep����
		// TODO Auto-generated method stub
    	Set<String> set = graph.vertices();
    	String[] strings = new String[set.size()];
    	set.toArray(strings);
    	for(int i = 0; i < strings.length - 1; i++) {
    		for(int j = i+1; j < strings.length; j++) {
    			assert !strings[i].equals(strings[j]);
    		}
    	}
//    	List<String> list = new ArrayList<String>(graph.vertices());
//    	int size = list.size();
//       for(int i = 0; i < size-1; i++) {
//    	   for(int j = i+1 ; j < size; j++) {
//    		   assert !list.get(i).equals(list.get(j));
//    	   }
//       }
    	   
	}
    /**
     * Generate a poem.
     * 
     * @param input string from which to create the poem
     * @return poem (as described above)
     */
    public String poem(String input) {
        String ansString = new String();
        String[] splitString = input.split(" ");
        String[] splitString1 = new String[splitString.length];
        for(int i = 0; i < splitString.length; i++) {
        	splitString1[i] = splitString[i].toLowerCase();
        }
        for(int i = 0; i < splitString1.length; i++) {
//        	Queue<String> queue = new LinkedList<String>(); //��������������֮����û�б�ĵ���
//        	List<String> set = new ArrayList<String>(graph.targets(splitString[i]).keySet());
        	List<String> set1 = new ArrayList<String>(graph.targets(splitString1[i]).keySet());
        	int[] setsize = new int[set1.size()];
        	int j = 0;
        	for(; j < set1.size(); j++) {
        		setsize[j] = 100000;   //java�Ƿ����һ��ѭ�������������������ص��ڴ棿
        	}
        	for(j = 0; j < set1.size(); j++) {
        		for(String aString : set1) {
        			if(graph.targets(aString).containsKey(splitString1[i+1])) {
        				if(graph.targets(aString).get(splitString1[i+1]) != 0) {
                			setsize[j] = graph.targets(splitString1[i]).get(aString)+graph.targets(aString).get(splitString1[i+1]); //aString                   //����ҵ����м�㣬�ٰ��м���Ȩֵ�ĵ�
                		}
        			}
            	}
        	}
        	int min = 10000;
        	int flag = -1;
        	for(int k = 0; k < set1.size(); k++) {
        		if(setsize[k] < min) {
        			min = setsize[k];
        			flag = k;
        		}
        	}
        	if(min == 10000&&flag==-1) {
        		if(i < splitString.length - 1)
        		ansString = ansString + splitString[i] + " ";
        		else {
					ansString = ansString + splitString[i];
				}
        	}
        	else {
        		if(i < splitString.length - 1)
        		ansString = ansString + splitString[i] + " " +set1.get(flag)+ " ";
        		else {
					ansString = ansString + splitString[i];
				}
        	}
        	
        }
        checkRep();
        return ansString;
    }
   //  TODO toString()   //toStringд��
//    @Override
//    public String toString() { //toString����
//    	// TODO Auto-generated method stub  //toStringֱ�Ӱ����ͼ��ӡ���������Ǵ�ӡ�µ�ʫ
//    	String a0 = new String();
//    	for(String a1 : graph.vertices()) {
//    		a0 = a0+a1;
//    	}
//    	for(Edge k : edges) {
//    		a0 = a0+k.toString();
//    	}
//    	checkRep();
//    	return a0;
//    }
}
