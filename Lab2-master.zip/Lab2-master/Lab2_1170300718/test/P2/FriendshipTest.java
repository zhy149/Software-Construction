package P2;

import static org.junit.Assert.*;
import org.junit.Test;


public class FriendshipTest {
	@Test(expected = AssertionError.class)
	public void testAssertionsEnabled() {
		assert false;
	}
	Person a1 = new Person("A1");
	Person a2 = new Person("A2");
	Person a3 = new Person("A3");
	Person a4 = new Person("A1");
	Person a5 = new Person("A2");
	Person a6 = new Person("A3");
	FriendshipGraph g1 = new FriendshipGraph();
	FriendshipGraph g2 = new FriendshipGraph();
	@Test
	public void addVertexTest() {
		g1.addVertex(a1);
		g1.addVertex(a2);
		g1.addVertex(a3);
		g2.addVertex(a4);
		g2.addVertex(a5);
		g2.addVertex(a6);
		assertNotEquals(g1, g2);
	}
	@Test
	public void addEdgeTest() {
		g1.addVertex(a1);
		g1.addVertex(a2);
		g1.addVertex(a3);
		FriendshipGraph g2 = new FriendshipGraph();
		g2.addVertex(a1); //Ϊʲô����ط�������g2 = g1?
		g2.addVertex(a2);
		g2.addVertex(a3);
		g1.addEdge(a1, a2, 3);
		g2.addEdge(a3, a1, 5);
		assertNotEquals(g1, g2);
	}
	@Test
	public void getDistanceTest() {
		FriendshipGraph f1 = new FriendshipGraph();
		Person a1 = new Person("a1");
		Person a2 = new Person("a2");
		Person a3 = new Person("a3");
		Person a4 = new Person("a4");
		Person a5 = new Person("a5");
		Person a6 = new Person("a6");
		Person a7 = new Person("a7");
		Person a8 = new Person("a8");
		Person a9 = new Person("a9");
		Person a10 = new Person("a10");
		Person a11 = new Person("a11");
		Person a12 = new Person("a12");
		f1.addVertex(a1);
		f1.addVertex(a2);
		f1.addVertex(a3);
		f1.addVertex(a4);
		f1.addVertex(a5);
		f1.addVertex(a6);
		f1.addVertex(a7);
		f1.addVertex(a8);
		f1.addVertex(a9);
		f1.addVertex(a10);
		f1.addVertex(a11);
		f1.addVertex(a12);
		f1.addEdge(a11, a3, 1);
		f1.addEdge(a5, a3, 1);
		f1.addEdge(a2, a1, 1);
		f1.addEdge(a5, a7, 1);
		f1.addEdge(a7, a10, 1);
		f1.addEdge(a8, a6, 1);
		f1.addEdge(a9, a3, 1);
		f1.addEdge(a2, a12, 1);
		f1.addEdge(a7, a3, 1);
		assertEquals(1, f1.getDistance(a1,a2), 0);
		assertEquals(-1, f1.getDistance(a1,a10), 0);
		assertEquals(-1, f1.getDistance(a3,a8), 0);
		assertEquals(2, f1.getDistance(a10,a3), 0);
		assertEquals(3, f1.getDistance(a10,a11), 0);
		assertEquals(0, f1.getDistance(a5,a5), 0);
	}
}
