package P3;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * this class is a junit test class for the class Player
 *
 */
public class Playertest {

	Player p1 = new Player("nova",1);
	Player p2 = new Player("",0);
	@Test
	public void TestPlayerName() {
		assertEquals("nova", p1.getName());
		assertEquals("", p2.getName());
	}
	
	@Test
	public void TestPlayerNum() {
		assertEquals(1, p1.getNum());
		assertEquals(0, p2.getNum());
	}
	
	@Test
	public void TestPlayerIsequals() {
		assertFalse(p1.isEquals(p2));
		assertFalse(p2.isEquals(p1));
		Player p3 = new Player(p1);
		assertTrue(p1.isEquals(p3));
	}
	
}
