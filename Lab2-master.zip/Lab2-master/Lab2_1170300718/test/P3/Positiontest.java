package P3;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * this class is a junit test class for the class Position
 *
 */
public class Positiontest {

	Position p1 = new Position(0, 0);
	Player player = new Player("nova",0);
	Piece piece = new Piece(player,"w");
	@Test
	public void getXTest() {
		assertEquals(0, p1.getX());
	}
	
	@Test
	public void getYTest() {
		assertEquals(0, p1.getY());
	}
	
	@Test
	public void setPieceTest() {
		assertTrue(p1.setPiece(piece));
		assertFalse(p1.setPiece(piece));
	}
	
	@Test
	public void resetPieceTest() {
		assertFalse(p1.resetPiece());
		assertTrue(p1.setPiece(piece));
		assertTrue(p1.resetPiece());
	}

	@Test
	public void getPieceTest() {
		assertEquals(null,p1.getPiece());
		assertTrue(p1.setPiece(piece));
		assertEquals(piece,p1.getPiece());
	}
	
	@Test
	public void isEmptyTest() {
		assertTrue(p1.isEmpty());
		assertTrue(p1.setPiece(piece));
		assertFalse(p1.isEmpty());
	}
	
	@Test
	public void isEqualsTest() {
		Position p2 = new Position(0, 0);
		Position p3 = new Position(1, 0);
		Position p4 = new Position(0, 1);
		assertTrue(p1.isEquals(p2));
		assertFalse(p1.isEquals(p3));
		assertFalse(p1.isEquals(p4));
	}
	
	@Test
	public void isOutofBoundTest() {
		Position p2 = new Position(-1, -1);
		Position p3 = new Position(-1, 0);
		Position p4 = new Position(0, -1);
		Position p5 = new Position(5, 5);
		Position p6 = new Position(0, 5);
		assertFalse(p1.isOutofBound(5));
		assertTrue(p2.isOutofBound(5));
		assertTrue(p3.isOutofBound(5));
		assertTrue(p4.isOutofBound(5));
		assertTrue(p5.isOutofBound(5));
		assertTrue(p6.isOutofBound(5));
	}
}
