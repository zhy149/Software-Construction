package P3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class Gametest {

	Game game1 = new Game("Chess", "Nova", "dqs");
	Game game2 = new Game("Go", "Nova", "dqs");
	@Test
	public void testGame() {
		assertEquals("Nova", game1.getPlayer1().getName());
		assertEquals("dqs", game1.getPlayer2().getName());
//		Board b1 = game1.getBoard();
//		Action action1 = game1.getAction();
		assertEquals(16, (int)game1.getPlayerPiece().get(0));
		assertEquals(16, (int)game1.getPlayerPiece().get(1));
		game1.P1add("1");
		game1.P1add("2");
		game1.P1add("3");
		List<String> list = new ArrayList<String>();
		list.add("1");
		list.add("2");
		list.add("3");
		assertEquals(list, game1.getPlay1Path());
		game1.P2add("1");
		game1.P2add("2");
		game1.P2add("3");
		List<String> list2 = new ArrayList<String>();
		list2.add("1");
		list2.add("2");
		list2.add("3");
		assertEquals(list2, game1.getPlay2Path());
	}

}
