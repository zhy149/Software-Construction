package P3;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * this class is a junit test class for the class Piece
 *
 */
public class Piecetest {
	Player p = new Player("nova",0);
	Piece piece1 = new Piece(p,"w");
	Piece piece2 = new Piece(piece1);
	Piece piece3 = new Piece(new Player("nova",0),"");
	
	@Test
	public void getType() {
		assertEquals("w", piece1.getType());
		assertEquals("w", piece2.getType());
		assertEquals("", piece3.getType());
	}
	
	@Test
	public void getPlayer() {
		assertTrue(piece1.getPlayer().isEquals(p));
	}

}
