/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import static org.junit.Assert.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Tests for ConcreteVerticesGraph.
 * 
 * This class runs the GraphInstanceTest tests against ConcreteVerticesGraph, as
 * well as tests for that particular implementation.
 * 
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteVerticesGraphTest extends GraphInstanceTest {
    
    /*
     * Provide a ConcreteVerticesGraph for tests in GraphInstanceTest.
     */
    @Override public Graph<String> emptyInstance() {
        return new ConcreteVerticesGraph<String>();
    }
    
    /*
     * Testing ConcreteVerticesGraph...
     */
    @Test
    public void ConcreteVertexToStrig() {
		// TODO Auto-generated method stub
     ConcreteVerticesGraph<String> c1 = new ConcreteVerticesGraph<String>(); //��������м���㣿
     c1.set("a1", "a2", 1);
     c1.set("a2", "a3", 2);
     c1.set("a3", "a1", 3);
     String aString = "a1"+" "+"a2"+":"+"1"+"\n"+"a2"+" "+"a3"+":"+"2"+"\n"+
    		 "a3"+" "+"a1"+":"+"3"+"\n";
     assertEquals(aString, c1.toString());

	}
    // Testing strategy for ConcreteVerticesGraph.toString()
    //   TODO
    
    // TODO tests for ConcreteVerticesGraph.toString()
    
    /*
     * Testing Vertex...
     */
    @Test
    public void VertexToStrig() {
		// TODO Auto-generated method stub
     Vertex<String> a1 = new Vertex<String>("a1");
     Map<String, Integer> m1 = new HashMap<String, Integer>();
     m1.put("a2", 1);
     m1.put("a3", 2);
     m1.put("a4", 3);
     a1.putmapfrom(m1);
     String cmpString = "a1"+" "+"a2"+":"+"1"+"\n"+
     "a1"+" "+"a3"+":"+"2"+"\n"+"a1"+" "+"a4"+":"+"3"+"\n";
     assertEquals(cmpString, a1.toString());
	}
    @Test
    public void testVertexConstructandgetname() {
    	String a1 = "a1";
        Vertex<String> a2 = new Vertex<String>("a1");
        Vertex<String> a3 = new Vertex<String>("a2");
        assertEquals(a1, a2.getname());
        assertNotEquals(a1, a3.getname());
        assertNotEquals(a2.getname(), a3.getname());
    }
    @Test
    public void testVertexputgetmapfrom() {
    	Map<String, Integer> m1 = new HashMap<String, Integer>();
    	m1.put("a2", 1);
    	m1.put("a3", 2);
    	m1.put("a4", 3);
    	Vertex<String> a1 = new Vertex<String>("a1");
    	Map<String, Integer> m2 = new HashMap<String, Integer>();
    	m2.put("a3", 2);
    	m2.put("a4", 3);
    	m2.put("a2", 1);
    	a1.putmapfrom(m2);
    	assertEquals(m1, m2);
    	assertEquals(m1, a1.mapfrom());
    }
    @Test
    public void testVertexgetputmapto() {
    	Map<String, Integer> m1 = new HashMap<String, Integer>();
    	m1.put("a2", 1);
    	m1.put("a3", 2);
    	m1.put("a4", 3);
    	Vertex<String> a1 = new Vertex<String>("a1");
    	Map<String, Integer> m2 = new HashMap<String, Integer>();
    	m2.put("a3", 2);
    	m2.put("a4", 3);
    	m2.put("a2", 1);
    	a1.putmapto(m2);
    	assertEquals(m1, m2);
    	assertEquals(m1, a1.mapto());
    }
    // Testing strategy for Vertex
    //   TODO
    
    // TODO tests for operations of Vertex
    
}
