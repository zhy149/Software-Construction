/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.graph;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests for ConcreteEdgesGraph.
 * 
 * This class runs the GraphInstanceTest tests against ConcreteEdgesGraph, as
 * well as tests for that particular implementation.
 * 
 * Tests against the Graph spec should be in GraphInstanceTest.
 */
public class ConcreteEdgesGraphTest extends GraphInstanceTest {
    
    /*
     * Provide a ConcreteEdgesGraph for tests in GraphInstanceTest.
     */
    @Override public Graph<String> emptyInstance() {
        return new ConcreteEdgesGraph<String>();
    }
    
    /*
     * Testing ConcreteEdgesGraph...
     */
    
    // Testing strategy for ConcreteEdgesGraph.toString()
    //   TODO
    
    // TODO tests for ConcreteEdgesGraph.toString()
    @Test
    public void ConcreteEdgesGraph_toString(){
    	String a0 = "a1a2"+"a1 a2:1";
    	ConcreteEdgesGraph<String> a1 = new ConcreteEdgesGraph<String>();
    	a1.set("a1", "a2", 1);
    	assertEquals(a0, a1.toString());
    }
    /*
     * Testing Edge...
     */
    
    // Testing strategy for Edge
    //   TODO
    @Test
    public void Edgeconstructor() {
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals("a1", a1.getsource());
    	assertEquals("a2", a1.gettarget());
    	assertEquals(1, a1.getweight());
    }
    @Test
    public void changeweight() {
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals(1, a1.getweight());
    	a1.changeweight(2);
    	assertEquals(2, a1.getweight());
    }
    @Test
    public void getsource() {
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals("a1", a1.getsource());
    }
    @Test
    public void gettarget() {
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals("a2", a1.gettarget());
    }
    @Test
    public void getweight() {
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals(1, a1.getweight());
    }
    @Test
    public void EdgetoString() {
    	String a0 = "a1 a2:1";
    	Edge<String> a1 = new Edge<String>("a1", "a2", 1);
    	assertEquals(a0, a1.toString());
    }
    // TODO tests for operations of Edge
    
}
