/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P1.poet;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest {
    
    // Testing strategy
    //   TODO
    
    @Test(expected=AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }
    @Test
    public void test() {
    	try {
    		final GraphPoet nimoy = new GraphPoet(new File("src/P1/poet/mugar-omni-theater.txt"));
    	    final String input = "Test the Omni fuk system";
            System.out.println(input + "\n>>>\n" + nimoy.poem(input));
            assertEquals("Test of the mugar Omni this fuk system", nimoy.poem(input));
		} catch (Exception e) {
			// TODO: handle exception
		}
    	try {
    		final GraphPoet nimoy = new GraphPoet(new File("src/P1/poet/mugar-omni-theater.txt"));
    	    final String input = "Test the Omni fuck system";
            System.out.println(input + "\n>>>\n" + nimoy.poem(input));
            assertEquals("Test of the mugar Omni fuck system", nimoy.poem(input));
		} catch (Exception e) {
			// TODO: handle exception
		}
    	try {
    		final GraphPoet nimoy = new GraphPoet(new File("src/P1/poet/mugar-omni-theater.txt"));
    	    final String input = "Test the Omni fuck system";
            System.out.println(input + "\n>>>\n" + nimoy.poem(input));
            assertEquals("Test of the mugar Omni fuck system", nimoy.poem(input));
		} catch (Exception e) {
			// TODO: handle exception
		}
    }

    
    // TODO tests
    
}
