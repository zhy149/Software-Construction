package centralObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class NucleusTest extends CentralObjectTest{

    @Test
    public void nucleusTest() {
        Nucleus nu = new Nucleus("Zn");
        assertEquals("Nucleus [getName()=Zn]", nu.toString());
    }

    @Override
    public CentralObject getInstance(String name) {
        Nucleus nu = new Nucleus(name);
        return nu;
    }

}
