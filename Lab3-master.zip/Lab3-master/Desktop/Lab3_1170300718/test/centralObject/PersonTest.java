package centralObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")
public class PersonTest extends CentralObjectTest{

    @Override
    public CentralObject getInstance(String name) {
        Person p = new Person(name); 
        return p;
    }

}
