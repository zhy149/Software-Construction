package centralObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public abstract class CentralObjectTest {

    public abstract CentralObject getInstance(String name);
    
    @Test
    public void getNameTest() {
        CentralObject co = getInstance("good");
        assertEquals("good", co.getName());
    }

}
