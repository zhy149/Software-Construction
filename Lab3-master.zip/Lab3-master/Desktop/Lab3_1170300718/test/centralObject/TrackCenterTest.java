package centralObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")
public class TrackCenterTest extends CentralObjectTest {

    @Override
    public CentralObject getInstance(String name) {
        TrackCenter tc = new TrackCenter(name);
        return tc;
    }

}
