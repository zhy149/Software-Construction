package track;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TrackTest {

    @Test
    public void getRadiusTest() {
        Track<String> ts = new Track<String>(4);
        assertEquals(4, ts.getRadius());
    }

    @Test
    public void getObjectsTest() {
        Track<String> ts = new Track<String>(4);
        assertEquals(0, ts.getObjects().size());
    }
    
    @Test
    public void numberOfObjectsTest() {
        Track<String> ts = new Track<String>(4);
        assertEquals(0, ts.numberOfObjects());
    }
    
    @Test
    public void addObjectTest() {
        Track<String> ts = new Track<String>(4);
        ts.addObject("good");
        assertEquals(1, ts.numberOfObjects());
        ts.addObject("res");
        assertEquals(2, ts.numberOfObjects());
    }
    
    @Test
    public void removeObjectTest() {
        Track<String> ts = new Track<String>(4);
        ts.addObject("good");
        ts.addObject("res");
        ts.removeObject("good");
        assertEquals(1, ts.numberOfObjects());
        ts.removeObject("res");
        assertEquals(0, ts.numberOfObjects());
    }
    
    @Test
    public void toStringTest() {
        Track<String> ts = new Track<String>(4);
        ts.addObject("good");
        ts.addObject("res");
        assertEquals("Track [radius=4]", ts.toString());
    }
}
