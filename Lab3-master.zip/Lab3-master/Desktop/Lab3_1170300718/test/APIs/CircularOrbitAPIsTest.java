package APIs;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import circularOrbit.AtomStructure;
import circularOrbit.PersonalAppEcosystem;
import physicalObject.App;
import physicalObject.Electron;

public class CircularOrbitAPIsTest {

    @Test
    public void getObjectDistributionEntropyTest() throws IOException {
        AtomStructure a1 = new AtomStructure(), a2 = new AtomStructure();
        a1.build("src/creator/AtomicStructure.txt");
        a2.build("src/creator/AtomicStructure_Medium.txt");
        double e1 = CircularOrbitAPIs.getObjectDistributionEntropy(a1);
        double e2 = CircularOrbitAPIs.getObjectDistributionEntropy(a2);
        assertTrue(e1 > e2);
    }

    @Test
    public void getLogicalDistanceTest() throws IOException {
        PersonalAppEcosystem game = new PersonalAppEcosystem();
        game.build("src/creator/PersonalAppEcosystem.txt");
        int dis = CircularOrbitAPIs.getLogicalDistance(game, game.getAppByName("QQ"), game.getAppByName("Eleme"));
        assertEquals(2, dis);
    }

    @Test
    public void getPhysicalDistanceTest() throws IOException {
        PersonalAppEcosystem game = new PersonalAppEcosystem();
        game.build("src/creator/PersonalAppEcosystem.txt");
        App weibo = game.getAppByName("Weibo");
        App didi = game.getAppByName("Didi");
        weibo.setSita(0);
        didi.setSita(0);
        double dis = CircularOrbitAPIs.getPhysicalDistance(game, didi, weibo);
        assertEquals(0, dis, 0.01);
    }

    @Test
    public void getDifferenceTest() throws IOException {
        AtomStructure a1 = new AtomStructure(), a2 = new AtomStructure();
        a1.build("src/creator/AtomicStructure.txt");
        a2.build("src/creator/AtomicStructure_Medium.txt");
        Difference<Electron> difference = CircularOrbitAPIs.getDifference(a1, a2);
        assertEquals(1, difference.getDiffTrackNumbers());
    }
}
