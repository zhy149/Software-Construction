package APIs;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import circularOrbit.AtomStructure;

public class DifferenceTest {

    @Test
    public void diffTrackNumbersTest() {
        Difference<AtomStructure> dif = new Difference<>();
        dif.setDiffTrackNumbers(0);
        assertEquals(0, dif.getDiffTrackNumbers());
    }
    
    @Test
    public void diffTrackObjectNumberTest() {
        Difference<AtomStructure> dif = new Difference<>();
        dif.setDiffTrackObjectNumber(3);
        dif.setDiffTrackObjectNumber(4);
        assertEquals(3, dif.getDiffTrackObjectNumber().get(0).intValue());
        assertEquals(4, dif.getDiffTrackObjectNumber().get(1).intValue());
        
    }
    
    @Test
    public void diffObjectsTest() {
        Difference<AtomStructure> dif = new Difference<>();
        Set<AtomStructure> sA = new HashSet<AtomStructure>(),
                           sB = new HashSet<AtomStructure>();
        dif.setDiffObjects(sA, sB);
        List<DiffOfObject<AtomStructure>> ls = dif.getDiffObjects();
        assertEquals(1, ls.size());
    }

}
