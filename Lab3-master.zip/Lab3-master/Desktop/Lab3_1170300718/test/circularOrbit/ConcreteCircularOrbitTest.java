package circularOrbit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public abstract class ConcreteCircularOrbitTest {

    public abstract <L, E> ConcreteCircularOrbit<L, E> getInstance();
    
    @Test
    public <L, E> void getNumberOfTracksTest() {
        ConcreteCircularOrbit<L, E> cc = getInstance();
        assertEquals(0, cc.getNumberOfTracks());
    }
    
    @Test
    public <L, E> void setNumberOfTracks() {
        ConcreteCircularOrbit<L, E> cc = getInstance();
        cc.setNumberOfTracks(3);
        assertEquals(3, cc.getNumberOfTracks());
    }
    
    @Test
    public <L, E> void addTrackTest() {
        CircularOrbit<L, E> cc = getInstance();
        assertTrue(cc.addTrack(3));
        assertFalse(cc.addTrack(3));
    }
    
    @Test
    public <L, E> void getTrackTest() {
        CircularOrbit<L, E> cc = getInstance();
        cc.addTrack(3);
        assertEquals(3, cc.getTrack(3).getRadius());
    }

    @Test
    public <L, E> void removeTrackTest() {
        CircularOrbit<L, E> cc = getInstance();
        cc.addTrack(3);
        cc.addTrack(5);
        cc.removeTrack(3);
        assertEquals(null, cc.getTrack(3));
        assertEquals(1, cc.getTracks().size());
    }
    
    @Test
    public <L, E> void centerTest() {
        CircularOrbit<L, E> cc = getInstance();
        cc.setCenter(null);
        assertEquals(null, cc.getCenter());
    }
    
    @Test
    public <L, E> void addObjectTest() {
        CircularOrbit<L, E> cc = getInstance();
        cc.addObject(null);
        assertEquals(1, cc.getObjects().size());
    }
    
}
