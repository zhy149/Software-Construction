package circularOrbit;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

public class AtomStructureTest extends ConcreteCircularOrbitTest{

    @SuppressWarnings("unchecked")
    @Override
    public <L, E> ConcreteCircularOrbit<L, E> getInstance() {
        return (ConcreteCircularOrbit<L, E>) new AtomStructure();
    }

    @Test
    public void atomStructureTest() throws IOException {
        AtomStructure as = new AtomStructure();
        as.build("src/creator/AtomicStructure.txt");
        assertTrue(as.transition(as.getTrack(1), as.getTrack(3)));
        assertTrue(as.transition(as.getTrack(1), as.getTrack(3)));
        assertFalse(as.transition(as.getTrack(1), as.getTrack(3)));
    }

}
