package circularOrbit;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

public class PersonalAppEcosystemTest extends ConcreteCircularOrbitTest {

    @SuppressWarnings("unchecked")
    @Override
    public <L, E> ConcreteCircularOrbit<L, E> getInstance() {
        return (ConcreteCircularOrbit<L, E>) new PersonalAppEcosystem();
    }
    
    @Test
    public void paeTest() throws IOException {
        PersonalAppEcosystem pae = new PersonalAppEcosystem();
        pae.build("src/creator/PersonalAppEcosystem.txt");
        assertEquals("Wechat", pae.getAppByName("Wechat").getName());
        assertEquals(null, pae.getAppByName("PS"));
    }

}
