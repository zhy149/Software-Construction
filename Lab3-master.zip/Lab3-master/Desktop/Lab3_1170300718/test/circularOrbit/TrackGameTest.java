package circularOrbit;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import physicalObject.Athlete;
import track.Track;

public class TrackGameTest extends ConcreteCircularOrbitTest {

    @SuppressWarnings("unchecked")
    @Override
    public <L, E> ConcreteCircularOrbit<L, E> getInstance() {
        return (ConcreteCircularOrbit<L, E>) new TrackGame();
    }
    
    @Test
    public void tgTest() throws IOException {
        TrackGame tg = new TrackGame();
        tg.build("src/creator/TrackGame.txt");
        tg.getOrderByGrade();
        tg.getOrderRandomly();
        Athlete a1 = tg.getAthleteByName("Tommy");
        Athlete a2 = tg.getAthleteByName("Cliton");
        assertTrue(a1 != null);
        assertTrue(a2 != null);
        assertEquals(null, tg.getAthleteByName("lili"));
        
        int g1 = a1.getGroupOrder();
        int g2 = a2.getGroupOrder();
        tg.exchangeGroup(a1, a2);
        assertEquals(g2, a1.getGroupOrder());
        assertEquals(g1, a2.getGroupOrder());
        
        @SuppressWarnings("unchecked")
        Track<Athlete> t1 = (Track<Athlete>) a1.getTrack();
        @SuppressWarnings("unchecked")
        Track<Athlete> t2 = (Track<Athlete>) a2.getTrack();
        tg.exchangeTrack(a1, a2);
        assertFalse(t1 == t2);
    }

}
