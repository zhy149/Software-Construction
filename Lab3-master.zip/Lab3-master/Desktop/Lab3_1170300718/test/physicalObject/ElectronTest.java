package physicalObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import track.Track;

public class ElectronTest extends PhysicalObjectTest {

    @Override
    public PhysicalObject getInstance(String name) {
        Electron ele = new Electron();
        return ele;
    }

    @Override @Test
    public void setTrackTest() {
        Electron ele = new Electron();
        ele.setTrack(new Track<Electron>(4));
        assertEquals(4, ele.getTrack().getRadius());
    }
    
}
