package physicalObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import track.Track;

public class AppTest extends PhysicalObjectTest {

    @Override
    public PhysicalObject getInstance(String name) {
        App app = new App(name, "1", "2", "3", "4");
        return app;
    }

    @Override @Test
    public void setTrackTest() {
        App app = new App("0", "1", "2", "3", "4");
        app.setTrack(new Track<App>(2));
        assertEquals(2, app.getTrack().getRadius());
    }

    @Test
    public void getTest() {
        App app = new App("0", "1", "2", "3", "4");
        assertEquals("1", app.getCompany());
        assertEquals("2", app.getVersion());
        assertEquals("3", app.getDescription());
        assertEquals("4", app.getField());
        assertEquals(-1, app.getCloseRate());
    }
    
    @Test
    public void addTest() {
        App app = new App("0", "1", "2", "3", "4");
        assertTrue(app.addInstallLog(""));
        assertTrue(app.addUninstallLog(""));
        assertTrue(app.addUsageLog(""));
    }
    
    @Test
    public void calculateTest() {
        App app = new App("0", "1", "2", "3", "4");
        app.addUsageLog("2019-01-01,15:00:00,Wechat,2");
        app.addUsageLog("2019-01-02,15:30:00,Wechat,1");
        app.addUsageLog("2019-02-02,15:30:00,Wechat,1");
        app.calculateCloseRate("Month", "2019-01-01,15:00:00,Wechat,2");
        assertEquals(2 * (2 + 1), app.getCloseRate());
        app.calculateCloseRate("Week", "2019-01-01,15:00:00,Wechat,2");
        assertEquals(2 * (2 + 1), app.getCloseRate());
        app.calculateCloseRate("Day", "2019-01-01,15:00:00,Wechat,2");
        assertEquals(1 * 2, app.getCloseRate());
        app.calculateCloseRate("Hour", "2019-01-01,15:00:00,Wechat,2");
        assertEquals(1 * 2, app.getCloseRate());
    }
}
