package physicalObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import track.Track;

public class AthleteTest extends PhysicalObjectTest{

    @Override
    public PhysicalObject getInstance(String name) {
        Athlete at = new Athlete(name, 0, "", 0, 0);
        return at;
    }

    @Override @Test
    public void setTrackTest() {
        Athlete at = new Athlete("0", 1, "2", 3, 4);
        at.setTrack(new Track<Athlete>(5));
        assertEquals(5, at.getTrack().getRadius());
    }
    
    @Test
    public void getTest() {
        Athlete at = new Athlete("0", 1, "2", 3, 4);
        assertEquals(1, at.getNumber());
        assertEquals("2", at.getNationality());
        assertEquals(3, at.getAge());
        assertEquals(4, at.getScore());
        at.setGroupOrder(99);
        assertEquals(99, at.getGroupOrder());
    }
    
    @Test
    public void toStringTest() {
        Athlete at = new Athlete("0", 1, "2", 3, 4);
        assertEquals("Athlete [name=0, number=1, nationality=2, age=3, score=4.0]", at.toString());
    }

}
