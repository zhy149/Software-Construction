package physicalObject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public abstract class PhysicalObjectTest {

    public abstract PhysicalObject getInstance(String name);
    
    @Test
    public void getNameTest() {
        PhysicalObject ph = getInstance("good");
        if (ph instanceof Electron)
            assertEquals("electron", ph.getName());
        else
            assertEquals("good", ph.getName());
    }
    
    @Test
    public void getTrackTest() {
        PhysicalObject ph = getInstance("good");
        assertEquals(null, ph.getTrack());
    }
    
    @Test
    public abstract void setTrackTest();
    
    @Test
    public void getSitaTest() {
        PhysicalObject ph = getInstance("good");
        assertEquals(0, ph.getSita());
    }
    
    @Test
    public void setSitaTest() {
        PhysicalObject ph = getInstance("good");
        ph.setSita(5);
        assertEquals(5, ph.getSita());
    }

}
