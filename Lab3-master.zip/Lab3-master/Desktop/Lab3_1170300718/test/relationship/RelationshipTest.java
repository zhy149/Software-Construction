package relationship;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class RelationshipTest {

    @Test
    public void relTest() {
        Relationship<String, String> rs = new Relationship<String, String>("obj1", "obj2");
        assertEquals("obj1", rs.getObject1());
        assertEquals("obj2", rs.getObject2());
    }

}
