package applications;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")
public class MainTest {

    @Test
    public void test() throws IOException {
        Main.main(new String[1]);
        // 需要使用命令行进行测试
    }

}
