package circularOrbit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import centralObject.Nucleus;
import physicalObject.Electron;
import track.Track;

public class AtomStructure extends ConcreteCircularOrbit<Nucleus, Electron> {

    /**
     * Create an instance of AtomStructure
     */
    public AtomStructure() {
        super();
    }

    /* 关联电子和轨道 */
    private void setTrack(Electron electron, int radius) {
        Track<Electron> track = getTrack(radius);
        electron.setTrack(track);
        track.addObject(electron);
    }

    @Override
    public void build(String fileAddress) throws IOException {

        File file = new File(fileAddress);
//      File file1 = new File("src/creator/AtomicStructure.txt");
//      File file2 = new File("src/creator/AtomicStructure_Medium.txt");
        BufferedReader reader = new BufferedReader(new FileReader(file));

        String tempString = null;
        String[] infoOfElectron = null;
        Pattern namePattern = Pattern.compile("(?<=(ElementName ::= ))[A-Z][a-z]?");
        Pattern trackPattern = Pattern.compile("(?<=(NumberOfTracks ::= ))[1-9]");
        Pattern electronPattern = Pattern.compile("(?<=(NumberOfElectron ::= ))([1-9]/[1-9]{1,2};?)+");

        while ((tempString = reader.readLine()) != null) {
            Matcher nameMatcher = namePattern.matcher(tempString);
            if (nameMatcher.find()) {
                int start = nameMatcher.start();
                int end = nameMatcher.end();
                String name = tempString.substring(start, end);
                this.setCenter(new Nucleus(name));
                System.out.println(name);
            }

            Matcher trackMatcher = trackPattern.matcher(tempString);
            if (trackMatcher.find()) {
                int start = trackMatcher.start();
                int end = trackMatcher.end();
                setNumberOfTracks(Integer.parseInt(tempString.substring(start, end)));
                System.out.println(getNumberOfTracks());
            }

            Matcher electronMatcher = electronPattern.matcher(tempString);
            if (electronMatcher.find()) {
                int start = electronMatcher.start();
                int end = electronMatcher.end();
                String result = tempString.substring(start, end);
                System.out.println(result);
                infoOfElectron = result.split(";");
            }
        }
        reader.close();

        for (int i = 1; i <= getNumberOfTracks(); i++) {
            addTrack(i);
        }
        for (int i = 0; i < infoOfElectron.length; i++) {
            String[] tracksOfElectron = infoOfElectron[i].split("/");
            int IdOfTrack = Integer.parseInt(tracksOfElectron[0]);
            int numOfElectron = Integer.parseInt(tracksOfElectron[1]);
            for (int j = 0; j < numOfElectron; j++) {
                Electron e = new Electron();
                setTrack(e, IdOfTrack);
                addObject(e);
            }
        }
    }
    
    /**
     * 模拟电子跃迁
     * @param source 源轨道
     * @param target 目标轨道
     * @return 如果操作成功返回true，否则返回false
     */
    public boolean transition(Track<Electron> source, Track<Electron> target) {
        List<Electron> eles = getObjects();
        for (Electron e : eles) {
            if (e.getTrack().equals(source)) {
                e.setTrack(target);
                source.removeObject(e);
                target.addObject(e);
                printResult();
                return true;
            }
        }
        return false;
    }
    
    private void printResult() {
        List<Track<Electron>> tracks = getTracks();
        for (Track<Electron> t : tracks) {
            System.out.println(t + " [objectNumber " + t.numberOfObjects() + "]");
        } 
    }

//    public static void main(String[] args) throws IOException {
//        AtomStructure raa = new AtomStructure();
//        raa.build("src/creator/AtomicStructure.txt");
//        raa.transition(raa.getTrack(2), raa.getTrack(3));
//    }

}
