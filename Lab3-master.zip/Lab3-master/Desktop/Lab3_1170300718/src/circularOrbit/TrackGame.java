package circularOrbit;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import centralObject.TrackCenter;
import physicalObject.Athlete;
import physicalObject.Electron;
import physicalObject.PhysicalObject;
import track.Track;

@SuppressWarnings("unused")
public class TrackGame extends ConcreteCircularOrbit<TrackCenter, Athlete>{
    
    private String game;
    
    // Abstraction function:
    //   AF(game) = a track game
    // Representation invariant:
    //   game never changes
    // Safety from rep exposure:
    //   String is private and immutable

    /**
     * Create an instance of TrackGame
     */
    public TrackGame() {
        super();
        this.setCenter(null);
    }
    
    /* 关联运动员和赛道 */
    private void setTrack(Athlete athlete, int radius) {
        Track<Athlete> track = getTrack(radius);
        athlete.setTrack(track);
        track.addObject(athlete);
    }
    
    @Override public void build(String fileAddress) throws IOException {
        
        File file = new File(fileAddress);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        
        String tempString = null;
        Pattern gamePattern = Pattern.compile("(?<=(Game ::= ))[1|2|4]00");
        Pattern numberPattern = Pattern.compile("(?<=(NumOfTracks ::= ))[0-9]{1,2}");
        Pattern athletePattern = Pattern.compile("(?<=(Athlete ::= <))" + 
                "[a-zA-Z]+,[0-9]{1,3},[A-Z]{3},[0-9]{1,2},[0-9]{1,2}.[0-9]{2}>");
        
        while ((tempString = reader.readLine()) != null) {
            Matcher gameMatcher = gamePattern.matcher(tempString);
            if (gameMatcher.find()) {
                int start = gameMatcher.start();
                int end = gameMatcher.end();
                game = tempString.substring(start, end);
//                System.out.println(game);
            }
            
            Matcher numberMatcher = numberPattern.matcher(tempString);
            if (numberMatcher.find()) {
                int start = numberMatcher.start();
                int end = numberMatcher.end();
                setNumberOfTracks(Integer.parseInt(tempString.substring(start, end)));
//                System.out.println(getNumberOfTracks());
            }
            
            Matcher athleteMatcher = athletePattern.matcher(tempString);
            if (athleteMatcher.find()) {
                int start = athleteMatcher.start();
                int end = athleteMatcher.end() - 1;
                String result = tempString.substring(start, end);
                String[] info = result.split(",");
                Athlete athlete = new Athlete(info[0], Integer.parseInt(info[1]), 
                        info[2], Integer.parseInt(info[3]), Double.parseDouble(info[4]));
                addObject(athlete);
            }
        }
        reader.close();
        
        // 建立轨道
        for (int i = 1; i <= getNumberOfTracks(); i++) {
            addTrack(i);
        }
    }
    
    /**
     * 对数组随机排序，并进行分组及场地安排
     */
    public void getOrderRandomly() {
        List<Athlete> athletes = getObjects();
        double[] randoms = new double[athletes.size()];
        for (int i = 0; i < athletes.size(); i++)
            randoms[i] = Math.random();

        // 进行排序
        for (int i = 0; i < athletes.size(); i++) {
            int k = i;
            for (int j = i+1; j < athletes.size(); j++) {
                if (randoms[j] < randoms[k])
                    k = j;
            }
            if (k != i) {
                Athlete tempA = athletes.get(k);
                athletes.set(k, athletes.get(i));
                athletes.set(i, tempA);
                double tempD = randoms[k];
                randoms[k] = randoms[i];
                randoms[i] = tempD;
            }
        }
//        for (Athlete athlete : athletes) {
//            System.out.println(randoms[athletes.indexOf(athlete)]);
//        }
            
        // 分配跑道
        for (int i = 0; i < athletes.size(); i++) {
            Athlete athlete = athletes.get(i);
            athlete.setGroupOrder(i / getNumberOfTracks() + 1);
            setTrack(athlete, i % getNumberOfTracks() + 1);
        }
        
        printSortingResult();
    }
    
    /**
     * 按照成绩的顺序对选手进行排列，从而进行场地安排
     */
    public void getOrderByGrade() {
        List<Athlete> athletes = getObjects();
        double[] grades = new double[athletes.size()];
        for (int i = 0; i < athletes.size(); i++)
            grades[i] = athletes.get(i).getScore();
        
        // 进行排序
        Comparator<Athlete> c = new Comparator<Athlete>() {
            @Override public int compare(Athlete o1, Athlete o2) {
                if (o1.getScore() < o2.getScore())
                    return -1;
                return 1;
            }
        };
        athletes.sort(c);
        
        // 进行分组
        int groupId = 0;
        for (int i = 0; i < athletes.size(); i++) {
            if (i % getNumberOfTracks() == 0)
                groupId++;
            athletes.get(i).setGroupOrder(groupId);
        }
        // 分配跑道
        for (int i = 1; i <= groupId; i++) {
            List<Athlete> as = new ArrayList<>();
            for (Athlete athlete : athletes) {
                if (athlete.getGroupOrder() == i)
                    as.add(athlete);
            }
            int k = 0;
            if (getNumberOfTracks() % 2 == 0) {
                for (int j = getNumberOfTracks() / 2; j >= 1; j--) {
                    if (k < as.size())
                        setTrack(as.get(k), j);
                    if (k + 1 < as.size())
                        setTrack(as.get(k+1), getNumberOfTracks()-j);
                    k += 2;
                }
            } else {
                setTrack(as.get(k), getNumberOfTracks() / 2 + 1);
                k++;
                for (int j = getNumberOfTracks() / 2; j >= 1; j--) {
                    if (k < as.size())
                        setTrack(as.get(k), j);
                    if (k + 1 < as.size())
                        setTrack(as.get(k+1), getNumberOfTracks()+1-j);
                    k += 2;
                }
            }
        }
        
        printSortingResult();
    }
    
    private void printSortingResult() {
        List<Athlete> as = getObjects();
        for (Athlete a : as) {
            System.out.println(a.getName() + " " + "Grade [" + a.getScore() + 
                    "] GroupOrder [" + a.getGroupOrder() + "] " + a.getTrack());
        } 
    }
    
    
    /**
     * 为两个运动员更换赛道
     * @param a 第一个运动员
     * @param b 第二个运动员
     */
    public void exchangeTrack(Athlete a, Athlete b) {
        if (a == null || b == null) {
            return;
        }
        Track<Athlete> trackA = null;
        Track<Athlete> trackB = null;
        List<Track<Athlete>> tracks = super.getTracks();
        for (Track<Athlete> track : tracks) {
            if (track.getObjects().contains(a))
                trackA = track;
            if (track.getObjects().contains(b))
                trackB = track;
        }
        trackA.removeObject(a);
        trackB.removeObject(b);
        a.setTrack(trackB);
        b.setTrack(trackA);
        trackA.addObject(b);
        trackB.addObject(a);
        printSortingResult();
    }
    
    /**
     * 为两运动员更换分组
     * @param a 第一个运动员
     * @param b 第二个运动员
     */
    public void exchangeGroup(Athlete a, Athlete b) {
        if (a == null || b == null) {
            return;
        }
        int groupIdA = a.getGroupOrder();
        a.setGroupOrder(b.getGroupOrder());
        b.setGroupOrder(groupIdA);
        printSortingResult();
    }
    
    /**
     * 通过名字寻找运动员对象
     * @param name 名字
     * @return 运动员对象
     */
    public Athlete getAthleteByName(String name) {
        List<Athlete> as = getObjects();
        for (Athlete a : as) {
            if (a.getName().equals(name))
                return a;
        }
        return null;
    }
    
//    public static void main(String[] args) throws IOException {
//        TrackGame raa = new TrackGame();
//        raa.build("src/creator/TrackGame.txt");
//        raa.getOrderRandomly();
//    }
}
