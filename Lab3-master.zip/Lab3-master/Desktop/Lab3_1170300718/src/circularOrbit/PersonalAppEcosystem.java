package circularOrbit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import centralObject.Person;
import physicalObject.App;
import relationship.Relationship;
import track.Track;

public class PersonalAppEcosystem extends ConcreteCircularOrbit<Person, App> {

//    private final List<Relationship<String, String>> rels = new ArrayList<>();
    private final List<String> installLogs = new ArrayList<String>();
    private final List<String> uninstallLogs = new ArrayList<String>();
    private final List<String> usageLogs = new ArrayList<String>();
    private String period = null;
    
    // Abstraction function:
    //   AF(rels, logs, period) = a personal app ecosystem
    // Representation invariant:
    //   all fields never change.
    // Safety from rep exposure:
    //   All fields are private;
    //   String is immutable.
    //   list is mutable.
    
    /**
     * Create an instance of PersonalAppEcosystem
     */
    public PersonalAppEcosystem() {
        super();
    }

    /* 关联软件和轨道 */
    private void setTrack(App app, int radius) {
        Track<App> track = getTrack(radius);
        app.setTrack(track);
        track.addObject(app);
    }
    
    @Override public void build(String fileAddress) throws IOException {
        File file = new File(fileAddress);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        
        /* patterns */
        Pattern usernamePattern = Pattern.compile("(?<=(User ::= ))[A-Za-z0-9]+");
        
        String[] infoOfApp = null;
        Pattern appPattern = Pattern.compile("(?<=(App ::= <))[A-Za-z0-9]+,[A-Za-z0-9]+," + 
        "[A-Za-z0-9.\\-_]+,\"[A-Za-z0-9 ]+\",\"[A-Za-z0-9 ]+\"");
        
        Pattern installLogPattern = Pattern.compile("(?<=(InstallLog ::= <))" + 
        "[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{2}:[0-9]{2}:[0-9]{2},[A-Za-z0-9]+");
        
        Pattern usageLogPattern = Pattern.compile("(?<=(UsageLog ::= <))" + 
        "[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{2}:[0-9]{2}:[0-9]{2},[A-Za-z0-9]+,[0-9]{1,5}");
        
        Pattern uninstallLogPattern = Pattern.compile("(?<=(UninstallLog ::= <))" + 
        "[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{2}:[0-9]{2}:[0-9]{2},[A-Za-z0-9]+");
        
        String[] infoOfRelation = null;
        Pattern relationPattern = Pattern.compile("(?<=(Relation ::= <))[A-Za-z0-9]+,[A-Za-z0-9]+");
        
        Pattern periodPattern = Pattern.compile("(?<=(Period ::= ))(Hour)|(Day)|(Week)|(Month)");

        /* read files */
        String tempString = null;
        while ((tempString = reader.readLine()) != null) {
            Matcher nameMatcher = usernamePattern.matcher(tempString);
            if (nameMatcher.find()) {
                int start = nameMatcher.start();
                int end = nameMatcher.end();
                String name = tempString.substring(start, end);
                this.setCenter(new Person(name));
//                System.out.println(name);
            }

            Matcher appMatcher = appPattern.matcher(tempString);
            if (appMatcher.find()) {
                int start = appMatcher.start();
                int end = appMatcher.end();
                String result = tempString.substring(start, end);
//                System.out.println(result);
                infoOfApp = result.split(",");
                App app = new App(infoOfApp[0], infoOfApp[1], infoOfApp[2], infoOfApp[3], infoOfApp[4]);
                addObject(app);
            }
            
            Matcher installLogMatcher = installLogPattern.matcher(tempString);
            if (installLogMatcher.find()) {
                int start = installLogMatcher.start();
                int end = installLogMatcher.end();
                String result = tempString.substring(start, end);
//                System.out.println(result);
                installLogs.add(result);
            }
            
            Matcher uninstallLogMatcher = uninstallLogPattern.matcher(tempString);
            if (uninstallLogMatcher.find()) {
                int start = uninstallLogMatcher.start();
                int end = uninstallLogMatcher.end();
                String result = tempString.substring(start, end);
//                System.out.println(result);
                uninstallLogs.add(result);
            }
            
            Matcher usageLogMatcher = usageLogPattern.matcher(tempString);
            if (usageLogMatcher.find()) {
                int start = usageLogMatcher.start();
                int end = usageLogMatcher.end();
                String result = tempString.substring(start, end);
//                System.out.println(result);
                usageLogs.add(result);
            }
            
            Matcher relationMatcher = relationPattern.matcher(tempString);
            if (relationMatcher.find()) {
                int start = relationMatcher.start();
                int end = relationMatcher.end();
                String result = tempString.substring(start, end);
//                System.out.println(result);
                infoOfRelation = result.split(",");
                Relationship<String, String> rel = 
                        new Relationship<>(infoOfRelation[0], infoOfRelation[1]);
                rels.add(rel);
            }
            
            Matcher periodMatcher = periodPattern.matcher(tempString);
            if (periodMatcher.find()) {
                int start = periodMatcher.start();
                int end = periodMatcher.end();
                period = tempString.substring(start, end);
//                System.out.println(period);
            }
        }
        reader.close();

        /* set logs */
        List<App> apps = getObjects();
        String[] infoOfLogs = null;
        for (String s : installLogs) {
            infoOfLogs = s.split(",");
            for (App app : apps) {
                if (app.getName().equals(infoOfLogs[2])) {
                    app.addInstallLog(s);
                }
            }
        }
        for (String s : uninstallLogs) {
            infoOfLogs = s.split(",");
            for (App app : apps) {
                if (app.getName().equals(infoOfLogs[2])) {
                    app.addUninstallLog(s);
                }
            }
        }
        for (String s : usageLogs) {
            infoOfLogs = s.split(",");
            for (App app : apps) {
                if (app.getName().equals(infoOfLogs[2])) {
                    app.addUsageLog(s);
                }
            }
        }
        setTrackOfApps();
    }
    
    private void setTrackOfApps() {
        List<App> apps = getObjects();
        for (App app : apps) {
            app.calculateCloseRate(period, usageLogs.get(0));
        }
        /* 设定分类的轨道 */
        int minRate = Integer.MAX_VALUE, maxRate = Integer.MIN_VALUE;
        for (App app : apps) {
            if (app.getCloseRate() < minRate)
                minRate = app.getCloseRate();
            if (app.getCloseRate() > maxRate)
                maxRate = app.getCloseRate();
        }
        int[] levels = new int[10];
        setNumberOfTracks(10);
        int delta = (maxRate - minRate) / 10;
        for (int i = 0; i < 10; i++) {
            levels[i] = maxRate - i * delta;
            addTrack(i + 1);
        }
        /* 将各个App放进特定的轨道之中 */
        NEXTAPP:
        for (App app : apps) {
            for (int i = 1; i < 10; i++) {
                if (app.getCloseRate() > levels[i]) {
                    setTrack(app, i);
                    continue NEXTAPP;
                }
            }
            if (app.getTrack() == null)
                setTrack(app, 10);
        }
    }
    
    /**
     * 通过名字寻找应用对象
     * @param name 名字
     * @return 应用对象
     */
    public App getAppByName(String name) {
        List<App> as = getObjects();
        for (App a : as) {
            if (a.getName().equals(name))
                return a;
        }
        return null;
    }
    
//    public static void main(String[] args) throws IOException {
//        PersonalAppEcosystem raa = new PersonalAppEcosystem();
//        raa.build("src/creator/PersonalAppEcosystem.txt");
//    }
    
}
