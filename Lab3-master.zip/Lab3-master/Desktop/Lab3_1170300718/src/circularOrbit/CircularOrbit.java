package circularOrbit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import relationship.Relationship;
import track.Track;

/**
 * 对现实中的各类具备“具有一个圆心/中心点、围绕圆心的多条环路/轨道、
 * 多个物体分布在圆心和不同环路上”特征的事物进行抽象。
 * 
 * @param <L> 代表多轨道系统的中心点物体类型
 * @param <E> 代表多轨道系统的轨道物体类型
 */
public interface CircularOrbit<L, E> {

    public final List<Relationship<String, String>> rels = new ArrayList<>();
    
    // Abstraction function:
    //   AF(rels) = a CircularOrbit
    // Representation invariant:
    //   all fields never change.
    // Safety from rep exposure:
    //   All fields are private;
    //   list is mutable.
    
    /**
     * 增加一条轨道
     * @param radius 轨道半径
     * @return 如果添加成功则返回true
     */
    public boolean addTrack(int radius);
    
    /**
     * 去除一条轨道
     * @param radius 待去除的轨道的半径
     */
    public void removeTrack(int radius);
    
    /**
     * 获取一条轨道
     * @param radius 待获取轨道的半径
     * @return 获得的轨道
     */
    public Track<E> getTrack(int radius);
    
    /**
     * 增加中心点物体
     * @param center 中心点物体
     */
    public void setCenter(L center);
    
    /**
     * 向系统中添加一个物体
     * @param object 待添加的物体
     */
    public void addObject(E object);
    
    /**
     * 增加从中心点物体与一个轨道物体之间的关系
     * @param object 轨道物体
     */
    public void relateCenterAndObject(E object);
    
    /**
     * 增加两个轨道物体之间的关系
     * @param objectA 轨道物体1
     * @param objectB 轨道物体2
     */
    public void relateBetweenObjects(E objectA, E objectB);
    
    /**
     * 从外部文件读取数据构造轨道系统对象
     * @throws IOException 
     */
    public void build(String fileAddress) throws IOException;

    /**
     * get the center
     * @return center
     */
    public L getCenter();

    /**
     * get the tracks
     * @return tracks
     */
    public List<Track<E>> getTracks();

    /** 
     * get the objects
     * @return objects
     */
    public List<E> getObjects();
    
}
