package circularOrbit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import relationship.Relationship;
import track.Track;

/**
 * CircularOrbit的部分实现
 * 
 * @param <L> 代表多轨道系统的中心点物体类型
 * @param <E> 代表多轨道系统的轨道物体类型
 */
public abstract class ConcreteCircularOrbit<L, E> implements CircularOrbit<L, E> {
    
    private L center;
    private final List<Track<E>> tracks = new ArrayList<>();
    private final List<E> objects = new ArrayList<>();
    private final List<Relationship<L, E>> relOfCenterAndObject = new ArrayList<>();
    private final List<Relationship<E, E>> relOfObjects = new ArrayList<>();
    private int numberOfTracks = 0;
    
    // Abstraction function:
    //   AF(center, tracks, objects, relOfCAndO, relOfObjects, numberOfTracks) = 
    //   a concrete circular orbit
    // Representation invariant:
    //   center and lists never change
    // Safety from rep exposure:
    //   center and lists are private;
    //   lists are returned after copied;
    //   center is immutable and lists are mutable.
    
    /**
     * get the number of tracks
     * @return track number
     */
    public int getNumberOfTracks() {
        return numberOfTracks;
    }

    /**
     * set the number of tracks
     * @param numberOfTracks track number
     */
    public void setNumberOfTracks(int numberOfTracks) {
        this.numberOfTracks = numberOfTracks;
    }

    
    @Override public boolean addTrack(int radius) {
        Iterator<Track<E>> iter = tracks.iterator();
        while (iter.hasNext()) {
            Track<E> track = iter.next();
            if (track.getRadius() == radius)
                return false;
        }
        tracks.add(new Track<E>(radius));
        return true;
    }
    
    @Override public void removeTrack(int radius) {
        Iterator<Track<E>> iter = tracks.iterator();
        while (iter.hasNext()) {
            Track<E> track = iter.next();
            if (track.getRadius() == radius) {
                iter.remove();
            }
        }
    }
    
    @Override public Track<E> getTrack(int radius) {
        Iterator<Track<E>> iter = tracks.iterator();
        while (iter.hasNext()) {
            Track<E> track = iter.next();
            if (track.getRadius() == radius)
                return track;
        }
        return null;
    }
    
    @Override public void setCenter(L center) {
        this.center = center;
    }
    
    @Override public void addObject(E object) {
        objects.add(object);
    }
    
    @Override public L getCenter() {
        return center;
    }

    @Override public List<Track<E>> getTracks() {
        return tracks;
    }

    @Override public List<E> getObjects() {
        return objects;
    }

    @Override public void relateCenterAndObject(E object) {
        relOfCenterAndObject.add(new Relationship<L, E>(center, object));
    }
    
    @Override public void relateBetweenObjects(E objectA, E objectB) {
        relOfObjects.add(new Relationship<E, E>(objectA, objectB));
    }
    
}
