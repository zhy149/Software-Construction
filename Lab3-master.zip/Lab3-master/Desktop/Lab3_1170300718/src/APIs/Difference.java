package APIs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Difference<E> {
    private int diffTrackNumbers;
    private final List<Integer> diffTrackObjectNumber = new ArrayList<>();
    private final List<DiffOfObject<E>> diffObjects = new ArrayList<>();
    
    /**
     * get the value of different track numbers
     * @return the number
     */
    public int getDiffTrackNumbers() {
        return diffTrackNumbers;
    }
    
    /**
     * set the value of different track numbers
     * @param diffTrackNumbers the value
     */
    public void setDiffTrackNumbers(int diffTrackNumbers) {
        this.diffTrackNumbers = diffTrackNumbers;
    }
    
    /**
     * set the value of different track object numbers
     * @param e the value
     */
    public void setDiffTrackObjectNumber(int e) {
        diffTrackObjectNumber.add(e);
    }
    
    /**
     * get the number of different objects
     * @return the number list
     */
    public List<Integer> getDiffTrackObjectNumber() {
        return new ArrayList<>(diffTrackObjectNumber);
    }
    
    public void setDiffObjects(Set<E> sA, Set<E> sB) {
        diffObjects.add(new DiffOfObject<E>(sA, sB));
    }
    
    /**
     * get the different objects
     * @return the object list
     */
    public List<DiffOfObject<E>> getDiffObjects() {
        return new ArrayList<>(diffObjects);
    }

    @Override
    public String toString() {
        return "Difference [diffTrackNumbers=" + diffTrackNumbers + ", diffTrackObjectNumber=" + diffTrackObjectNumber
                + ", diffObjects=" + diffObjects + "]";
    }
    
    
    
}

class DiffOfObject<E> {
    private final Set<E> onlyAppearInA = new HashSet<>();
    private final Set<E> onlyAppearInB = new HashSet<>();
    
    // Abstraction function:
    // AF(onlyAppearInA, onlyAppearInB) = difference of objects
    // Representation invariant:
    // all fields never change.
    // Safety from rep exposure:
    // All fields are private;
    // lists are mutable.
    
    public DiffOfObject(Set<E> sA, Set<E> sB) {
        onlyAppearInA.addAll(sA);
        onlyAppearInB.addAll(sB);
    }
    
    /**
     * set the objects which only appears in A
     * @param o the object
     */
    public void setOnlyAppearInA(E o) {
        onlyAppearInA.add(o);
    }
    
    /**
     * set the objects which only appears in B
     * @param o the object
     */
    public void setOnlyAppearInB(E o) {
        onlyAppearInB.add(o);
    }

    /**
     * get the set of objects which only appears in A
     * @return the set
     */
    public Set<E> getOnlyAppearInA() {
        return new HashSet<>(onlyAppearInA);
    }

    /**
     * get the set of objects which only appears in B
     * @return the set
     */
    public Set<E> getOnlyAppearInB() {
        return new HashSet<>(onlyAppearInB);
    }
    
}