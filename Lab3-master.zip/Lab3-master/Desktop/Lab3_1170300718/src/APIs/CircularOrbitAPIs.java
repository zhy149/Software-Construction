package APIs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import circularOrbit.CircularOrbit;
import physicalObject.PhysicalObject;
import relationship.Relationship;
import track.Track;

public class CircularOrbitAPIs {

    /**
     * 计算多轨道系统中各轨道上物体分布的熵值。如果所有物体都分布在同一条轨道上，其熵值最低；
     * 如果所有物体均匀的分布在每一条轨道上，整个系统的熵值最高。
     * @param c 多轨道系统
     * @return 熵值
     */
    public static <L, E extends PhysicalObject> double getObjectDistributionEntropy(CircularOrbit<L, E> c) {
        double s = 0;
        List<Track<E>> tracks = c.getTracks();
        List<E> objects = c.getObjects();
        int objectTotalNum = 0;
        int[] objectNum = new int[tracks.size()];
        double[] entropy = new double[tracks.size()];
        for (E o : objects) {
            if (o.getTrack() == null)
                continue;
            objectNum[tracks.indexOf(o.getTrack())]++;
            objectTotalNum++;
        }
        for (int i = 0; i < entropy.length; i++) {
            entropy[i] = (double)objectNum[i] / objectTotalNum;
            if (objectTotalNum == 0)
                entropy[i] = 0;
        }
        for (int i = 0; i < entropy.length; i++) {
            if (entropy[i] != 0)
                s -= entropy[i] * Math.log(entropy[i]);
        } 
        return s;
    }
    
    /**
     * 计算任意两个物体之间的最短逻辑距离。
     * @param c 多轨道系统
     * @param e1 物体1
     * @param e2 物体2
     * @return 两物体之间的最短逻辑距离
     */
    public static <L, E extends PhysicalObject> int getLogicalDistance(CircularOrbit<L, E> c, E e1, E e2) {
        
        if (e1 == null || e2 == null) {
            return -1;
        }
        if (e1 == e2) {
            return 0;
        }
        
        List<E> objects = new ArrayList<>();      //顶点表
        List<List<E>> links = new ArrayList<>();  //边表
        List<E> objectsOfC = c.getObjects();
        for (E e : objectsOfC) {
            objects.add(e);
        }
        for (int i = 0; i < objectsOfC.size(); i++) {
            links.add(new ArrayList<E>());
        }
        
        
        /* 将关系列表转化为关系图 */
        for (Relationship<String, String> r : CircularOrbit.rels) {
            E object1 = null, object2 = null;
            String name1 = r.getObject1(), name2 = r.getObject2();
            for (E e : objectsOfC) {
                if (e.getName().equals(name1)) {
                    object1 = e;
                }
                if (e.getName().equals(name2)) {
                    object2 = e;
                }
            }

            int index1 = objects.indexOf(object1);
            links.get(index1).add(object2);
            int index2 = objects.indexOf(object2);
            links.get(index2).add(object1);
        }
        
        int distance = 1;
        int[] visited = new int[objects.size()];
        
        /* 广度优先搜索使用的队列 */
        Queue<E> queue = new LinkedList<E>();
        queue.offer(e1);
        visited[objects.indexOf(e1)] = 1;
        
        /* 图的分层标记 */
        E levelIndex = e1;
        E person = e1;
        
        /* 进行广度搜索 */
        while (!queue.isEmpty()) {
            
            E head = queue.poll();
            List<E> friendsOfHead = links.get(objects.indexOf(head));
            
            for (Iterator<E> it = friendsOfHead.iterator(); it.hasNext(); ) {
                person = it.next();
                if (visited[objects.indexOf(person)] == 0) {
                    queue.offer(person);
                    visited[objects.indexOf(person)] = 1;
                    if (person == e2) {
                        return distance;
                    }
                }
            }
            /* 更新层号和分层标记 */
            if (head == levelIndex) {
                distance++;
                levelIndex = person;
            }
        }
        
        return -1;
    }

    /**
     * 计算任意两个物体之间的物理距离。
     * @param c 多轨道系统
     * @param e1 物体1
     * @param e2 物体2
     * @return 两物体之间的物理距离
     */
    public static <L, E extends PhysicalObject> double getPhysicalDistance(CircularOrbit<L, E> c, E e1, E e2) {
        int radius1 = e1.getTrack().getRadius();
        double sita1 = e1.getSita();
        double x1 = radius1 * Math.cos(sita1);
        double y1 = radius1 * Math.sin(radius1);
        
        int radius2 = e2.getTrack().getRadius();
        double sita2 = e2.getSita();
        double x2 = radius2 * Math.cos(sita2);
        double y2 = radius2 * Math.sin(radius2);
        
        return Math.sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
    }
    
    /**
     * 计算两个多轨道系统之间的差异。
     * @param e1 物体1
     * @param e2 物体2
     * @return 两个多轨道系统之间的差异
     */
    public static <L, E extends PhysicalObject> Difference<E> getDifference(CircularOrbit<L, E> c1, CircularOrbit<L, E> c2) {
        if (!c1.getClass().equals(c2.getClass()))
            return null;
        Difference<E> diff = new Difference<E>();
        List<Track<E>> trackList1 = c1.getTracks();
        List<Track<E>> trackList2 = c2.getTracks();
        diff.setDiffTrackNumbers(Math.abs(trackList1.size() - trackList2.size()));
        final Set<E> onlyAppearInA = new HashSet<>();
        final Set<E> onlyAppearInB = new HashSet<>();
        
        if (trackList1.size() > trackList1.size()) {
            for (Track<E> trk1 : trackList1) {
                for (Track<E> trk2 : trackList2) {
                    List<E> objectList1 = trk1.getObjects();
                    List<E> objectList2 = trk2.getObjects();
                    diff.setDiffTrackObjectNumber(objectList1.size() - objectList2.size());
                    
                    for (E e1 : objectList1) {
                        boolean exist = false;
                        for (E e2 : objectList2) {
                            if (e1.equals(e2))
                                exist = true;
                        }
                        if (exist == false) {
                            onlyAppearInA.add(e1);
                        }
                    }
                    for (E e2 : objectList2) {
                        boolean exist = false;
                        for (E e1 : objectList1) {
                            if (e2.equals(e1))
                                exist = true;
                        }
                        if (exist == false) {
                            onlyAppearInB.add(e2);
                        }
                    }
                    diff.setDiffObjects(onlyAppearInA, onlyAppearInB);
                }
            }
        } else {
            for (Track<E> trk2 : trackList2) {
                for (Track<E> trk1 : trackList1) {
                    List<E> objectList1 = trk1.getObjects();
                    List<E> objectList2 = trk2.getObjects();
                    diff.setDiffTrackObjectNumber(objectList1.size() - objectList2.size());
                    
                    for (E e1 : objectList1) {
                        boolean exist = false;
                        for (E e2 : objectList2) {
                            if (e1.equals(e2))
                                exist = true;
                        }
                        if (exist == false) {
                            onlyAppearInA.add(e1);
                        }
                    }
                    for (E e2 : objectList2) {
                        boolean exist = false;
                        for (E e1 : objectList1) {
                            if (e2.equals(e1))
                                exist = true;
                        }
                        if (exist == false) {
                            onlyAppearInB.add(e2);
                        }
                    }
                    diff.setDiffObjects(onlyAppearInA, onlyAppearInB);
                }
            }
        }
        return diff;
    }
}
