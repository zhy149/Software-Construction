package APIs;

import java.util.ArrayList;
import java.util.List;

import circularOrbit.CircularOrbit;
import physicalObject.PhysicalObject;
import relationship.Relationship;
import shapes.Circle;
import shapes.Line;
import shapes.Picture;
import shapes.Rectangle;
import track.Track;

public class CircularOrbitHelper {

    private static final int GRAPH_X = 800;
    private static final int GRAPH_Y = 800;
    private static final int SCALE_INDEX = 30;
    
    public static <L, E extends PhysicalObject> void visualize(CircularOrbit<L, E> c) {
        
        List<Track<E>> tracks = c.getTracks();
        List<E> objects = new ArrayList<>();
        List<Integer> posOfObjectsX = new ArrayList<>();
        List<Integer> posOfObjectsY = new ArrayList<>();
        Picture pic = new Picture(GRAPH_X, GRAPH_Y);
        
        for (Track<E> track : tracks) {
            objects.addAll(track.getObjects());
            pic.add(new Circle(GRAPH_X / 2, GRAPH_Y / 2, track.getRadius() * SCALE_INDEX));
        }
        for (E object : objects) {
            int radius = object.getTrack().getRadius() * SCALE_INDEX;
            double sita = Math.random() * 2 * Math.PI;
            int x = GRAPH_X / 2 + (int)(radius * Math.cos(sita));
            int y = GRAPH_Y / 2 + (int)(radius * Math.sin(sita));
            posOfObjectsX.add(x);
            posOfObjectsY.add(y);
            pic.add(new Rectangle(x - 2, y - 2, 5, 5));
        }
        for (Relationship<String, String> rel : CircularOrbit.rels) {
            E obj1 = null, obj2 = null;
            for (E object : objects) {
                if (object.getName().equals(rel.getObject1()))
                    obj1 = object;
                if (object.getName().equals(rel.getObject2()))
                    obj2 = object;
            }
            int lineSrcX = posOfObjectsX.get(objects.indexOf(obj1));
            int lineSrcY = posOfObjectsY.get(objects.indexOf(obj1));
            int lineDstX = posOfObjectsX.get(objects.indexOf(obj2));
            int lineDstY = posOfObjectsY.get(objects.indexOf(obj2));
            pic.add(new Line(lineSrcX, lineSrcY, lineDstX, lineDstY));
        }
        if (c.getCenter() != null)
            pic.add(new Rectangle(GRAPH_X / 2 - 5, GRAPH_Y / 2 - 5, 10, 10));
        pic.draw(); 
    }
    
}
