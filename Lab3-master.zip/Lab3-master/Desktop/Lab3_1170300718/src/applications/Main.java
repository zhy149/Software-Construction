package applications;

import java.io.IOException;
import java.util.Scanner;

import APIs.CircularOrbitAPIs;
import APIs.CircularOrbitHelper;
import APIs.Difference;
import centralObject.CentralObject;
import circularOrbit.AtomStructure;
import circularOrbit.CircularOrbit;
import circularOrbit.PersonalAppEcosystem;
import circularOrbit.TrackGame;
import physicalObject.App;
import physicalObject.Athlete;
import physicalObject.Electron;
import physicalObject.PhysicalObject;
import track.Track;

public class Main {

    /**
     * 主函数
     * @param args unused
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        menuStarter();
        Scanner scanner = new Scanner(System.in);
        int chooser = scanner.nextInt();
        CircularOrbit<? extends CentralObject, ? extends PhysicalObject> c = gameSelector(chooser);
        while (chooser != 0) {
            menuPrinter(c);
            chooser = scanner.nextInt();
            functionSelector(c, chooser);
        }
        scanner.close();
    }

    // 开始菜单
    private static void menuStarter() {
        System.out.println("输入待使用应用对应的编号");
        System.out.println("1. TrackGame");
        System.out.println("2. AtomStructure");
        System.out.println("3. PersonalAppEcosystem");
    }
    
    // 选择具体应用
    private static CircularOrbit<? extends CentralObject, ? extends PhysicalObject> gameSelector(
            int app) throws IOException {
        switch (app) {
        case 1:
            return playTrackGame();
        case 2:
            return playAtomStructure();
        case 3:
            return playPersonalAppEcosystem();
        default:
            return null;
        }
    }
    
    // TrackGame的初始化
    private static TrackGame playTrackGame() throws IOException {
//        File file1 = new File("src/creator/TrackGame.txt");
//        File file2 = new File("src/creator/TrackGame_Larger.txt");
//        File file3 = new File("src/creator/TrackGame_Medium.txt");
        TrackGame game = new TrackGame();
        game.build("src/creator/TrackGame.txt");
        return game;
    }

    // AtomStructure的初始化
    private static AtomStructure playAtomStructure() throws IOException {
//        File file1 = new File("src/creator/AtomicStructure.txt");
//        File file2 = new File("src/creator/AtomicStructure_Medium.txt");
        AtomStructure game = new AtomStructure();
        game.build("src/creator/AtomicStructure.txt");
        return game;

    }

    // PersonalAppEcosystem的初始化
    private static PersonalAppEcosystem playPersonalAppEcosystem() throws IOException {
//        File file1 = new File("src/creator/PersonalAppEcosystem.txt");
//        File file2 = new File("src/creator/PersonalAppEcosystem_Medium.txt");
//        File file3 = new File("src/creator/PersonalAppEcosystem_Medium2.txt");
//        File file4 = new File("src/creator/PersonalAppEcosystem_Larger.txt");
//        File file5 = new File("src/creator/PersonalAppEcosystem_Larger2.txt");
        PersonalAppEcosystem game = new PersonalAppEcosystem();
        game.build("src/creator/PersonalAppEcosystem.txt");
        return game;
    }
    
    // 功能菜单
    private static void menuPrinter(CircularOrbit<?, ?> c) {
        System.out.println();
        System.out.println("1. 在 GUI 上可视化展示文件读入的或程序产生的多轨道结构");
        System.out.println("2. 计算多轨道系统中各轨道上物体分布的熵值");
        if (c instanceof TrackGame) {
            System.out.println("3. 随机编排比赛方案");
            System.out.println("4. 按照成绩编排比赛方案");
            System.out.println("5. 为两个选手更换赛道");
            System.out.println("6. 为两个选手更换组");
        } else if (c instanceof AtomStructure) {
            System.out.println("3. 给定源轨道、目标轨道，模拟电子跃迁");
        } else if (c instanceof PersonalAppEcosystem) {
            System.out.println("3. 获取两个时间段的轨道系统结构差异");
            System.out.println("4. 计算两个 App 之间的逻辑距离");
        }
        System.out.println("7. 判断多轨道系统的合法性");
        System.out.println("8. 提供必要信息，以增加新轨道、向特定轨道上增加物体");
        System.out.println("9. 提供必要信息，以从特定轨道上删除物体、删除整条轨道");
        System.out.println("0. 结束退出");
    }
    
    // 选择具体功能
    private static <L, E extends PhysicalObject> void functionSelector(CircularOrbit<L, E> c, int function) {
        switch (function) {
        case 1:
            CircularOrbitHelper.visualize(c);
            break;
        case 2:
            double result = CircularOrbitAPIs.getObjectDistributionEntropy(c);
            System.out.println("该轨道的熵值为：" + result);
            break;
        default:
            /* 按照不同的实现选择不同的功能 */
            if (c instanceof TrackGame)
                trackGameFuncSelector((TrackGame)c, function);
            else if (c instanceof AtomStructure)
                atomStructureFuncSelector((AtomStructure)c, function);
            else if (c instanceof PersonalAppEcosystem)
                personalAppFuncSelector((PersonalAppEcosystem)c, function);
            break;
        case 8:
            Scanner scanner8 = new Scanner(System.in);
            System.out.println("输入轨道的半径");
            int a8 = scanner8.nextInt();
            scanner8.nextLine();
            System.out.println("输入物体名称");
            String name8 = scanner8.nextLine();
            if (c instanceof TrackGame) {
                Track<Athlete> t = ((TrackGame)c).getTrack(a8);
                Athlete athlete = new Athlete(name8, 0, "", 0, 0);
                athlete.setTrack(t);
                t.addObject(athlete);
            } else if (c instanceof AtomStructure) {
                Track<Electron> t = ((AtomStructure)c).getTrack(a8);
                Electron electron = new Electron();
                electron.setTrack(t);
                t.addObject(electron);
            } else if (c instanceof PersonalAppEcosystem) {
                Track<App> t = ((PersonalAppEcosystem)c).getTrack(a8);
                App app = new App(name8, "", "", "", "");
                app.setTrack(t);
                t.addObject(app);
            }
            break;
        case 9:
            Scanner scanner9 = new Scanner(System.in);
            System.out.println("输入轨道的半径");
            int a9 = scanner9.nextInt();
            scanner9.nextLine();
            System.out.println("输入物体名称");
            String name9 = scanner9.nextLine();
            if (c instanceof TrackGame) {
                Track<Athlete> t = ((TrackGame)c).getTrack(a9);
                Athlete athlete = ((TrackGame)c).getAthleteByName(name9);
                if (athlete != null)
                    t.removeObject(athlete);
            } else if (c instanceof AtomStructure) {
                Track<Electron> t = ((AtomStructure)c).getTrack(a9);
                Electron electron = t.getObjects().get(0);
                if (electron != null)
                    t.removeObject(electron);
            } else if (c instanceof PersonalAppEcosystem) {
                Track<App> t = ((PersonalAppEcosystem)c).getTrack(a9);
                App app = ((PersonalAppEcosystem)c).getAppByName(name9);
                if (app != null)
                    t.removeObject(app);
            }
            break;
        }
    }
    
    // trackGame的具体功能
    private static void trackGameFuncSelector(TrackGame c, int function) {
        @SuppressWarnings("resource")
        Scanner scanner = new Scanner(System.in);
        switch (function) {
        case 3:
            c.getOrderRandomly();
            break;
        case 4:
            c.getOrderByGrade();
            break;
        case 5:
            System.out.println("输入两个运动员的名字");
            System.out.print("1.");
            String a5 = scanner.nextLine();
            System.out.print("2.");
            String b5 = scanner.nextLine();
            c.exchangeTrack(c.getAthleteByName(a5), c.getAthleteByName(b5));
            break;
        case 6:
            System.out.println("输入两个运动员的名字");
            System.out.print("1.");
            String a6 = scanner.nextLine();
            System.out.print("2.");
            String b6 = scanner.nextLine();
            c.exchangeGroup(c.getAthleteByName(a6), c.getAthleteByName(b6));
            break;
        case 7:
            if ((c.getCenter() == null) && (c.getTracks().size() >= 4) && (c.getTracks().size() <= 10))
                System.out.println("轨道合法");
            else
                System.out.println("轨道不合法");
            break;
        default:
            break;
        }
    }
    
    // atomStructure的具体功能
    private static void atomStructureFuncSelector(AtomStructure c, int function) {
        @SuppressWarnings("resource")
        Scanner scanner = new Scanner(System.in);
        switch (function) {
        case 3:
            System.out.println("输入两个轨道的层号");
            System.out.print("1.");
            int a = scanner.nextInt();
            System.out.print("2.");
            int b = scanner.nextInt();
            c.transition(c.getTrack(a), c.getTrack(b));
            break;
        default:
            break;
        }
    }
    
    // personalApp的具体功能
    private static void personalAppFuncSelector(PersonalAppEcosystem c, int function) {
        @SuppressWarnings("resource")
        Scanner scanner = new Scanner(System.in);
        switch (function) {
        case 3:
            Difference<App> diff = CircularOrbitAPIs.getDifference(c, new PersonalAppEcosystem());
            System.out.println(diff);
            break;
        case 4:
            System.out.println("分别输入两个App的名字");
            System.out.print("1.");
            String name1 = scanner.nextLine();
            System.out.print("2.");
            String name2 = scanner.nextLine();
            App e1 = c.getAppByName(name1);
            App e2 = c.getAppByName(name2);
            System.out.println(CircularOrbitAPIs.getLogicalDistance(c, e1, e2));
            break;
        default:
            break;
        }
    }
    
}
