package track;

import java.util.ArrayList;
import java.util.List;

/**
 * 围绕中心点的一条闭合曲线，本实验中统一考虑为标准圆形。
 * 轨道的半径是指该轨道与中心点之间的距离。
 * 
 * @param <E> 代表多轨道系统的轨道物体类型
 */
public class Track<E> {

    private int radius;
    private List<E> objects = new ArrayList<E>();
    
    // Abstraction function:
    //   AF(radius, objects) = a track with some objects
    // Representation invariant:
    //   radius is positive, objects is not empty
    // Safety from rep exposure:
    //   All fields are private;
    //   objects is mutable, in order to be operated;
    //   int and E are immutable.
    
    /**
     * Create an instance of Track
     * @param radius the radius of the track
     */
    public Track(int radius) {
        this.radius = radius;
    }
    
    /**
     * add an object to the track
     * @param object the object to be added
     */
    public void addObject(E object) {
        objects.add(object);
    }
    
    /**
     * remove the object off the track
     * @param object the object to be removed
     */
    public void removeObject(E object) {
        objects.remove(object);
    }

    /**
     * get the value of radius of the track
     * @return the radius value
     */
    public int getRadius() {
        return radius;
    }
    
    /**
     * get the objects list
     * @return the list
     */
    public List<E> getObjects() {
        return new ArrayList<E>(objects);
    }

    /**
     * get the number of the objects
     * @return the number
     */
    public int numberOfObjects() {
        return objects.size();
    }
    
    @Override
    public String toString() {
        return "Track [radius=" + radius + "]";
    }
    
}
