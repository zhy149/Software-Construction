package relationship;

/**
 * 表示两个Object之间的关系
 *
 * @param <M> Object1的类型
 * @param <N> Object2的类型
 */
public class Relationship<M, N> {
    
    private M object1;
    private N object2;
    
    // Abstraction function:
    //   AF(object1, object2) = the relationship between two objects
    // Representation invariant:
    //   object1 and object2 never change
    // Safety from rep exposure:
    //   object1 and object2 are private and immutable
    
    /**
     * Create an instance of Relationship
     * @param object1 one object
     * @param object2 the other object
     */
    public Relationship(M object1, N object2) {
        this.object1 = object1;
        this.object2 = object2;
    }

    /**
     * get the object1
     * @return object1
     */
    public M getObject1() {
        return object1;
    }

    /**
     * get the object2
     * @return object2
     */
    public N getObject2() {
        return object2;
    }
    
    
}
