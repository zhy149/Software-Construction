package centralObject;

/**
 * 中心点的原子核类型
 */
public class Nucleus extends CentralObject {

    /**
     * Create an instance of Nucleus
     * @param elementName the name of the elements
     */
    public Nucleus(String name) {
        super(name);
    }

    @Override
    public String toString() {
        return "Nucleus [getName()=" + getName() + "]";
    }
}
