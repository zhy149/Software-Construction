package centralObject;

/**
 * 中心点的用户类型
 */
public class Person extends CentralObject {
    
    /**
     * Create an instance of Person
     * @param name the name of the user
     */
    public Person(String name) {
        super(name);
    }
}
