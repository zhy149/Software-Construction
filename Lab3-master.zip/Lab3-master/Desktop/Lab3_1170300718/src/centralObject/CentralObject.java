package centralObject;

/**
 * 多轨道系统的中心点
 */
public abstract class CentralObject {

    private String name;

    // Abstraction function:
    //   AF(name) = the name of central object
    // Representation invariant:
    //   name never changes
    // Safety from rep exposure:
    //   String is private and immutable
    
    /**
     * Create an instance of Nucleus
     * @param name the name of the elements
     */
    public CentralObject(String name) {
        this.name = name;
    }

    /**
     * get the name of the object
     * @return object name
     */
    public String getName() {
        return name;
    }
    
}
