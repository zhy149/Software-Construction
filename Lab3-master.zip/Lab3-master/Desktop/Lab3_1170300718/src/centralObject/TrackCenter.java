package centralObject;

/**
 * the center of the track game (null)
 */
public class TrackCenter extends CentralObject {

    public TrackCenter(String name) {
        super(name);
    }
}
