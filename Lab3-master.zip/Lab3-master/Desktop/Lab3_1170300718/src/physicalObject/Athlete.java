package physicalObject;

/**
 * 分布在不同轨道上的运动员
 */
public class Athlete extends PhysicalObject {

    private int number;
    private String nationality;
    private int age;
    private double score;
    private int groupOrder;
    
    // Abstraction function:
    //   AF(name, track, number, nationality, age, score) = an athlete
    // Representation invariant:
    //   name, number, nationality, age, score never change.
    // Safety from rep exposure:
    //   All fields are private;
    //   track is mutable, in order to be operated;
    //   the others are immutable.
    
    /**
     * Create an instance of Athlete
     * @param name the name of the athlete
     * @param track the track the athlete is on
     * @param number the number of the athlete
     * @param nationality the country which the athlete belongs to
     * @param age the age of the athlete
     * @param score the best score of the athelete
     */
    public Athlete(String name, int number, String nationality, int age, double score) {
        super(name);
        this.number = number;
        this.nationality = nationality;
        this.age = age;
        this.score = score;
    }

    /**
     * get the number of the athlete
     * @return the number
     */
    public int getNumber() {
        return number;
    }

    /**
     * get the nationality of the athlete
     * @return the nationality
     */
    public String getNationality() {
        return nationality;
    }

    /**
     * get the age of the athlete
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * get the best score of the athlete 
     * @return the best score
     */
    public double getScore() {
        return score;
    }

    /**
     * get the group order
     * @return group order
     */
    public int getGroupOrder() {
        return groupOrder;
    }

    /**
     * set the group order
     * @param groupOrder
     */
    public void setGroupOrder(int groupOrder) {
        this.groupOrder = groupOrder;
    }

    @Override
    public String toString() {
        return "Athlete [name=" + this.getName() + ", number=" + number +
                ", nationality=" + nationality + ", age=" + age + ", score=" + score + "]";
    }

}
