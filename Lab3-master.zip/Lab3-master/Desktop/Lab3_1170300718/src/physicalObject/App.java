package physicalObject;

import java.util.ArrayList;
import java.util.List;

public class App extends PhysicalObject {

    private String company;
    private String version;
    private String description;
    private String field;
    private final List<String> installLogs = new ArrayList<>();
    private final List<String> uninstallLogs = new ArrayList<>();
    private final List<String> usageLogs = new ArrayList<>();
    private int closeRate = -1;

    // Abstraction function:
    // AF(name, company, version, description, field, installLogs, uninstallLogs,
    // usageLogs)
    // = an app
    // Representation invariant:
    // all fields never change, closeRate is nonnegative or -1 if not initialized.
    // Safety from rep exposure:
    // All fields are private;
    // String is immutable.
    // lists are mutable.

    /**
     * Create an instance of App
     * 
     * @param name        the name of the app
     * @param company     the company which the app belongs to
     * @param version     the version of the app
     * @param description the description of the app
     * @param field       the field of the app
     */
    public App(String name, String company, String version, String description, String field) {
        super(name);
        this.company = company;
        this.version = version;
        this.description = description;
        this.field = field;
    }

    /**
     * get the company which the app belongs to
     * 
     * @return the company
     */
    public String getCompany() {
        return company;
    }

    /**
     * get the version of the app
     * 
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * get the description of the app
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * get the field of the app
     * 
     * @return the field
     */
    public String getField() {
        return field;
    }

    /**
     * 添加一条安装日志
     * 
     * @param installLog 安装日志
     */
    public boolean addInstallLog(String installLog) {
        installLogs.add(installLog);
        return true;
    }

    /**
     * 添加一条卸载日志
     * 
     * @param uninstallLog 卸载日志
     */
    public boolean addUninstallLog(String uninstallLog) {
        uninstallLogs.add(uninstallLog);
        return true;
    }

    /**
     * 添加一条使用日志
     * 
     * @param usageLog 使用日志
     */
    public boolean addUsageLog(String usageLog) {
        usageLogs.add(usageLog);
        return true;
    }

    /**
     * 计算亲密度（亲密度等于使用总时长乘以使用次数）
     */
    public void calculateCloseRate(String period, String basicLog) {
        int usingTime = 0;
        int usingCount = 0;
        /* 根据第一条日志进行比较计算，得到使用时长和使用次数 */
        if (period.equals("Month")) {
            for (String s : usageLogs) {
                String[] info = s.split(",");
                if (info[0].substring(0, 7).equals(basicLog.substring(0, 7))) {
                    usingTime += Integer.parseInt(info[3]);
                    usingCount++;
                }
            }
        } else if (period.equals("Week")) {
            for (String s : usageLogs) {
                String[] info = s.split(",");
                if (info[0].substring(0, 7).equals(basicLog.substring(0, 7))
                        && Integer.parseInt(info[0].substring(8))
                                / 7 == Integer.parseInt(basicLog.substring(8, 10)) / 7) {
                    usingTime += Integer.parseInt(info[3]);
                    usingCount++;
                }
            }
        } else if (period.equals("Day")) {
            for (String s : usageLogs) {
                String[] info = s.split(",");
                if (info[0].equals(basicLog.substring(0, 10))) {
                    usingTime += Integer.parseInt(info[3]);
                    usingCount++;
                }
            }
        } else if (period.equals("Hour")) {
            for (String s : usageLogs) {
                String[] info = s.split(",");
                if (info[0].equals(basicLog.substring(0, 10))
                        && s.substring(0, 13).equals(basicLog.substring(0, 13))) {
                    usingTime += Integer.parseInt(info[3]);
                    usingCount++;
                }
            }
        }
        closeRate = usingTime * usingCount;
    }

    /**
     * 获取亲密度数值
     * 
     * @return 亲密度
     */
    public int getCloseRate() {
        return closeRate;
    }

}
