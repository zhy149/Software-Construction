package physicalObject;

/**
 * 分布在不同轨道上的电子
 */
public class Electron extends PhysicalObject {

    /**
     * Create an instance of Electron
     */
    public Electron() {
        super("electron");
    }

}
