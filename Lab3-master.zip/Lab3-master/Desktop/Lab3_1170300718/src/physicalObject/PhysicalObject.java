package physicalObject;

import track.Track;

/**
 * 分布在不同轨道上的物体类
 * 
 * @param <E> 代表多轨道系统的轨道物体类型
 */
public abstract class PhysicalObject {

    private String name = null;
    private Track<? extends PhysicalObject> track = null;
    private double sita = 0;
    
    // Abstraction function:
    //   AF(name, track, sita) = a physical object
    // Representation invariant:
    //   name never changes, 0 <= sita < 2pi
    // Safety from rep exposure:
    //   All fields are private;
    //   track is mutable, in order to be operated;
    //   name is immutable.
    
    /**
     * Create an instance of PhysicalObject
     * @param name the name of the object
     */
    public PhysicalObject(String name) {
        this.name = name;
    }

    /**
     * get the name of the object
     * @return object's name
     */
    public String getName() {
        return name;
    }

    /**
     * get the track of the object
     * @return the track
     */
    public Track<? extends PhysicalObject> getTrack() {
        return track;
    }

    /**
     * change the track of the object
     * @param track the target track
     */
    public void setTrack(Track<? extends PhysicalObject> track) {
        this.track = track;
    }

    /**
     * get the sita value of the object
     * @return the sita value
     */
    public double getSita() {
        return sita;
    }

    /**
     * set the sita value of the object
     * @param sita the sita value
     */
    public void setSita(double sita) {
        if (sita >= 0 && sita < 2 * Math.PI)
            this.sita = sita;
    }
    
}
