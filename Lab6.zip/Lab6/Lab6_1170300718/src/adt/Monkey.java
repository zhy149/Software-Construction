package adt;


import java.util.Random;

import application.CrossRiverApplication;
import strategy.FastestLadderStrategy;
import strategy.FindLadderStrategy;
import strategy.FreeLadderStrategy;

public class Monkey{

	private final int monkeyId;
	private final int velocity;
	private final Direction direction;
	private boolean onBridge;
	private boolean finishCross;
	private Ladder currentLadder;
	private int currentPosition;
	private long bornTime;
	private long arriveTime;
	private FindLadderStrategy strategy;
	
	private void print(String text) {
		CrossRiverApplication.getInstance().printInformation(text);
	}
	
	public Monkey(int monkeyId, int velocity, Direction direction) {
		this.monkeyId = monkeyId;
		this.velocity = velocity;
		this.direction = direction;
		this.onBridge = false;
		this.finishCross = false;
		bornTime = System.currentTimeMillis();
		strategy = (new Random().nextInt(2) == 0) ? new FreeLadderStrategy() : new FastestLadderStrategy();
		print("generate monkey " + this.monkeyId + " velocity=" + this.velocity + ", direction=" + this.direction + " " + strategy.toString());
	}

//	public findLadder() {
//		
//	}
	
	public void climbLadder() {
		Ladder ladder = strategy.findLadder(direction); 
		if(ladder != null) {
			synchronized (ladder) {
				if(ladder.getMonkeyNumber() == 0 || (ladder.climbable() && ladder.getDirection() == this.direction)) {
					ladder.getMonkeyList()[0] = this;
					ladder.addMonkeyNumber();
					ladder.setDirection(this.direction);
					onBridge = true;
					currentLadder = ladder;
					currentPosition = 0;
//					System.out.println("Monkey " + monkeyId + " climb up ladder " + ladder.getLadderIndex());//debug
					print("Monkey " + monkeyId + " is on " + ladder.getLadderIndex() + " ladder, " + (currentPosition + 1) + " step, " + direction + " dirction, has born " + getSurvivalTime() + "s");
				} else {
					print("Monkey " + monkeyId + " wait on " + ((this.direction == Direction.L2R) ? "left" : "right") + " coast, has born " + getSurvivalTime() + "s");
				}
			}
		} else {
			print("Monkey " + monkeyId + " wait on " + ((this.direction == Direction.L2R) ? "left" : "right") + " coast, has born " + getSurvivalTime() + "s");
		}
	}
	
	public long getSurvivalTime() {
		return (System.currentTimeMillis() - bornTime) / 1000;
	}
	
	public int getVelocity() {
		return this.velocity;
	}
	
	
	public long getBornTime() {
		return bornTime;
	}
	
	public int getMonkeyId() {
		return monkeyId;
	}

	public long getArriveTime() {
		return arriveTime;
	}

	public void walk() {
		if(onBridge && currentLadder != null) {
			synchronized (currentLadder) {
				Monkey[] monkeys = currentLadder.getMonkeyList();
				if(currentPosition + velocity < currentLadder.getLength()) {
					for(int i = currentPosition + 1; i <=currentPosition + velocity; i++) {
						if(monkeys[i] != null) {
							if(i > currentPosition + 1) {
								monkeys[currentPosition] = null;
								monkeys[i - 1] = this;
//								System.out.println("Monkey " + monkeyId + " from " + currentPosition + " walk to " +  (i - 1));
								currentPosition = i - 1;
								print("Monkey " + monkeyId + " is on " + currentLadder.getLadderIndex() + " ladder, " + (currentPosition + 1) + " step, " + direction + " dirction, has born " + getSurvivalTime() + "s");//debug
								return;
							} else {
								return;
							}
						}
					}
					monkeys[currentPosition] = null;
					monkeys[currentPosition + velocity] = this;
//					System.out.println("Monkey " + monkeyId + " from " + currentPosition + " walk to " +  (currentPosition + velocity));
					currentPosition += velocity;
					print("Monkey " + monkeyId + " is on " + currentLadder.getLadderIndex() + " ladder, " + (currentPosition + 1) + " step, " + direction + " dirction, has born " + getSurvivalTime() + "s");//debug
				} else {
					for(int i = currentPosition + 1; i < currentLadder.getLength(); i++) {
						if(monkeys[i] != null) {
							if(i > currentPosition + 1) {
								monkeys[currentPosition] = null;
								monkeys[i - 1] = this;
//								System.out.println("Monkey " + monkeyId + " from " + currentPosition + " walk to " +  (i - 1));
								currentPosition = i - 1;
								print("Monkey " + monkeyId + " is on " + currentLadder.getLadderIndex() + " ladder, " + (currentPosition + 1) + " step, " + direction + " dirction, has born " + getSurvivalTime() + "s");//debug
								return;
							} else {
								return;
							}
						}
					}
					monkeys[currentPosition] = null;
					currentLadder.subMonkeyNumber();
					onBridge = false;
					finishCross = true;
					arriveTime = System.currentTimeMillis();
					CrossRiverApplication.getInstance().addFinishMonkeyNumber();
					print("Monkey " + monkeyId + " arrives " + ((direction == Direction.L2R) ? "right coast" : "left coast") + ", cost " + (arriveTime - bornTime) / 1000 + " s");
				}
			}
		}
	}
	
	public void start() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
					if(onBridge == false && finishCross == false) {
						climbLadder();
					} else if(onBridge == true) {
						if(currentLadder != null) {
							walk();
						}
					} else {
						break;
					}
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
			}
		}).start();
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

}
