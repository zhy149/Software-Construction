package adt;

import java.util.ArrayList;
import java.util.List;

public class Ladder {
	private final int ladderIndex;
	private final int ladderLength;
	private Monkey[] monkeyList;
	private int monkeyNumber;
	private Direction direction;
	
	
	public Ladder(int ladderIndex, int ladderLength) {
		this.ladderIndex = ladderIndex;
		this.ladderLength = ladderLength;
		this.monkeyList = new Monkey[ladderLength];
		monkeyNumber = 0;
		direction = Direction.R2L;
	}
	
	public Direction getDirection() {
		return direction;
	}
	
	public void setDirection(Direction dirction) {
		this.direction = dirction;
	}
	
	public int getSlowVelocity() {
		int slowVelocity = Integer.MAX_VALUE;
		for(Monkey monkey : monkeyList) {
			if(monkey != null && monkey.getVelocity() < slowVelocity) {
				slowVelocity = monkey.getVelocity();
			}
		}
		return slowVelocity;
	}
	
	public int getMonkeyNumber() {
		return this.monkeyNumber;
	}
	
	public int getLength() {
		return ladderLength;
	}
	
	public boolean climbable() {
		if(monkeyList[0] == null) { 
			return true;
		} else {
			return false;
		}
	}
	
	public Monkey[] getMonkeyList() {
		return monkeyList;
	}
	
	public void addMonkeyNumber() {
		monkeyNumber ++;
	}
	
	public void subMonkeyNumber() {
		monkeyNumber --;
	}
	
	
//	
//	//return null
//	public Step getStepFromLeft(int stepIndex) {
//		if(stepIndex >= 1 && stepIndex <= stepList.size()) {
//			return stepList.get(stepIndex + 1);
//		} else {
//			return null;
//		}
//	}
//	
//	//return null
//	public Step getStepFromRight(int stepIndex) {
//		if(stepIndex >= 1 && stepIndex <= stepList.size()) {
//			return stepList.get(stepList.size() - stepIndex);
//		} else {
//			return null;
//		}
//	}
	
	public int getLadderIndex() {
		return ladderIndex;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
