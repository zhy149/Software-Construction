package adt;


public enum Direction{
	L2R, R2L;
	
	public static String getDirction(Direction direction) {
		if(direction == Direction.L2R) {
			return "from left to right";
		} else {
			return "from right to left";
		}
	}
}


