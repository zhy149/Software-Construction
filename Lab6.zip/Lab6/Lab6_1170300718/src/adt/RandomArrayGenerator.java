package adt;

import java.util.Random;


public class RandomArrayGenerator {
	
	public static int[] getRandomArray(int size) {
		int seed = new Random().nextInt(size);
		int[] randomArray = new int[size];
		for(int i = 0; i < size; i++) {
			randomArray[i] = (i + seed) % size;
		}
		return randomArray;
	}
}
