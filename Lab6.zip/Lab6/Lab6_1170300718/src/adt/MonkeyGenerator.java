package adt;

import java.util.Random;

import application.CrossRiverApplication;

public class MonkeyGenerator {
	int interval;
	int singleNumber;
	int totalNumber;
	int maxVelocity;
	
	public void generate() {
		new Thread(new Runnable() {
			int leftNumber = totalNumber;
			int currentID = 0;
			
			@Override
			public void run() {
				while(leftNumber > 0) {
					int tempNumber = (leftNumber < singleNumber) ? leftNumber : singleNumber;
					for(int i = 0; i < tempNumber; i++) {
						int velocity = (new Random().nextInt(maxVelocity)) + 1;
						Direction direction = (new Random().nextInt(2) == 0) ? Direction.L2R : Direction.R2L;
						Monkey monkey =  new Monkey(++currentID, velocity, direction);
						CrossRiverApplication.getInstance().getMonkeyList()[currentID - 1] = monkey;
						monkey.start();
					}
					leftNumber -= tempNumber;
					try {
						Thread.sleep(interval * 1000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
			}
		}).start();
	}

	public MonkeyGenerator(int interval, int singleNumber, int totalNumber, int maxVelocity) {
		this.interval = interval;
		this.singleNumber = singleNumber;
		this.totalNumber = totalNumber;
		this.maxVelocity = maxVelocity;
	}


	public static void main(String[] args) {
		MonkeyGenerator monkeyGenerator = new MonkeyGenerator(1, 10, 40, 5);
		monkeyGenerator.generate();
	}
}
