package parser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

public class Parser {

  public static String getContent(String filePath) throws IOException {
    List<String> stringList = new ArrayList<String>();

    try {
      stringList = Files.readAllLines(Paths.get(filePath));
    } catch (IOException e) {
      Logger logger = Logger.getLogger(Parser.class);
      logger.error("the file on path:" + filePath + " cannot be found!");
      throw new IOException("the file on path:" + filePath + " cannot be found!");
    }

    StringBuilder stringBuilder = new StringBuilder();
    for (String s : stringList) {
      stringBuilder.append(s + "\n");
    }
    String contentString = stringBuilder.toString();
    return contentString;
  }
  
  

}
