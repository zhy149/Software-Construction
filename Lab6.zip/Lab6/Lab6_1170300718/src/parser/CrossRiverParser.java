package parser;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.CrossRiverApplication;

public class CrossRiverParser {
	private static String monkeyRegex = "<n=(\\d+),t=(\\d+),N=(\\d+),k=(\\d+),MV=(\\d+)>";
	
	public static void parse(String filePath) {
		try {
			String content = Parser.getContent(filePath);
			Pattern monkeyPattern = Pattern.compile(monkeyRegex);
			Matcher matcher = monkeyPattern.matcher(content);
			if(matcher.find()) {
				int n = Integer.parseInt(matcher.group(1));
				int t = Integer.parseInt(matcher.group(2));
				int N = Integer.parseInt(matcher.group(3));
				int k = Integer.parseInt(matcher.group(4));
				int MV = Integer.parseInt(matcher.group(5));
				if(CrossRiverApplication.checkPara(n, t, N, k, MV)) {
					CrossRiverApplication.initInstance(n, 20, t, N, k, MV);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
