package strategy;

import adt.Direction;
import adt.Ladder;

public interface FindLadderStrategy {
	
	public Ladder findLadder(Direction direction);
}



