package strategy;



import adt.Direction;
import adt.Ladder;
import adt.RandomArrayGenerator;
import application.CrossRiverApplication;

public class FastestLadderStrategy implements FindLadderStrategy {

	@Override
	public Ladder findLadder(Direction direction) {
		Ladder[] ladders = CrossRiverApplication.getInstance().getLadderList();
		int[] randomArray = RandomArrayGenerator.getRandomArray(ladders.length);

		Ladder fastLadder = null;
		int topSpeed = -1;
		
		for(int i : randomArray) {
			if(ladders[i].getMonkeyNumber() == 0) {
				return ladders[i];
			} else if(ladders[i].getDirection() == direction && ladders[i].getSlowVelocity() > topSpeed) {
				topSpeed = ladders[i].getSlowVelocity();
				fastLadder = ladders[i];
			}
		}
		
		return fastLadder;
	}
	
	@Override
	public String toString() {
		return "FastestLadderStrategy";
	}
	
	public static void main(String[] args) {
	
	}

}
