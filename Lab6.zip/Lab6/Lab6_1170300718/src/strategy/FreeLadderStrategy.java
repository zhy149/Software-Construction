package strategy;


import adt.Direction;
import adt.Ladder;
import adt.RandomArrayGenerator;
import application.CrossRiverApplication;
import strategy.FindLadderStrategy;

public class FreeLadderStrategy implements FindLadderStrategy{


	@Override
	public Ladder findLadder(Direction direction) {
		Ladder[] ladders = CrossRiverApplication.getInstance().getLadderList();
		int[] randomArray = RandomArrayGenerator.getRandomArray(ladders.length);

		for(int i : randomArray) {
			if(ladders[i].getMonkeyNumber() == 0) {
				return ladders[i];
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return "FreeLadderStrategy";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
}
