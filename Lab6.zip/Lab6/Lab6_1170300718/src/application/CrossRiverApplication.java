package application;

import java.awt.TextArea;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import adt.Direction;
import adt.Ladder;
import adt.Monkey;
import adt.MonkeyGenerator;

public class CrossRiverApplication {
	private final int ladderNumber;		//n
	private final int ladderLength;		//h
	private final int interval;				//t
	private final int totalNumber;		//N
	private final int singleNumber;		//k
	private final int maxVelocity;		//MV
	private final Ladder[] ladderList ;
	private boolean lock = true;
	private final Monkey[] monkeyList;
	private int finishMonkeyNumber; 
	private TextArea textArea;
	
  
  public static boolean checkPara(int ladderNumber, int interval, int totalNumber, int singleNumber, int maxVelocity) {
  	if(ladderNumber >= 1 && ladderNumber <= 10 
  			&& interval >= 1 && interval <=5 && totalNumber >= 2 && totalNumber <= 1000 
  			&& singleNumber >= 1 && singleNumber <= 50 && maxVelocity >= 5 && maxVelocity <=10) {
  		return true;
  	} else {
  		return false;
  	}
  		
  }
  
  public void printInformation(String text) {
  	if(textArea != null) {
  		textArea.append(text + "\n");
  	}
  	Logger logger = Logger.getLogger(CrossRiverApplication.class);
  	logger.info(text);
  }
  
  public void setTextArea(TextArea textArea) {
  		this.textArea = textArea;
  }
  
  public TextArea geTextArea() {
  	return this.textArea;
  }
	
	public Ladder[] getLadderList(){ 
		return ladderList;
	}
	
	public int getLadderNumber() {
		return ladderNumber;
	}
	
	public synchronized void addFinishMonkeyNumber() {
		finishMonkeyNumber ++;
	}
	
	public Monkey[] getMonkeyList() {
		return monkeyList;
	}
	
	public void checkRep() {
		assert(totalNumber > 0);
		for(Monkey monkey : monkeyList) {
			assert(monkey != null);
		}
	}
	
	public double getFairness() {
		double totalFairness = 0;
		int totalCal = 0;
		for(int i = 0; i < totalNumber - 1; i++) {
			for(int j = i + 1; j < totalNumber; j++) {
				long Ya = monkeyList[i].getBornTime();
				long Yb = monkeyList[j].getBornTime();
				long Za = monkeyList[i].getArriveTime();
				long Zb = monkeyList[j].getArriveTime();
				if(((Yb - Ya) * (Zb - Za)) >= 0) {
					totalFairness ++;
				} else {
					totalFairness --;
				}
				totalCal ++;
			}
		}
		return totalFairness / totalCal;
	}

	public double getThroughput() {
		long minBurnTime = monkeyList[0].getBornTime();
		long maxArriveTime = monkeyList[0].getArriveTime();
		for(int i = 1; i < totalNumber; i++) {
			if(monkeyList[i].getBornTime() < minBurnTime) {
				minBurnTime = monkeyList[i].getBornTime();
			}
			if(monkeyList[i].getArriveTime() > maxArriveTime) {
				maxArriveTime = monkeyList[i].getArriveTime();
			}
		}
		return ((double)totalNumber) / ((maxArriveTime - minBurnTime) / 1000.0);
	}
	
	public void start() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				new MonkeyGenerator(interval, singleNumber, totalNumber, maxVelocity).generate();
				while(true) {
					if(finishMonkeyNumber == totalNumber) {
						checkRep();
						printInformation("Finish whole process.");
						printInformation("Throughput: " + getThroughput());
						printInformation("Fairness: " + getFairness());
						break;
					} else {
						try {
							Thread.sleep(500);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}).start();
	}

	
	private CrossRiverApplication(int ladderNumber, int ladderLength, int interval, int totalNumber, int singleNumber,
			int maxVelocity) {
		this.ladderNumber = ladderNumber;
		this.ladderLength = ladderLength;
		this.interval = interval;
		this.totalNumber = totalNumber;
		this.singleNumber = singleNumber;
		this.maxVelocity = maxVelocity;
		this.ladderList = new Ladder[ladderNumber];
		for(int i = 0; i < ladderNumber; i++) {
			ladderList[i] = new Ladder(i + 1, ladderLength);
		}
		this.monkeyList = new Monkey[totalNumber];
		finishMonkeyNumber = 0;
	}

	
	private static CrossRiverApplication instance;
	
	public static void initInstance(int ladderNumber, int ladderLength, int interval, int totalNumber, int singleNumber,
			int maxVelocity) {
		instance = new CrossRiverApplication(ladderNumber, ladderLength, interval, totalNumber, singleNumber,
				maxVelocity);
	}

	
	public static CrossRiverApplication getInstance() {
		return instance;
	}
	

	public static void main(String[] args) {
//		CrossRiverApplication.initInstance(10, 10, 1, 1, 100, 5);
//		CrossRiverApplication instance = CrossRiverApplication.getInstance();
//		for(Ladder ladder : instance.getLadderList()) {
//			System.out.println(ladder.getLadderIndex());
//		}
//		instance.showMessage();
		
		CrossRiverApplication.initInstance(1, 10, 1, 3, 3, 1);
		CrossRiverApplication.getInstance().start();
//		CrossRiverApplication instance = CrossRiverApplication.getInstance();
//		System.out.println(instance.getLadderNumber());
//		System.out.println(instance.getLadderList()[0].getLadderIndex());
//		System.out.println(instance.getLadderList()[1].getLadderIndex());
//		System.out.println(instance.getLadderList()[2].getLadderIndex());
//		for(int i = 0; i < 40; i++) {
//			new Monkey(i + 1, 2, Direction.L2R).start();
//		}
//		new MonkeyGenerator(1, 10, 35, 5).generate();
		
		
	}
	
}
