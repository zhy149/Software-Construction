/* Copyright (c) 2007-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P4;

import static org.junit.Assert.*;

import java.time.Instant;
import java.util.Arrays;
import java.util.Set;

import org.junit.Test;
import P4.src.twitter.*;
public class ExtractTest {

    /*
     * TODO: your testing strategies for these methods should go here.
     * See the ic03-testing exercise for examples of what a testing strategy comment looks like.
     * Make sure you have partitions.
     */
    
    private static final Instant d1 = Instant.parse("2016-02-17T11:00:00Z");
    private static final Instant d2 = Instant.parse("2016-02-17T11:00:00Z");
    private static final Instant d3 = Instant.parse("2016-02-17T11:00:01Z");
    private static final Instant d4 = Instant.parse("2016-02-17T11:00:02Z");
    private static final Instant d5 = Instant.parse("2016-02-17T11:00:05Z");
    private static final Instant d6 = Instant.parse("2016-02-17T11:00:06Z");
    
    private static final Tweet tweet1 = new Tweet(1, "alyssa", "is it reasonable to talk about rivest so much?", d1);
    private static final Tweet tweet2 = new Tweet(2, "bbitdiddle", "rivest talk in 30 minutes #hype", d2);
    private static final Tweet tweet3 = new Tweet(3, "slakj", "sakjjkj&3 432jr dsj3js- fdjq $ @ejw", d3);
    private static final Tweet tweet4 = new Tweet(4, "nenemnr", "fda gfdhagj dslkahds dsj @gfdh jfd@jda", d4);
    private static final Tweet tweet5 = new Tweet(5, "wewngk", "dhk 8fjds*jewfrkn fdfhkewqhf", d5);
    private static final Tweet tweet6 = new Tweet(6, "fdjk", "ehqfgrk ejqkj& 3243 ewjkqr # 2@are", d6);
    @Test(expected=AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // make sure assertions are enabled with VM argument: -ea
    }
    
    @Test
    public void testGetTimespanTwoTweets() {
        Timespan timespan = Extract.getTimespan(Arrays.asList(tweet1, tweet2));
        Timespan timespan2 = Extract.getTimespan(Arrays.asList(tweet3, tweet4));
        Timespan timespan3 = Extract.getTimespan(Arrays.asList(tweet5, tweet6));
        Timespan timespan4 = Extract.getTimespan(Arrays.asList(tweet1, tweet3));
        Timespan timespan5 = Extract.getTimespan(Arrays.asList(tweet2, tweet4));
        Timespan timespan6 = Extract.getTimespan(Arrays.asList(tweet3, tweet3));
        assertEquals("expected start", d1, timespan.getStart());
        assertEquals("expected end", d4, timespan2.getEnd());
        assertEquals("expected start", d5, timespan3.getStart());
        assertEquals("expected end", d3, timespan4.getEnd());
        assertEquals("expected start", d2, timespan5.getStart());
        assertEquals("expected end", d3, timespan6.getEnd());
    }
    
    @Test
    public void testGetMentionedUsersNoMention() {
        Set<String> mentionedUsers = Extract.getMentionedUsers(Arrays.asList(tweet1));
        Set<String> mentionedUsers2 = Extract.getMentionedUsers(Arrays.asList(tweet2));
        Set<String> mentionedUsers3 = Extract.getMentionedUsers(Arrays.asList(tweet3));
        Set<String> mentionedUsers4 = Extract.getMentionedUsers(Arrays.asList(tweet4));
        Set<String> mentionedUsers5 = Extract.getMentionedUsers(Arrays.asList(tweet5));
        Set<String> mentionedUsers6 = Extract.getMentionedUsers(Arrays.asList(tweet6));
        
        assertTrue("expected empty set", mentionedUsers.isEmpty());
        assertTrue("expected empty set", mentionedUsers2.isEmpty());
        assertFalse("expected empty set", mentionedUsers3.isEmpty());
        assertFalse("expected empty set", mentionedUsers4.isEmpty());
        assertTrue("expected empty set", mentionedUsers5.isEmpty());
        assertTrue("expected empty set", mentionedUsers6.isEmpty());
    }

    /*
     * Warning: all the tests you write here must be runnable against any
     * Extract class that follows the spec. It will be run against several staff
     * implementations of Extract, which will be done by overwriting
     * (temporarily) your version of Extract with the staff's version.
     * DO NOT strengthen the spec of Extract or its methods.
     * 
     * In particular, your test cases must not call helper methods of your own
     * that you have put in Extract, because that means you're testing a
     * stronger spec than Extract says. If you need such helper methods, define
     * them in a different class. If you only need them in this test class, then
     * keep them in this test class.
     */

}
