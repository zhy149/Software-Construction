package P4;

import static org.junit.Assert.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import P4.src.twitter.*;
public class MySocialNetworkTest {
	 @Test(expected=AssertionError.class)
	    public void testAssertionsEnabled() {
	        assert false; // make sure assertions are enabled with VM argument: -ea
	    }
	private static final Instant d1 = Instant.parse("2016-02-17T11:00:00Z");
    private static final Instant d2 = Instant.parse("2016-02-17T11:00:00Z"); //
    private static final Instant d3 = Instant.parse("2016-02-17T11:00:01Z");
    private static final Instant d4 = Instant.parse("2016-02-17T11:00:02Z");
    private static final Instant d5 = Instant.parse("2016-02-17T11:00:05Z");
    private static final Instant d6 = Instant.parse("2016-02-17T11:00:06Z");
    private static final Tweet tweet1 = new Tweet(1, "alyssa", "is it reasonable to talk about #rivest  # hype so much?", d1);
    private static final Tweet tweet2 = new Tweet(2, "bbitdiddle", "rivest talk in 30 minutes #hype", d2);
    private static final Tweet tweet3 = new Tweet(3, "slakj", "sakjjkj&3 432jr dsj3js- fdjq $ @ejw", d3);
    private static final Tweet tweet4 = new Tweet(4, "nenemnr", "fda gfdhagj ds @lkahds dsj @gfdh jfd@jda", d4);
    private static final Tweet tweet5 = new Tweet(5, "wewngk", "dhk 8fjds*jewfrkn fdfhk @ewqhf @lkahds", d5);
    private static final Tweet tweet6 = new Tweet(6, "fdjk", "ehqfgrk ejqkj& 3243 ewjkqr # 2@are", d6);
	 @Test
	    public void MytestGuessFollowsGraphEmpty() {
	        Map<String, Set<String>> followsGraph = SocialNetwork.guessFollowsGraph(new ArrayList<>());
	        List<Tweet> list = new ArrayList<Tweet>();
	        list.add(tweet1);
	        list.add(tweet2);
	        list.add(tweet3);
	        list.add(tweet4);
	        list.add(tweet5);
	        list.add(tweet6);
	        Map<String, Set<String>> followsGraph2 = SocialNetwork.guessFollowsGraph(list);
	        List<Tweet> list1 = new ArrayList<Tweet>();
	        list1.add(tweet1);
	        list1.add(tweet2);
	        Map<String, Set<String>> followsGraph3 = SocialNetwork.guessFollowsGraph(list1);
	        
	        
	        assertTrue("expected empty graph", followsGraph.isEmpty());
	        assertFalse("expected empty graph", followsGraph2.isEmpty());
	        assertFalse("expected empty graph", followsGraph3.isEmpty());
	    }

}
