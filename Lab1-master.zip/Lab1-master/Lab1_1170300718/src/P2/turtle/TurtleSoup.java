/* Copyright (c) 2007-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P2.turtle;

import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.ArrayList;
import java.util.HashSet;

public class TurtleSoup {

    /**
     * Draw a square.
     * 
     * @param turtle the turtle context
     * @param sideLength length of each side
     */
    public static void drawSquare(Turtle turtle, int sideLength) {
        // Coding start
    	//formula:(n-2)*180/n,n>2
    	int i=0;
    	for(i=0;i<4;i++)
    	{
    	turtle.forward(sideLength);
    	turtle.turn(90);
    	}
    
    }

    /**
     * Determine inside angles of a regular polygon.
     * 
     * There is a simple formula for calculating the inside angles of a polygon;
     * you should derive it and use it here.
     * 
     * @param sides number of sides, where sides must be > 2
     * @return angle in degrees, where 0 <= angle < 360
     */
    public static double calculateRegularPolygonAngle(int sides) {
       
    	// Coding start
    	//formula:(n-2)*180/n,n>2
    	double angle=0;
        if(sides<=2)
        {
        	System.out.println("There's less than 3 sides for the polygon");
        	return angle;
        }
        else
        {
        	angle = (sides-2)*180;
        	angle = angle/sides;
        	return angle;
        }
    }

    /**
     * Determine number of sides given the size of interior angles of a regular polygon.
     * 
     * There is a simple formula for this; you should derive it and use it here.
     * Make sure you *properly round* the answer before you return it (see java.lang.Math).
     * HINT: it is easier if you think about the exterior angles.
     * 
     * @param angle size of interior angles in degrees, where 0 < angle < 180
     * @return the integer number of sides
     */
    public static int calculatePolygonSidesFromAngle(double angle) {
    	//Coding start
        int sides = 0;
        if(angle<0||angle>360)
        {
        	System.out.println("wrong angle input");
        	return 0;
        }
        else
//        int angle1 = Math.round(angle);
        {
        	sides = (int)(360/(180-angle)+0.5);
            return sides;
        }
    }

    /**
     * Given the number of sides, draw a regular polygon.
     * 
     * (0,0) is the lower-left corner of the polygon; use only right-hand turns to draw.
     * 
     * @param turtle the turtle context
     * @param sides number of sides of the polygon to draw
     * @param sideLength length of each side
     */
    public static void drawRegularPolygon(Turtle turtle, int sides, int sideLength) {
//        throw new RuntimeException("implement me!");
    	int n = sides;
    	double angle = calculateRegularPolygonAngle(sides);
    	for(;n>0;n--)
    	{
    		turtle.forward(sideLength);
    		turtle.turn(180-angle);
    	}
    	//Coding start
    }

    /**
     * Given the current direction, current location, and a target location, calculate the Bearing
     * towards the target point.
     * 
     * The return value is the angle input to turn() that would point the turtle in the direction of
     * the target point (targetX,targetY), given that the turtle is already at the point
     * (currentX,currentY) and is facing at angle currentBearing. The angle must be expressed in
     * degrees, where 0 <= angle < 360. 
     *
     * HINT: look at http://en.wikipedia.org/wiki/Atan2 and Java's math libraries
     * 
     * @param currentBearing current direction as clockwise from north
     * @param currentX current location x-coordinate
     * @param currentY current location y-coordinate
     * @param targetX target point x-coordinate
     * @param targetY target point y-coordinate
     * @return adjustment to Bearing (right turn amount) to get to target point,
     *         must be 0 <= angle < 360
     */
    public static double calculateBearingToPoint(double currentBearing, int currentX, int currentY,
                                                 int targetX, int targetY) {
        //Coding start
    	double turndegree;
    	int Xdi = targetX-currentX;
        int Ydi = targetY-currentY;
        double XdiD = (double)Xdi;
        double YdiD = (double)Ydi;
        double deg1 = (180*Math.atan2(YdiD, XdiD))/Math.PI;
        double deg2 = 90-deg1;
        if(deg2>=currentBearing)
        {
        	turndegree = deg2-currentBearing;
        }
        else {
        	turndegree = 360-currentBearing+deg2;	
		}
        System.out.println(turndegree);
        return turndegree;
        	
    }

    /**
     * Given a sequence of points, calculate the Bearing adjustments needed to get from each point
     * to the next.
     * 
     * Assumes that the turtle starts at the first point given, facing up (i.e. 0 degrees).
     * For each subsequent point, assumes that the turtle is still facing in the direction it was
     * facing when it moved to the previous point.
     * You should use calculateBearingToPoint() to implement this function.
     * 
     * @param xCoords list of x-coordinates (must be same length as yCoords)
     * @param yCoords list of y-coordinates (must be same length as xCoords)
     * @return list of Bearing adjustments between points, of size 0 if (# of points) == 0,
     *         otherwise of size (# of points) - 1
     */
    public static List<Double> calculateBearings(List<Integer> xCoords, List<Integer> yCoords) {
        //Coding start
        List<Double> Cal=new ArrayList<Double>();
        if(xCoords.size()==0||yCoords.size()==0)
        {
        	Cal.add(null);
        	return Cal;
        }
        else if(xCoords.size()==1||yCoords.size()==1)
        {
        	Cal.add(null);
        	return Cal;
        }
        else
        {
        	
        	Cal.add(calculateBearingToPoint(0.0,xCoords.get(0),yCoords.get(0),xCoords.get(1),yCoords.get(1)));
        	double tmp1 = Cal.get(0);
        	int i = 1;
        	for(;i<xCoords.size()-1;i++)
        	{
        		double tmp = Cal.get(i-1);
        		while(tmp>360)
        		{
        			tmp-=360;
        		}
        		while(tmp<0)
        		{
        			tmp+=360;
        		}
        		Cal.add(calculateBearingToPoint(tmp1,xCoords.get(i),yCoords.get(i),xCoords.get(i+1),yCoords.get(i+1)));
        		tmp1 = tmp1+tmp;
        		System.out.println(Cal.get(i));
        	}
        	return Cal;
        }
    }
    /**
     * Given a set of points, compute the convex hull, the smallest convex set that contains all the points 
     * in a set of input points. The gift-wrapping algorithm is one simple approach to this problem, and 
     * there are other algorithms too.
     * 
     * @param points a set of points with xCoords and yCoords. It might be empty, contain only 1 point, two points or more.
     * @return minimal subset of the input points that form the vertices of the perimeter of the convex hull
     */
//   
    public static double cross(Point a, Point b, Point c)
    {
    	double Cro = 0;
//    	double dix1 = a.x()-b.x();
//    	double dix2 = b.x()-c.x();
//    	double diy1 = a.y()-b.y();
//    	double diy2 = b.y()-c.y();
    	double current = 90-Math.atan2(b.y()-a.y(), b.x()-a.x());
    	Cro = calculateBearingToPoint(current,(int)b.x(),(int)b.y(),(int)c.x(),(int)c.y());
    	return Cro;
    }
    
    public static double distance(Point a, Point b)
    {
        double xdi = a.x()-b.x();
        double ydi = a.y()-b.y();
        double sum = Math.sqrt(xdi*xdi+ydi*ydi);
        return sum;
    }
    public static Set<Point> convexHull(Set<Point> points) {
    	Set<Point> ans = new HashSet<Point>();
    	int num = points.size();
    	if(num==0) return ans;
    	if(num==1||num==2||num==3) {
    		for(Point p :points) {
    			ans.add(p);
    		}
    		return ans;
    	}
    	Stack<Point> stack = new Stack<Point>();
    	Stack<Double> angle_stack = new Stack<Double>();
    	Point[] list = new Point[points.size()];
    	points.toArray(list);
    	int len = list.length;
    	Point tmp = list[0];
    	//int index = 0;
    	for(int i=0;i<len;i++) {
    		if(list[i].y()<tmp.y()) {
    			tmp = list[i];
    			//index = i;
    		}
    	}
    	Point tmp0;
    	for(int j=0;j<len;j++) {
    		for(int i=0;i<len-1;i++) {
    			if((Math.atan2(list[i].y()-tmp.y(), list[i].x()-tmp.x())>
    			Math.atan2(list[i+1].y()-tmp.y(), list[i+1].x()-tmp.x()))||
    					((Math.atan2(list[i].y()-tmp.y(), list[i].x()-tmp.x())==
    			Math.atan2(list[i+1].y()-tmp.y(), list[i+1].x()-tmp.x()))&&(
    			Math.pow(list[i].x()-tmp.x(), 2)+Math.pow(list[i].y()-tmp.y(), 2)>
    					Math.pow(list[i+1].y()-tmp.y(), 2)+Math.pow(list[i+1].x()-tmp.x(), 2)))) {
    				tmp0 = list[i];
    				list[i] = list[i+1];
    				list[i+1] = tmp0;
    			}
    		}
    	}
    	stack.push(list[0]);
    	stack.push(list[1]);
    	double angle = 0;
    	angle += calculateBearingToPoint(angle,(int)(list[0].x()-tmp.x()),
    			(int)(list[0].y()-tmp.y()),(int)(list[1].x()-tmp.x()),(int)(list[1].y()-tmp.y()));
    	for(int i = 2;i<len;i++) {
    		do {
    			Point cur = stack.peek();
    			double tmpangle = calculateBearingToPoint(angle,
    					(int)(cur.x()-tmp.x()),(int)(cur.y()-tmp.y()),
    					(int)(list[i].x()-tmp.x()),(int)(list[i].y()-tmp.y()));
    			if(tmpangle>180) {
    				angle+=tmpangle;
    				if(angle>360) angle-=360;
    				angle_stack.push(tmpangle);
    				stack.push(list[i]);
    				break;
    			}
    			stack.pop();
    			tmpangle = angle_stack.pop();
    			angle-=tmpangle;
    			if(angle<0) angle+=360;
    			
    		}while(true);
    	}
    	while(!stack.isEmpty()) {
    		Point curp = stack.pop();
    		ans.add(curp);
    	}
    	return ans;
        }

    
    
    
    /**
     * Draw your personal, custom art.
     * 
     * Many interesting images can be drawn using the simple implementation of a turtle.  For this
     * function, draw something interesting; the complexity can be as little or as much as you want.
     * 
     * @param turtle the turtle context
     */
    public static void drawPersonalArt(Turtle turtle) {
        //Coding start
        int len = 1;
        for(int i = 1; i < 300; i++)
        {
        	if (i%4 == 0) {
				turtle.color(PenColor.BLUE);
			}
        	else if(i%4 == 1) {
        		turtle.color(PenColor.RED);
        	}
        	else if(i%4 == 2) {
        		turtle.color(PenColor.YELLOW);
        	}
        	else {
				turtle.color(PenColor.BLACK);
			}
        	turtle.forward(i+len);
        	turtle.turn((double)i);
        }
    }

    /**
     * Main method.
     * 
     * This is the method that runs when you run "java TurtleSoup".
     * 
     * @param args unused
     */
    public static void main(String args[]) {
        DrawableTurtle turtle = new DrawableTurtle();
        drawPersonalArt(turtle);
//       drawSquare(turtle, 40);
      drawRegularPolygon(turtle, 8, 40);
        // draw the window
        turtle.draw();
    }

}
