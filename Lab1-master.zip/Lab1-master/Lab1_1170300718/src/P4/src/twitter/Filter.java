/* Copyright (c) 2007-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P4.src.twitter;

import java.util.ArrayList;
import java.util.List;

/**
 * Filter consists of methods that filter a list of tweets for those matching a
 * condition.
 * 
 * DO NOT change the method signatures and specifications of these methods, but
 * you should implement their method bodies, and you may add new public or
 * private methods or classes if you like.
 */
public class Filter {

    /**
     * Find tweets written by a particular user.
     * 
     * @param tweets
     *            a list of tweets with distinct ids, not modified by this method.
     * @param username
     *            Twitter username, required to be a valid Twitter username as
     *            defined by Tweet.getAuthor()'s spec.
     * @return all and only the tweets in the list whose author is username,
     *         in the same order as in the input list.
     */
    public static List<Tweet> writtenBy(List<Tweet> tweets, String username) {
        List<Tweet> tweet = new ArrayList<Tweet>();
        int tweetsize = tweets.size();
        if(tweetsize == 0)
        {
        	System.out.println("You put an empty tweet list in the input!");
        }
        else {
        	for(int i = 0; i < tweetsize; i++)
        	{
        		if(tweets.get(i).getAuthor().equals(username))
        		{
        			tweet.add(tweets.get(i));
        		}
        	}
		}
        return tweet;
    }

    /**
     * Find tweets that were sent during a particular timespan.
     * 
     * @param tweets
     *            a list of tweets with distinct ids, not modified by this method.
     * @param timespan
     *            timespan
     * @return all and only the tweets in the list that were sent during the timespan,
     *         in the same order as in the input list.
     */
    public static List<Tweet> inTimespan(List<Tweet> tweets, Timespan timespan) {
        List<Tweet> tweet = new ArrayList<Tweet>();
        long start = timespan.getStart().getEpochSecond();
        long end = timespan.getEnd().getEpochSecond();
        int tweetsize = tweets.size();
        for(int i = 0; i < tweetsize; i++)
        {
        	long time = tweets.get(i).getTimestamp().getEpochSecond();
        	if(time>start&&time<end)
        	{
        		tweet.add(tweets.get(i));
        	}
        }
        return tweet;
    }

    /**
     * Find tweets that contain certain words.
     * 
     * @param tweets
     *            a list of tweets with distinct ids, not modified by this method.
     * @param words
     *            a list of words to search for in the tweets. 
     *            A word is a nonempty sequence of nonspace characters.//words����û�пո��Ҳ�Ϊ��
     * @return all and only the tweets in the list such that the tweet text (when 
     *         represented as a sequence of nonempty words bounded by space characters 
     *         and the ends of the string) includes *at least one* of the words 
     *         found in the words list. Word comparison is not case-sensitive,
     *         so "Obama" is the same as "obama".  The returned tweets are in the
     *         same order as in the input list.
     */
    public static List<Tweet> containing(List<Tweet> tweets, List<String> words) {
        List<Tweet> tweet = new ArrayList<Tweet>();
        int tweetsize = tweets.size();
        int wordsize = words.size();
        for(int i = 0; i < tweetsize; i++)
        {
        	String tweetext = tweets.get(i).getText();
        	for(int j = 0; j < wordsize; j++)
        	{
        		String wordtmp = words.get(j);
        		if(judgespace(wordtmp) == true)
        		{
        			System.out.println("there's a space in the word you input");
        		}
        		else {
        			if(includeword(tweetext, wordtmp) == true)
        			{
        				tweet.add(tweets.get(i));
        				break;
        			}
        			else {
        				continue;
        			}
				}
        	}
        }
        return tweet;
    }
    public static boolean judgespace(String s)
    {
    	boolean judge = false;//Ĭ��û�пո��пո�judge����
    	int end_index = s.length()-1;
    	for(int i = 0; i < end_index; i++)
    	{
    		if(s.charAt(i) == ' ')
    		{
    			judge = true;
    			break;
    		}
    	}
    	return judge;
    }
    public static boolean includeword(String s1, String s2)
    {
    	boolean flag = true;//Ĭ�Ϻ���
    	if(s1.indexOf(s2)==-1)
    	{
    		flag = false;
    	}
    	return flag;
    }
    public static String getname(String s, int beginindex)
    {
    	int length = s.length();
    	int endindex = length;
      	for(int i = beginindex+1; i < endindex; i++)
    	{
    		if((s.charAt(i)>='A'&&s.charAt(i)<='Z')||(s.charAt(i)>='0'&&s.charAt(i)<='9')||(s.charAt(i)=='-')||(s.charAt(i)=='_'))
    		{
    			continue;
    		}
    		else {
    			endindex = i;
    			break;
			}
    	}
    	return s.substring(beginindex, endindex);
    	
    }
}
