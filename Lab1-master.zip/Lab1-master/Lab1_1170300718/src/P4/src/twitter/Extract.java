/* Copyright (c) 2007-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package P4.src.twitter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;



/**
 * Extract consists of methods that extract information from a list of tweets.
 * 
 * DO NOT change the method signatures and specifications of these methods, but
 * you should implement their method bodies, and you may add new public or
 * private methods or classes if you like.
 */
public class Extract {

    /**
     * Get the time period spanned by tweets.
     * 
     * @param tweets
     *            list of tweets with distinct ids, not modified by this method.
     * @return a minimum-length time interval that contains the timestamp of
     *         every tweet in the list.
     */
    public static Timespan getTimespan(List<Tweet> tweets) {
        //throw new RuntimeException("not implemented");
        long instant = tweets.get(0).getTimestamp().getEpochSecond();//timestamp to long(seconds)
        long max;
    	long min;
    	int max1 = 0;
    	int min1 = 0;
    	max = min = instant;
        	for(int j = 0; j < tweets.size(); j++)
        	{
        		long tmp2 = tweets.get(j).getTimestamp().getEpochSecond();
        		if(tmp2>=max)
        		{
        			max1 = j;
        			System.out.println(max1);//test
        		}
        		if(tmp2<=min)
        		{
        			min1 = j;
        			System.out.println(min1);//test
        		}
        	}
        	Timespan TF = new Timespan(tweets.get(min1).getTimestamp(),tweets.get(max1).getTimestamp());
        return TF;
    }

    /**
     * Get usernames mentioned in a list of tweets.
     * 
     * @param tweets
     *            list of tweets with distinct ids, not modified by this method.
     * @return the set of usernames who are mentioned in the text of the tweets.
     *         A username-mention is "@" followed by a Twitter username (as
     *         defined by Tweet.getAuthor()'s spec).
     *         The username-mention cannot be immediately preceded or followed by any
     *         character valid in a Twitter username.
     *         For this reason, an email address like bitdiddle@mit.edu does NOT 
     *         contain a mention of the username mit.
     *         Twitter usernames are case-insensitive, and the returned set may
     *         include a username at most once.
     */
    public static Set<String> getMentionedUsers(List<Tweet> tweets) {
        Set<String> set = new HashSet<String>();
        int tweetsize = tweets.size();
        if(tweetsize == 0)
        {
        	System.out.println("You put an empty tweet list in the input");
        }
        for(int i = 0; i < tweets.size(); i++)
        {
        	String tmp = tweets.get(i).getText();
        	tmp = tmp.toUpperCase();
        	solvesingle_Tweet(set, tmp);
        }
        return set;
    }
    public static void solvesingle_TweetTag(Set<String> set, String tmp)//set�Ǽ��ϣ������м���username��tmp��tweeter text
    {
    	int begin_index = 0;//begin_index �Ƕ�̬��ɨ���ַ�����ʼ��
    	int end_index = tmp.length()-1;//end_index�����һ���ַ�����ţ������ж��ַ����Ƿ�ɨ�����
    	boolean flag = false;//�˴�flag�����ж�text���Ƿ���@
    	while(!flag)
    	{
    		begin_index = tmp.indexOf('#');
    		if(begin_index == -1)
    		{
    			flag = true;
    		}
    		else {
				if(begin_index == 0)
				{
					String newString = Extract.getname(tmp, begin_index);
					if(newString.equals("#")) //equals��������ŵ����ַ�������Ϊ�������ַ���ƥ��
					{
						begin_index++;
					}
					else
					{
						set.add(newString);
						begin_index = begin_index+newString.length();
					}
					
				}
				else if(tmp.charAt(begin_index-1)>='A'&&tmp.charAt(begin_index-1)<='Z'||tmp.charAt(begin_index-1)>='0'&&
						tmp.charAt(begin_index-1)<='9'||tmp.charAt(begin_index-1)=='-'||tmp.charAt(begin_index)=='_')
				{
				    begin_index++;	
				}
				else {
					String newString = Extract.getname(tmp, begin_index);
					if(newString.equals("#"))
					{
						begin_index++;
					}
					else {
						set.add(newString);
						begin_index = begin_index+newString.length();
					}
				}
				tmp = tmp.substring(begin_index);//ÿ������һ��whileѭ����Ҫʹbegin_Index��λ
			}
    		if(begin_index >= end_index)
    		{
    			break;
    		}
    	}
    	return;
    }
    public static void solvesingle_Tweet(Set<String> set, String tmp)//set�Ǽ��ϣ������м���username��tmp��tweeter text
    {
    	int begin_index = 0;//begin_index �Ƕ�̬��ɨ���ַ�����ʼ��
    	int end_index = tmp.length()-1;//end_index�����һ���ַ�����ţ������ж��ַ����Ƿ�ɨ�����
    	boolean flag = false;//�˴�flag�����ж�text���Ƿ���@
    	while(!flag)
    	{
    		begin_index = tmp.indexOf('@');
    		if(begin_index == -1)
    		{
    			flag = true;
    		}
    		else {
				if(begin_index == 0)
				{
					String newString = Extract.getname(tmp, begin_index);
					if(newString.equals("@")) //equals��������ŵ����ַ�������Ϊ�������ַ���ƥ��
					{
						begin_index++;
					}
					else
					{
						set.add(newString);
						begin_index = begin_index+newString.length();
					}
					
				}
				else if(tmp.charAt(begin_index-1)>='A'&&tmp.charAt(begin_index-1)<='Z'||tmp.charAt(begin_index-1)>='0'&&
						tmp.charAt(begin_index-1)<='9'||tmp.charAt(begin_index-1)=='-'||tmp.charAt(begin_index)=='_')
				{
				    begin_index++;	
				}
				else {
					String newString = Extract.getname(tmp, begin_index);
					if(newString.equals("@"))
					{
						begin_index++;
					}
					else {
						set.add(newString);
						begin_index = begin_index+newString.length();
					}
				}
				tmp = tmp.substring(begin_index);//ÿ������һ��whileѭ����Ҫʹbegin_Index��λ
			}
    		if(begin_index >= end_index)
    		{
    			break;
    		}
    	}
    	return;
    }
    public static String getname(String s, int beginindex) //ȫ��ת��д
    {
    	int length = s.length();
    	int endindex = length;
      	for(int i = beginindex+1; i < endindex; i++)
    	{
    		if((s.charAt(i)>='A'&&s.charAt(i)<='Z')||(s.charAt(i)>='0'&&s.charAt(i)<='9')||(s.charAt(i)=='-')||(s.charAt(i)=='_'))
    		{
    			continue;
    		}
    		else {
    			endindex = i;
    			break;
			}
    	}
    	return s.substring(beginindex, endindex);
}
   
}
