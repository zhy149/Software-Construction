package P3;

import java.util.*;

public class FriendshipGraph {
	private List<Person> vertex = new ArrayList<>();
	private int[][] edge = new int[300][300];
	// �����ߵĶ�ά���飬��ͼ��������֮��Ĺ�ϵ
    public void initial()
    {
    	for(int i = 0; i<300 ;i++)
    	{
    		for(int j = 0; j<300 ;j++)
    		{
    			edge[i][j] = 0;
    		}
    	}
    }
	public void addVertex(Person name) {
		for (Person p : vertex) {
			if (p.getName() != name.getName()) {
				continue;
			} else {
				System.out.println("This name already exists in the list");
				System.exit(0);
			}
		}
		vertex.add(name);
		name.index = vertex.size()-1;
	}

	public void addEdge(Person name1, Person name2) {
		edge[name1.index][name2.index] = 1;
		edge[name2.index][name1.index] = 1;
	}
//	 private int number = vertex.size();  
//	 private boolean[] flag;  
	 public int getDistance(Person num1, Person num2){
		    int number = vertex.size();  
	        boolean[] flag = new boolean[number];
	        int count = 0;
	        Queue<Integer> queue = new LinkedList<Integer>();
	        for(int i = 0; i < number; i++)
	        {
	        	flag[i] = false;
	        }
	        flag[num1.index] = true;
	        int tmp = 0;
	        queue.add(num1.index);
	        if(edge[num1.index][num2.index]==1)
	        {
	        	return 1;
	        }
//	        System.out.println(num2.index);
	        while((!flag[num2.index])&&(!queue.isEmpty()))
	        {
	        	tmp = queue.poll();
	        	for(int j = 0; j < number; j++)
	        	{
	        		
	        		if(edge[tmp][j] == 1&&flag[j] == false)
	        		{
	        			flag[j] = true;
	        			queue.add(j);
	        		}
	        	}
	        	count++;
	        }
	        if(!flag[num2.index])
	        {
	        	return -1;
	        }
	        else {
	        	return count;
			}
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FriendshipGraph graph = new FriendshipGraph();
		Person rachel = new Person("Rachel");
		Person ross = new Person("Ross");
		Person ben = new Person("Ben");
		Person kramer = new Person("Kramer");
		graph.addVertex(rachel);
		graph.addVertex(ross);
		graph.addVertex(ben);
		graph.addVertex(kramer);
		graph.addEdge(rachel, ross);
		graph.addEdge(ross, rachel);
		graph.addEdge(ross, ben);
		graph.addEdge(ben, ross);
		System.out.println(graph.getDistance(rachel, ross)); // should print 1
		System.out.println(graph.getDistance(rachel, ben)); // should print 2
		System.out.println(graph.getDistance(rachel, rachel)); // should print 0
		System.out.println(graph.getDistance(rachel, kramer)); // should print -1
	}

}
