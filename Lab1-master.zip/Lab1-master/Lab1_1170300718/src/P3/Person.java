package P3;

public class Person {
    private String name;
    public int index;
    public Person(String person)
    {
    	this.name = person;
    }
    
    public String getName() {
    	return name;
    }

}
