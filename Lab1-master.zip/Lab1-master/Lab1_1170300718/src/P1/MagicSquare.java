package P1;

import java.util.*;

import java.io.*;
import java.util.Scanner;

public class MagicSquare {

	boolean isLegalMagicSquare(String FileName) {
		String filename = "src/P1/txt/" + FileName;
		String lineString;
		List<String> list = new ArrayList<>();
		File file = new File(filename);
		try {
			FileReader fr = new FileReader(file);
			BufferedReader bf = new BufferedReader(fr);
			try {
				while((lineString=bf.readLine())!=null) {
					list.add(lineString);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int rows = list.size();
		int []counter = new int[rows];
		int flag = (list.get(0).split("\t")).length;
		int [][]arr = new int[rows][];
		//this flag is to verify if there are same columns for each rows
		int SR[] = new int[rows];// sum of each row
		int SC[] = new int[rows];// sum of each column
		int SD[] = new int[rows];// sum of diagonal
		for(int i=0;i<rows;i++)
		{
		if(list.get(i).indexOf('.')!=-1) {
			//float
			System.out.println("There is float number in the file");
			return false;
		}
		else if(list.get(i).indexOf('-')!=-1)
		{
			//neg
			System.out.println("There is negative number in the file");
			return false;
		}
		else if(list.get(i).indexOf(' ')!=-1)
		{
			//blank
			System.out.println("There is blank in the file which is supposed to be tab");
			return false;
		}
		String [] rowStrings = list.get(i).split("\t");
		arr[i] = new int[rowStrings.length];
		counter[i] = rowStrings.length;
		if(counter[i]!=flag)
		{
			System.out.println("It's not a matrix");
		}
		for(int j=0;j<rowStrings.length;j++) 
		{
			arr[i][j]=Integer.parseInt(rowStrings[j]);
		
				SR[i] += arr[i][j];
				SC[j] += arr[i][j];

				if (i == j) {
					SD[0] += arr[i][j];
				}

				if (i + j + 1 == rowStrings.length) {
					SD[1] += arr[i][j];
				}
			}
		}
		if(flag!=rows)
		{
			System.out.println("columns and rows don't equal with each other");
		}
		if (SD[0] != SD[1]) {
			return false;
		}

		int sum = SD[0];

		for (int b = 0; b < rows; b++) {
			if (SR[b] != sum || SC[b] != sum)
				return false;
		}
		return true;
	}

	public static boolean generateMagicSquare(int n) {
		int magic[][] = new int[n][n];
		int row = 0, col = n / 2, i, j, square = n * n; //����һ��n*n�ľ����Լ�������в���

		for (i = 1; i <= square; i++) {
			magic[row][col] = i;    //��n*n�ľ����ÿһ��Ԫ�ظ�ֵ
			if (i % n == 0)    //��֧1����ÿһ�е���β������Ҫ����
				row++;
			else {             //��֧2��
				if (row == 0)   //��֧2.1.1������ڵ�һ�еĻ�����һ������n-1��
					row = n - 1;
				else           //��֧2.1.2�����ڵ�һ����һ���ͷ�����һ��ͬ�е�������д
					row--;
				if (col == (n - 1))//��֧2.2.1������ǵ����ڶ��У�����һ������һ������д
					col = 0;
				else             //��֧2.2.2��������һ��
					col++;
			}
		}
		for(i=0;i<n;i++){//���ûʲô��˵�ģ����Ǵ�ӡ����
            for(j=0;j<n;j++)
                System.out.print(magic[i][j]+"\t");
            System.out.println();
        }
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("src\\P1\\txt\\6.txt"));
			for (i = 0; i < n; i++) {
				for (j = 0; j < n; j++) {
					bw.write(magic[i][j] + "\t");

				}
				bw.newLine();
			}
			try {
				bw.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MagicSquare magic = new MagicSquare();

		for (int i = 1; i < 6; i++) {
			System.out.println();
			if (magic.isLegalMagicSquare(String.valueOf(i) + ".txt"))
				System.out.println(i + ":Yes");
			else {
				System.out.println(i + ":No");
			}
		}

		Scanner scanner = new Scanner(System.in);
		int n;

		try {
			System.out.println("Please input a number:");
			n = scanner.nextInt();
			scanner.close();
			System.out.println(n);
			generateMagicSquare(n);
			System.out.println(magic.isLegalMagicSquare("6.txt"));
			if (n % 2 != 0) {
				System.out.println(6 + ":Yes");
			}
		} catch (ArrayIndexOutOfBoundsException aiex) {
			System.out.println("an even number input!\nfalse");
		} catch (NegativeArraySizeException nex) {
			System.out.println("a negative number input!\nfalse");
		}
	}
}
