package centralObject;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.extension.ParameterResolutionException;



public class CentralObjectTest {
	@Test
	public void testNucleus() {
		Nucleus nucleus = new Nucleus("Ca");
		assertEquals("Ca", nucleus.toString());
	}
	
	@Test
	public void testPerson() {
		Person person = new Person("pp", 20, true);
		person.setCurAngle(20);
		assertEquals(20, person.getCurAngle());
		assertEquals(0, person.getNextAngle(10));
		person.setOrbitRadius(10);
		assertEquals(10, person.getOrbitRadius());
		assertEquals("pp", person.getName());
		assertTrue(person.equals(new Person("pp", 20, true)));
		assertEquals(person.name.hashCode(), person.hashCode());
		assertEquals(person.name + person.orbitRadius, person.toString());
		assertEquals(0, person.getRadius());
	}
	
	@Test
	public void testStellar() {
		Stellar stellar = new Stellar("sun", 100, 10);
		assertEquals(stellar.name + " " + stellar.radius + " " + stellar.mass, stellar.toString());
	}
	
//	@Test
//	public void testNucleus() {
//	}
//	
//	@Test
//	public void testNucleus() {
//	}
	
}
