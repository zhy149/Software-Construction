package debug;


import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class TopVotedCandidateTest {
	
	@Test public void testTopVotedCandidate() {
		int[] persons = {0, 1, 1, 0, 0, 1, 0};
		int[] times = {0, 5, 10, 15, 20, 25, 30};
		TopVotedCandidate topVotedCandidate = new TopVotedCandidate(persons, times);
		assertEquals("Correct answer",0,topVotedCandidate.q(3));
		assertEquals("Correct answer",1,topVotedCandidate.q(12));
		assertEquals("Correct answer",1,topVotedCandidate.q(25));
		assertEquals("Correct answer",0,topVotedCandidate.q(15));
		assertEquals("Correct answer",1,topVotedCandidate.q(14));
		assertEquals("Correct answer",1,topVotedCandidate.q(8));
	}
}