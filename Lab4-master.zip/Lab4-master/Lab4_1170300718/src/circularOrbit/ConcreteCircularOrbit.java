package circularOrbit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import physicalObject.PhysicalObject;

import java.util.Set;
import track.Track;


public class ConcreteCircularOrbit<L, E extends PhysicalObject> implements CircularOrbit<L, E> {

	public TreeMap<Track, ArrayList<E>> orbitMap = new TreeMap<Track, ArrayList<E>>();
	public L centralObject;
	
	@Override
	public TreeMap<Track, ArrayList<E>> getOrbitMap() {
		return orbitMap;
	}
	
	
	
	public void resetAngle() {
		
		for(Track track : orbitMap.keySet()) {
			if(!orbitMap.get(track).isEmpty()) {
				double separateAngle = 360.0 / orbitMap.get(track).size();
				for(int i = 0; i < orbitMap.get(track).size(); i++) {
					orbitMap.get(track).get(i).setCurAngle((90 + i * separateAngle) % 360);
				}
			}
		}
	}
	
	
	public Set<String> getSurNameSet(){
		Set<String> set = new HashSet<String>();
		for(Track track : orbitMap.keySet()) {
			for(PhysicalObject surObject : orbitMap.get(track)) {
				set.add(surObject.getName());
			}
		}
		return set;
	}
	

	@Override
	public void refresh(double milisecond) {
		for(Track track : orbitMap.keySet()) {
			for(E e : orbitMap.get(track)) {
				e.setNextAngle(milisecond);
			}
		}
	}
	
	public int getSurObjectNumber() {
		int number = 0;
		for(Track track : orbitMap.keySet()) {
			number += orbitMap.get(track).size();
		}
		return number;
	}


	@Override
	public ConcreteCircularOrbit<L, E> emptyCircularOrbit() {
		return new ConcreteCircularOrbit<L, E>();
	}
	
	

	

	@Override
	public void addOrbit(Track track) {
		if(!orbitMap.containsKey(track)) {
			orbitMap.put(track, new ArrayList<E>());
			assert(orbitMap.containsKey(track));
			Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
			logger.info("add track with radius:" + track.getRadius());
		}
	}
	
	

	@Override
	public void deleteOrbit(Track track) {
		if(orbitMap.containsKey(track)) {
			orbitMap.remove(track);
			assert(!orbitMap.containsKey(track));
			Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
			logger.info("remove track with radius:" + track.getRadius());
		}
	}
	
	@Override
	public void deleteOrbitByRadius(double radius) {
		Track tempTrack = null;
		for(Track track : orbitMap.keySet()) {
			if (track.getRadius() == radius) {
				tempTrack = track;
			}
		}
		if(tempTrack != null) {
			orbitMap.remove(tempTrack);
			Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
			logger.info("remove track with radius:" + radius);
		}
	}


	@Override
	public void addCenObject(L object) {
		this.centralObject = object;
		Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
		logger.info("add central object");
	}

	
	public void deleteSurObjectByName(String name) {
		Track tempTrack = null;
		PhysicalObject tempObject = null;
		for(Track track : orbitMap.keySet()) {
			for(PhysicalObject objcet : orbitMap.get(track)) {
				if(objcet.getName().equals(name)) {
					tempTrack = track;
					tempObject = objcet;
				}
			}
		}
		if(tempObject != null && tempTrack != null) {
			orbitMap.get(tempTrack).remove(tempObject);
			Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
			logger.info("delete surrounding object:" + tempObject.getName());
		}
	}
	
	@Override
	public void addSurObject(Track track, E object) {
		if(orbitMap.containsKey(track)){
			orbitMap.get(track).add(object);
		} else {
			ArrayList<E> objectSet = new ArrayList<E>();
			objectSet.add(object);
			orbitMap.put(track, objectSet);
		}
		Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
		logger.info("add surrounding object:" + object.getName());
	}
	
	@Override
	public void addSurObject(E object) {
		Logger logger = Logger.getLogger(ConcreteCircularOrbit.class);
		logger.info("add surrounding object:" + object.getName());
		for(Track track : orbitMap.keySet()) {
			if (track.getRadius() == object.getOrbitRadius()) {
				orbitMap.get(track).add(object);
				return;
			}
		}
		ArrayList<E> objectSet = new ArrayList<>();
		objectSet.add(object);
		orbitMap.put(new Track(object.getOrbitRadius()), objectSet);
	}
	
	

	public void print() {
		if(centralObject != null) {
			System.out.println(centralObject.toString());
			System.out.println();
		}
		
		int count = 0;
		for(Track track : orbitMap.keySet()) {
			System.out.println(++count + " " + track.toString());
			for(E e : orbitMap.get(track)) {
				System.out.println(e.toString());
			}
			System.out.println();
		}
		
	}



	
	public static void main(String[] args) {
//		ConcreteCircularOrbit<Stellar, PhysicalObject> trackGame = new ConcreteCircularOrbit<Stellar, PhysicalObject>();
//		trackGame.print();
	}

	@Override
	public int getOrbitNumber() {
		return orbitMap.size();
	}

}
