package circularOrbit;

import java.util.ArrayList;
import java.util.TreeMap;

import track.Track;


public interface CircularOrbit <L, E> {
	public CircularOrbit<L, E> emptyCircularOrbit();
	public TreeMap<Track, ArrayList<E>> getOrbitMap();
	public void addOrbit(Track track);
	public void deleteOrbit(Track track);
	public void deleteOrbitByRadius(double radius);
	public int getOrbitNumber();
	public void addCenObject(L object);
	public void addSurObject(Track track, E object);
	public void addSurObject(E object);
	public void refresh(double milisecond);
}
