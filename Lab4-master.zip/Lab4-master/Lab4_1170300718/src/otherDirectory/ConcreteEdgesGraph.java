/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package otherDirectory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import physicalObject.PhysicalObject;



/**
 * An implementation of Graph.
 * 
 * <p>PS2 instructions: you MUST use the provided rep.
 */
public class ConcreteEdgesGraph<L extends PhysicalObject> implements Graph<L>{
    
    private final Set<L> vertices = new HashSet<>();
    private final List<Edge<L>> edges = new ArrayList<>();
    
	// Abstraction function:
	// AF(vertices, edges) client can get a graph from the class,
	// for instance:
	/////////////////////////////////////
	// vertices (a1,a2,a3)
	//
	// edges: a1->a2:3,a1->a3:4
	//////////////////////////////////////////////
	// these two infos mean there are three vertices in the graph:
	// a1,a2,a3. and there are 2 edges in the graph, they are a1 to
	// a2, the weight is 3. another is a1 to a3, and the weight is 4
	//////////////////////////////////////////////////////////////////////////
	// Representation invariant:
	// vertices is a non-repeated set and the HashSet has satisfy it,
	// so it doesn't have limitation
	// edges contains a list of Edge<L>, any two of it
	// are different(the definition of difference)
	/////////////////////////////////////////////////////////////////////////////
	//
	// Safety from rep exposure:
	// the vertices and edges are modified by "private final", and I use Defensive
	// copy to protect it
	// in function which may return reps.
	//
    
    // TODO checkRep
    	private void checkRep() {
    		for(int i=0;i<edges.size();i++) {
    			assert vertices.contains(edges.get(i).getSource()):"an edge has illegal source vertex";
    			assert vertices.contains(edges.get(i).getTarget()):"an edge has illegal target vertex";
    			for(int j=i+1;j<edges.size();j++) {
    				assert !(edges.get(i).getSource().equals(edges.get(j).getSource())&&edges.get(i).getTarget().equals(edges.get(j).getTarget()))
    				:"duplicate edges";
    			}
    			assert edges.get(i)!=null;
    		}
    		for(L s:vertices) {
    			assert s!=null;
    		}
    }
    	
    	public List<Edge<L>> getEdges(){
    		return edges;
    	}
    	
    	

    
    
    public void setByName(String source, String target, double weight) {
    	L sourceL = null, targetL = null;
    	for(L vertix : vertices) {
    		if(vertix.getName().equals(source)) {
    			sourceL = vertix;
    			break;
    		}
    	}
    	for(L vertix : vertices) {
    		if(vertix.getName().equals(target)) {
    			targetL = vertix;
    			break;
    		}
    	}
    	if(sourceL != null && targetL != null) {
    		set(sourceL, targetL, weight);
    		set(targetL, sourceL, weight);
    	}
    }
    	
    @Override public boolean add(L vertex) {
        if(!vertices.contains(vertex)) {
        	vertices.add(vertex);
        	checkRep();
        	return true;
        } else {
        	return false;
        }
        
    }
    
    @Override public double set(L source, L target, double weight) {
    	if(weight < 0) {
    		throw new NumberFormatException("Weight cannot be negetive");
    	} else if(weight > 0) {
        	if(vertices.contains(source) && vertices.contains(target)) {
        		for(Edge<L> edge : edges) {
        			if(edge.getSource().equals(source) && edge.getTarget().equals(target)) {
        				double preWeight = edge.getWeight();
        				edge.setWeight(weight);
        				checkRep();
        				return preWeight;
        			}
        		}
        	}
    		add(source);
    		add(target);
    		edges.add(new Edge<L>(source, target, weight));
    		checkRep();
    		return 0;
        } else {
        	Edge<L> removeEdge = null;
        	for(Edge<L> edge : edges) {
        		if(edge.getSource().equals(source) && edge.getTarget().equals(target)) {
        			removeEdge = edge;
        			break;
        		}
        	}
        	if(removeEdge != null) {
        		double preWeight = removeEdge.getWeight();
        		edges.remove(removeEdge);
        		checkRep();
        		return preWeight;
        	} else {
        		checkRep();
        		return 0;
        	}
        }
    }
    
    @Override public boolean remove(L vertex) {
        if(vertices.contains(vertex)) {
        	Set<Edge<L>> removeEdges = new HashSet<>();
        	for(Edge<L> edge : edges) {
        		if(edge.getSource().equals(vertex) || edge.getTarget().equals(vertex)) {
        			removeEdges.add(edge);
        		}
        	}
        	edges.removeAll(removeEdges);
        	vertices.remove(vertex);
        	checkRep();
        	return true;
        } else {
        	checkRep();
        	return false;
        }
    }
    
    @Override public Set<L> vertices() {
        Set<L> returnSet = new HashSet<>();
        for(L vertex : vertices) {
        	returnSet.add(vertex);
        }
        checkRep();
        return returnSet;
    }
    
    @Override public Map<L, Double> sources(L target) {
        Map<L, Double> returnMap = new HashMap<>();
        for(Edge<L> edge : edges) {
        	if(edge.getTarget().equals(target)) {
        		returnMap.put(edge.getSource(), edge.getWeight());
        	}
        }
        checkRep();
        return returnMap;
    }
    
    @Override public Map<L, Double> targets(L source) {
    	Map<L, Double> returnMap = new HashMap<>();
        for(Edge<L> edge : edges) {
        	if(edge.getSource().equals(source)) {
        		returnMap.put(edge.getTarget(), edge.getWeight());
        	}
        }
        checkRep();
        return returnMap;
    }
    
    public void print() {
    	for(L vertix : vertices()) {
    		System.out.println(vertix.toString());
    	}
    	System.out.println();
    	for(Edge<L> edge : edges) {
    		System.out.println(edge.toString());
    	}
    }

    
}

