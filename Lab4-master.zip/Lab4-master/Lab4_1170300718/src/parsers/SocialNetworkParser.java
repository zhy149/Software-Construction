package parsers;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import applications.SocialNetworkCircle;
import centralObject.Person;
import exception.DuplicateCentralObjectException;
import exception.DuplicateNameException;
import exception.NoCentralObjectExcetion;

public class SocialNetworkParser extends Parser {
	private static String userRegex = "CentralUser\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([1-9][0-9]*)\\s*,\\s*(M|F)\\s*>";
	private static String friendRegex = "Friend\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([1-9][0-9]*)\\s*,\\s*(M|F)\\s*>";
	private static String socialTieRegex = "SocialTie\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([a-zA-Z0-9]+)\\s*,\\s*(1|0(\\.[0-9]{1,3})?)\\s*>";

	public static SocialNetworkCircle<Person, Person> parse(String filePath) throws Exception {
		SocialNetworkCircle<Person, Person> socialNetworkCircle = new SocialNetworkCircle<Person, Person>();
		String contentString = getContent(filePath);
		Pattern userPattern = Pattern.compile(userRegex);
		Matcher userMatcher = userPattern.matcher(contentString);
		Logger logger = Logger.getLogger(SocialNetworkParser.class);
		
		if(userMatcher.find()) {
				socialNetworkCircle.addCenObject(new Person(userMatcher.group(1), Integer.parseInt(userMatcher.group(2)), (userMatcher.group(3).equals("M") ? true : false)));
				if(userMatcher.find()) {
					logger.error("More than one user found.");
					throw new DuplicateCentralObjectException("More than one user found.");
				}
		} else {
			logger.error("No user found!");
			throw new NoCentralObjectExcetion("No user found!");
		}
		
		Pattern friendPattern = Pattern.compile(friendRegex);
		Matcher friendMatcher = friendPattern.matcher(contentString);
		while(friendMatcher.find()) {
			if(socialNetworkCircle.getSurNameSet().contains(friendMatcher.group(1))) {
				logger.error("the friend named " + friendMatcher.group(1) + " already exists!");
				throw new DuplicateNameException("the friend named " + friendMatcher.group(1) + " already exists!");
			}
			socialNetworkCircle.addSurObject(new Person(friendMatcher.group(1), Integer.parseInt(friendMatcher.group(2)), (friendMatcher.group(3).equals("M") ? true : false)));
		}
		
		Pattern socialTiePattern = Pattern.compile(socialTieRegex);
		Matcher socialTieMatcher = socialTiePattern.matcher(contentString);
		while(socialTieMatcher.find()) {
				socialNetworkCircle.setRelation(socialTieMatcher.group(1), socialTieMatcher.group(2), Double.parseDouble(socialTieMatcher.group(3)));
		}
		return socialNetworkCircle;
	}
	
	
	
	public static void main(String[] args){
//		SocialNetworkCircle<Person, Person> socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
////		socialNetworkCircle.print();
//		
//		socialNetworkCircle.refresh(0);
////		socialNetworkCircle.print();
	}

}
