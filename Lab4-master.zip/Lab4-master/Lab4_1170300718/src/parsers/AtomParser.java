package parsers;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import applications.AtomStructure;
import centralObject.Nucleus;
import exception.DataNotMatchException;
import exception.DuplicateElementException;
import exception.NoElementException;
import physicalObject.Electron;
import track.Track;

public class AtomParser extends Parser {
	private static String elementRegex = "ElementName\\s*::=\\s*([A-Z][a-z]?)";
	private static String trackNumberRegex = "NumberOfTracks\\s*::=\\s*([1-9][0-9]*)";
	private static String electronNumberRegex = "NumberOfElectron\\s*::=\\s*([1-9][0-9]*/[1-9][0-9]*(;[1-9][0-9]*/[1-9][0-9]*)*)";

	public static AtomStructure<Nucleus, Electron> parse(String filePath) throws Exception {
		AtomStructure<Nucleus, Electron> atomStructure = new AtomStructure<Nucleus, Electron>();
		String contentString = getContent(filePath);
		
		Pattern elemenPattern = Pattern.compile(elementRegex);
		Matcher elementMatcher = elemenPattern.matcher(contentString);
		if(elementMatcher.find()) {
			atomStructure.addCenObject(new Nucleus(elementMatcher.group(1)));
			if(elementMatcher.find()) {
				throw new DuplicateElementException("More than one element name exists");
			}
		} else {
			throw new NoElementException("No element name found");
		}
		
		int trackNumber = 0;;
		Pattern trackPattern = Pattern.compile(trackNumberRegex);
		Matcher trackMatcher = trackPattern.matcher(contentString);
		if(trackMatcher.find()) {
				if(Integer.parseInt(trackMatcher.group(1)) < 0) {
					throw new NumberFormatException("Number of tracks must >= 0");
				}
				trackNumber = Integer.parseInt((trackMatcher.group(1)));
				for(int i = 0; i < trackNumber; i++) {
					atomStructure.addOrbit(new Track(i + 1));
				}
			if(trackMatcher.find()) {
				throw new DuplicateElementException("more than one track number exists");
			}
		} else {
			throw new NoElementException("no track number found");
		}
		
		Pattern electronPattern = Pattern.compile(electronNumberRegex);
		Matcher elecrtonMatcher = electronPattern.matcher(contentString);
		if(elecrtonMatcher.find()) {
				String[] electronNumberString = elecrtonMatcher.group(1).split(";");
				if(electronNumberString.length != trackNumber) {
					throw new DataNotMatchException("the number of track doesn't match");
				}
				for(String s : electronNumberString) {
					double radius = Integer.parseInt(s.split("/")[0]);
					int electronNumber = Integer.parseInt(s.split("/")[1]);
					for(int i = 0; i < electronNumber; i++) {
						atomStructure.addSurObject(new Electron(radius));
					}
				}
			if(elecrtonMatcher.find()) {
				throw new DuplicateElementException("more than one electron number exists");
			}
		} else {
			throw new NoElementException("no electron number found");
		}
		
		
		return atomStructure;
		
	}

	public static void main(String[] args)  {
		
	}

}
