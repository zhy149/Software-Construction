package parsers;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;


import applications.StellarSystem;
import centralObject.Stellar;
import exception.DuplicateCentralObjectException;
import exception.DuplicateNameException;
import exception.NoCentralObjectExcetion;
import physicalObject.Planet;


public class StellarParser extends Parser{
	private static String stellarRegex = "Stellar\\s+::=\\s+<([a-zA-Z0-9]+),(.*?),(.*?)>";
	private static String planetRegex = "Planet\\s+::=\\s+<([a-zA-Z0-9]+),([a-zA-Z0-9]+),([a-zA-Z0-9]+),(.*?),(.*?),(.*?),(CC?W),(\\d+(\\.\\d+)?)>";
	Logger logger = Logger.getLogger(StellarParser.class);
	
	public static StellarSystem<Stellar, Planet> parse(String filePath) throws Exception{
		StellarSystem<Stellar, Planet> stellarSystem = new StellarSystem<Stellar, Planet>();
		String contentString = getContent(filePath);
		
		
		Pattern planetPattern = Pattern.compile(planetRegex);
		Matcher planetMatcher = planetPattern.matcher(contentString);
		while(planetMatcher.find()) {
			if(isNumber(planetMatcher.group(4)) && isNumber(planetMatcher.group(5)) && isNumber(planetMatcher.group(6))) {
				if(stellarSystem.getSurNameSet().contains(planetMatcher.group(1))) {
			
					throw new DuplicateNameException("the planet named " + planetMatcher.group(1) + " already exists!");
				}
				stellarSystem.addSurObject(new Planet(planetMatcher.group(1), planetMatcher.group(2), planetMatcher.group(3), Double.parseDouble(planetMatcher.group(4)), Double.parseDouble(planetMatcher.group(5)), Double.parseDouble(planetMatcher.group(6)), planetMatcher.group(7).equals("CW") ? true : false, Double.parseDouble(planetMatcher.group(8))));
			}
		}
		
		Pattern stellarPattern = Pattern.compile(stellarRegex);
		Matcher stellarMatcher = stellarPattern.matcher(contentString);
		if(stellarMatcher.find()) {
			if(isNumber(stellarMatcher.group(2)) && isNumber(stellarMatcher.group(3))) {
				stellarSystem.addCenObject(new Stellar(stellarMatcher.group(1), Double.parseDouble(stellarMatcher.group(2)), Double.parseDouble(stellarMatcher.group(3))));
			}
			if(stellarMatcher.find()) {
				throw new DuplicateCentralObjectException("More than one Stellar exists");
			}
		} else {
			throw new NoCentralObjectExcetion("No stellar found!");
		}
		
		return stellarSystem;
	}
	
	
	public static void main(String[] args) throws IOException {
//		StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt");
		
		
	}

}
