package centralObject;

public interface CentralObject {
}
 