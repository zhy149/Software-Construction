package centralObject;

import physicalObject.PhysicalObject;

public class Person implements PhysicalObject, CentralObject{
	String name;
	int age;
	boolean gender;
	double orbitRadius;
	double curAngle;
	
	
	
	public Person(String name, int age, boolean gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}

	@Override
	public void setCurAngle(double curAngel) {
		this.curAngle = curAngel;

	}

	@Override
	public double getCurAngle() {
		return curAngle;
	}

	@Override
	public void setNextAngle(double milisecond) {
		
	}

	@Override
	public double getNextAngle(double milisecond) {
		return 0;
	}

	@Override
	public double getOrbitRadius() {
		return this.orbitRadius;
	}
	
	@Override
	public void setOrbitRadius(double orbitRadius) {
		this.orbitRadius = orbitRadius;
		
	}
	
	public String getName() {
		return this.name;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}else {
			if(this.getName().equals(((Person)obj).getName())){
				return true;
			} else {
				return false;
			}
		}
	}
	
	
	
	

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	@Override
	public String toString() {
		return this.name + this.orbitRadius;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	@Override
	public double getRadius() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setRadius(double radius) {
		// TODO Auto-generated method stub
		
	}


	

}
