package exception;

public class NoElementException extends Exception {
	public NoElementException(String msg) {
		super(msg);
	}
}
