package general;

public final class Nucleus implements L{
	public String name;
	
	public Nucleus(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return name;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
