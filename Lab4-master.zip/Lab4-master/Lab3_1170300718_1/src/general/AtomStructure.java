package general;

import java.util.ArrayList;
import java.util.TreeMap;

public class AtomStructure<L, E extends PhysicalObject> extends ConcreteCircularOrbit<L, E> {
	
	
	
	@SuppressWarnings("unchecked")
	public void transit(int sourceRadius, int targetRadius) {
		if(sourceRadius > 0 && targetRadius > 0 && sourceRadius <= orbitMap.size() && targetRadius <= orbitMap.size() && sourceRadius != targetRadius) {
			Track sourcTrack = null;
			Track tarTrack = null;
			int i = 0;
			for(Track track : orbitMap.keySet()) {
				i++;
				if(i == sourceRadius) {
					sourcTrack = track;
				}
				if(i == targetRadius) {
					tarTrack = track;
				}
			}
			if(sourcTrack!=null && tarTrack!=null && sourcTrack!=tarTrack) {
				if(!orbitMap.get(sourcTrack).isEmpty()) {
					orbitMap.get(sourcTrack).remove(0);
					orbitMap.get(tarTrack).add((E)(new Electron(tarTrack.getRadius())));
				}
			}
		}
	}

	
	
	@Override
	public void refresh(double milisecond) {
		resetAngle();
	}
	
	

	@Override
	public void print() {
		if(centralObject != null) {
			System.out.println(centralObject.toString());
			System.out.println();
		}
		
		int count = 0;
		for(Track track : orbitMap.keySet()) {
			System.out.println(++count + " " + track.toString() + " has " + orbitMap.get(track).size() + " electron.");
			System.out.println();
		}
	}



	public static void main(String[] args) {

	}

}
