package general;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeMap;

import javax.swing.*;


public class StellarSystemPanel extends JPanel{
	private StellarSystem<Stellar, Planet> stellarSystem;
	private int orbitDistance = 10;
	
	public void setOrbitDistance(int distance) {
		this.orbitDistance = distance;
	}

	
	public StellarSystemPanel(StellarSystem<Stellar, Planet> stellarSystem) {
		this.stellarSystem = stellarSystem;
	}
	
	public void refresh(double milisecond) {
		stellarSystem.refresh(milisecond);
	}
	
	
	
	private void paintOrbit(int orbitNumber, Graphics g) {
		g.setColor(Color.black);
		for (int i = 0; i < orbitNumber; i++) {
			g.drawOval(i * orbitDistance, i * orbitDistance, 2 *orbitDistance * (orbitNumber - i), 2 * orbitDistance * (orbitNumber - i));
		}
	}
	
	private void paintStellar(int orbitNumber, Graphics g) {
		g.setColor(Color.red);
		g.fillOval(orbitNumber * orbitDistance - (int)(orbitDistance / 2), orbitNumber * orbitDistance - (int)(orbitDistance / 2), orbitDistance, orbitDistance);
	}
	
	private void paintPlanet(int orbitNumer, int orbitIndex, double angle , Graphics g) {
		int X = orbitNumer * orbitDistance + (int)(orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 4);
		int Y = orbitNumer * orbitDistance + (int)(- orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI) - orbitDistance / 4);
		int planetDiameter = (int)(orbitDistance / 2);
		g.setColor(Color.blue);
		g.fillOval(X, Y, planetDiameter, planetDiameter);
	}
	
	private void paintSystem(StellarSystem<Stellar, Planet> stellarSystem, Graphics g) {
		int orbitNumber = stellarSystem.getOrbitNumber();
		TreeMap<Track, ArrayList<Planet>> treeMap = stellarSystem.getOrbitMap();
		
		paintStellar(orbitNumber, g);
		paintOrbit(orbitNumber, g);
		int i = 0;
		for(Track track : treeMap.keySet()) {
			++i;
			for(Planet planet : treeMap.get(track)) {
				paintPlanet(orbitNumber, i, planet.getCurAngle(), g);
			}
		}
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		paintSystem(stellarSystem, g);
		
//		paintOrbit(10, g);
//		paintStellar(10, g);
//		paintPlanet(10, 4, angle, g);
//		g.drawOval(0, 0, 1000, 1000);
//		g.drawOval(100, 100, 800, 800);
//		g.drawOval(200, 200, 600, 600);
//		g.drawOval(300, 300, 400, 400);
//		g.drawOval(400, 400, 200, 200);
//		g.fillOval(475, 475, 50, 50);
	}

	public static void main(String[] args) throws IOException {
		JFrame myFrame = new JFrame();
		StellarSystemPanel stellarSystemPanel = new StellarSystemPanel(StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt"));
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		stellarSystemPanel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(stellarSystemPanel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);

		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
					stellarSystemPanel.refresh(1);
					stellarSystemPanel.repaint();
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}
		).run();
	}

}
