package general;
import java.awt.Dimension;
import java.io.IOException;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JScrollPane;







public class Main {
	private void print(String content) {
		System.out.println(content);
	}

	
	public void StellarVisualize(StellarSystem<Stellar, Planet> stellarSystem) {
		StellarSystemPanel stellarSystemPanel = new StellarSystemPanel(stellarSystem);
		JFrame myFrame = new JFrame();
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		stellarSystemPanel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(stellarSystemPanel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);

		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
					stellarSystemPanel.refresh(1);
					stellarSystemPanel.repaint();
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}
		).run();
	}
	
	public void StellarSystemMenu() throws IOException {
		StellarSystem<Stellar, Planet> stellarSystem;
		
		Scanner inputScnScanner = new Scanner(System.in);
		print("Choose one to generate: 1,Normal 2,Medium 3,Large");
		switch (inputScnScanner.nextLine()) {
		case "1":
			stellarSystem = StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt");
			break;
		case "2":
			stellarSystem = StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem_Medium.txt");
			break;
		case "3":
			stellarSystem = StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem_Larger.txt");
			break;
		default:
			stellarSystem = StellarParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\StellarSystem.txt");
			break;
		}
		
		while(true) {
		print("choose function to perform: 1,add oribt 2,add subject 3,delete subject 4,delete orbit 5,calculate entropy 6,print information 7,get change by time 8,visualize ");
		switch (inputScnScanner.nextLine()) {
		case "1":
			print("input the radius of track");
			double radius = Double.parseDouble(inputScnScanner.nextLine());
			if(radius > 0) {
				stellarSystem.addOrbit(new Track(radius));
				print("Track with " + radius + " successfully added.");
			}
			break;
		case "2":
			String name;
			print("input the name of the planet");
			name = inputScnScanner.nextLine();
			print("input the radius of the planet");
			radius = Double.parseDouble(inputScnScanner.nextLine());
			stellarSystem.addSurObject(new Planet(name, "solic", "blue", 1, radius, 100, true, 0));
			print("Planet with " + radius + " successfully added.");
			break;
		case "3":
			print("input the name of planet to delete");
			name = inputScnScanner.nextLine();
			stellarSystem.deleteSurObjectByName(name);
			break;
		case "4":
			print("input the radius of track you want to delete");
			radius = Double.parseDouble(inputScnScanner.nextLine());
			stellarSystem.deleteOrbitByRadius(radius);
			break;
		case "5":
			print("the entropy is " + CircularOrbitAPIs.getDistributionEntropy(stellarSystem));
			break;
		case "6":
			stellarSystem.print();
			break;
		case "7":
			print("input the time offset.");
			double milisecond = Double.parseDouble(inputScnScanner.nextLine());
			if (milisecond > 0) {
				stellarSystem.refresh(milisecond);
			}
			break;
		case "8":
			StellarVisualize(stellarSystem);
			break;
		default:
			break;
		}
		print("");
		}
	}
	
	public void AtomVisualize(AtomStructure<Nucleus, Electron> atomStructure) {
		AtomPanel atomPanel = new AtomPanel(atomStructure);
		JFrame myFrame = new JFrame();
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		atomPanel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(atomPanel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);

		atomPanel.refresh(0);
		atomPanel.repaint();
	}
	
	public void AtomMenu() throws IOException {
		AtomStructure<Nucleus, Electron> atomStructure;
		
		Scanner inputScnScanner = new Scanner(System.in);
		print("Choose one to generate: 1,Normal 2,Medium");
		switch (inputScnScanner.nextLine()) {
		case "1":
			atomStructure = AtomParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure.txt");
			break;
		case "2":
			atomStructure = AtomParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure_Medium.txt");
			break;
		default:
			atomStructure = AtomParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure.txt");
			break;
		}
		
		while(true) {
		print("choose function to perform: 1,transic electron 2,print information 3,visualize ");
		switch (inputScnScanner.nextLine()) {
		case "1":
			print("input the radius of sorce electron track");
			int sourceRadius = Integer.parseInt(inputScnScanner.nextLine());
			print("input the radius of target electron track");
			int targetRadius = Integer.parseInt(inputScnScanner.nextLine());
			atomStructure.transit(sourceRadius, targetRadius);
			break;
		case "2":
			atomStructure.print();
			break;
		case "3":
			AtomVisualize(atomStructure);
			break;
		default:
			break;
		}
		print("");
		}
	}
	
	public void SocialNetworkVisualize(SocialNetworkCircle<Person, Person> networkCircle) {
		JFrame myFrame = new JFrame();
		SocialNetworkPanel myPenel = new SocialNetworkPanel(networkCircle);
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		myPenel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(myPenel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);
		myPenel.refresh(0);
		myPenel.repaint();
	}
	
	
	public void SocialNetworkMenu() throws IOException {
		SocialNetworkCircle<Person, Person> socialNetworkCircle;
		
		Scanner inputScnScanner = new Scanner(System.in);
		print("Choose one to generate: 1,Normal 2,Medium 3,Large");
		switch (inputScnScanner.nextLine()) {
		case "1":
			socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
			break;
		case "2":
			socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle_Medium.txt");
			break;
		case "3":
			socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle_Larger.txt");
			break;
		default:
			socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
			break;
		}
		
		while(true) {
		//print("choose function to perform: 1,add person 2,delete person 3,set relation 4,delete relation 5,calculate entropy 6,print information 7,refresh orbitSystem 8,visualize ");
		print("choose function to perform: 1,add person 2,delete person 5,calculate entropy 6,print information 7,refresh orbitSystem 8,visualize ");
		switch (inputScnScanner.nextLine()) {
		case "1":
			print("input the name of person");
			String name = inputScnScanner.nextLine();
			socialNetworkCircle.addPerson(name);
			break;
		case "2":
			print("input the name of person");
			name = inputScnScanner.nextLine();
			socialNetworkCircle.deletePerson(name);
			break;
		case "3":
			print("input the name and weight of relation to set");
			String sourceName = inputScnScanner.nextLine();
			String targetName = inputScnScanner.nextLine();
			double weight = Double.parseDouble(inputScnScanner.nextLine());
			socialNetworkCircle.setRelationship(sourceName, targetName, weight);
			break;
		case "4":
			print("input the name of relation to delete");
			sourceName = inputScnScanner.nextLine();
			targetName = inputScnScanner.nextLine();
			socialNetworkCircle.deleteRelationship(sourceName, targetName);
			break;
		case "5":
			print("the entropy is " + CircularOrbitAPIs.getDistributionEntropy(socialNetworkCircle));
			break;
		case "6":
			socialNetworkCircle.print();
			break;
		case "7":
			socialNetworkCircle.refresh(0);
			break;
		case "8":
			SocialNetworkVisualize(socialNetworkCircle);
			break;
		default:
			break;
		}
		print("");
		}
	}
	
	

	public static void main(String[] args) throws Exception{
		Main menu = new Main();
		Scanner inputScanner = new Scanner(System.in);
		System.out.println("Choose one game to play:\n1, StellarSystem 2, AtomStructure 3, SocialNetworkCircle");
		switch (inputScanner.nextLine()) {
		case "1":
			menu.StellarSystemMenu();
		break;
			
		case "2":
			menu.AtomMenu();
		break;

		case "3":
			menu.SocialNetworkMenu();
		break;
		default:
			break;
		}
		
		
		// TODO Auto-generated method stub

	}

}
