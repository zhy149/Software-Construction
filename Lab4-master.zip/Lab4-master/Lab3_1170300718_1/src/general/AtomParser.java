package general;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AtomParser extends Parser {
	private static String elementRegex = "ElementName\\s*::=\\s*([A-Z][a-z]?)";
	private static String trackNumberRegex = "NumberOfTracks\\s*::=\\s*([1-9][0-9]*)";
	private static String electronNumberRegex = "NumberOfElectron\\s*::=\\s*([1-9][0-9]*/[1-9][0-9]*(;[1-9][0-9]*/[1-9][0-9]*)*)";

	public static AtomStructure<Nucleus, Electron> parse(String filePath) throws IOException {
		AtomStructure<Nucleus, Electron> atomStructure = new AtomStructure<Nucleus, Electron>();
		String contentString = getContent(filePath);
		Pattern elemenPattern = Pattern.compile(elementRegex);
		Matcher elementMatcher = elemenPattern.matcher(contentString);
		while(elementMatcher.find()) {
				atomStructure.addCenObject(new Nucleus(elementMatcher.group(1)));
		}
		Pattern trackPattern = Pattern.compile(trackNumberRegex);
		Matcher trackMatcher = trackPattern.matcher(contentString);
		if(trackMatcher.find()) {
				for(int i = 0; i < Integer.parseInt(trackMatcher.group(1)); i++) {
					atomStructure.addOrbit(new Track(i + 1));
				}
		}
		
		Pattern electronPattern = Pattern.compile(electronNumberRegex);
		Matcher elecrtonMatcher = electronPattern.matcher(contentString);
		if(elecrtonMatcher.find()) {
				String[] electronNumberString = elecrtonMatcher.group(1).split(";");
				for(String s : electronNumberString) {
					double radius = Integer.parseInt(s.split("/")[0]);
					int electronNumber = Integer.parseInt(s.split("/")[1]);
					for(int i = 0; i < electronNumber; i++) {
						atomStructure.addSurObject(new Electron(radius));
					}
				}
		}
		
		
		return atomStructure;
		
	}

	public static void main(String[] args) throws IOException {
		AtomStructure<Nucleus, Electron> atomStructure = AtomParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure.txt");
		atomStructure.refresh(0);
		atomStructure.print();
	}

}
