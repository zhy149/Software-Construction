package general;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SocialNetworkParser extends Parser {
	private static String userRegex = "CentralUser\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([1-9][0-9]*)\\s*,\\s*(M|F)\\s*>";
	private static String friendRegex = "Friend\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([1-9][0-9]*)\\s*,\\s*(M|F)\\s*>";
	private static String socialTieRegex = "SocialTie\\s*::=\\s*<\\s*([a-zA-Z0-9]+)\\s*,\\s*([a-zA-Z0-9]+)\\s*,\\s*(1|0(\\.[0-9]{1,3})?)\\s*>";

	public static SocialNetworkCircle<Person, Person> parse(String filePath) throws IOException {
		SocialNetworkCircle<Person, Person> socialNetworkCircle = new SocialNetworkCircle<Person, Person>();
		String contentString = getContent(filePath);
		Pattern userPattern = Pattern.compile(userRegex);
		Matcher userMatcher = userPattern.matcher(contentString);
		
		if(userMatcher.find()) {
				socialNetworkCircle.addCenObject(new Person(userMatcher.group(1), Integer.parseInt(userMatcher.group(2)), (userMatcher.group(3).equals("M") ? true : false)));
		} else {
			throw new IOException("No user fined!");
		}
		
		Pattern friendPattern = Pattern.compile(friendRegex);
		Matcher friendMatcher = friendPattern.matcher(contentString);
		while(friendMatcher.find()) {
				socialNetworkCircle.addSurObject(new Person(friendMatcher.group(1), Integer.parseInt(friendMatcher.group(2)), (friendMatcher.group(3).equals("M") ? true : false)));
		}
		
		Pattern socialTiePattern = Pattern.compile(socialTieRegex);
		Matcher socialTieMatcher = socialTiePattern.matcher(contentString);
		while(socialTieMatcher.find()) {
				socialNetworkCircle.setRelation(socialTieMatcher.group(1), socialTieMatcher.group(2), Double.parseDouble(socialTieMatcher.group(3)));
		}
		
		return socialNetworkCircle;
	}
	
	
	
	public static void main(String[] args) throws IOException {
		SocialNetworkCircle<Person, Person> socialNetworkCircle = SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle.txt");
//		socialNetworkCircle.print();
		
		socialNetworkCircle.refresh(0);
//		socialNetworkCircle.print();
	}

}
