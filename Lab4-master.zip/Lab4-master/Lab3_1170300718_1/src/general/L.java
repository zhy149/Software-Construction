package general;

public interface L {
	
}
