package general;

import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.TreeMap;
import java.util.concurrent.LinkedBlockingQueue;






public class SocialNetworkCircle<L extends PhysicalObject, E extends PhysicalObject> extends ConcreteCircularOrbit<L, E> {
	ConcreteEdgesGraph<PhysicalObject> graph = new ConcreteEdgesGraph<PhysicalObject>(); 
	
    @Override
	public void refresh(double milisecond) {
    	generateOrbitSystem();
    	resetAngle();
    }
    
    public boolean containPerson(PhysicalObject person) {
    	if(person.equals((Person)centralObject)) {
    		return true;
    	}
    	for(Track track : orbitMap.keySet()) {
    		if(orbitMap.get(track).contains(person)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    public void addPerson(String name) {
    	graph.vertices().add(new Person(name, 10, true));
    	System.out.println("add Person");
    }
    
    public void deletePerson(String name) {
    	PhysicalObject tempPerson = null;
    	for(PhysicalObject person : graph.vertices()) {
    		if(person.getName().equals(name)) {
    			tempPerson = person;
    		}
    	}
    	if(tempPerson != null) {
    		graph.remove(tempPerson);
    	}
    }
    
    public void deleteRelationship(String sourceName, String targetName) {
    	Set<Edge<PhysicalObject>> set = new HashSet<Edge<PhysicalObject>>();
    	for(Edge<PhysicalObject> edge : graph.getEdges()) {
    		if(edge.getSource().getName().equals(sourceName) && edge.getTarget().getName().equals(targetName)) {
    			set.add(edge);
    		} else if(edge.getSource().getName().equals(targetName) && edge.getTarget().getName().equals(sourceName)) {
    			set.add(edge);
    		}
    	}
    	graph.getEdges().removeAll(set);
    }
    
    
    public PhysicalObject getPerson(String name) {
    	PhysicalObject tempPerson = null;
    	for(PhysicalObject person : graph.vertices()) {
    		if(person.getName().equals(name)) {
    			tempPerson = person;
    		}
    	}
    	return tempPerson;
    }
    
    
    public void setRelationship(String sourceName, String targetName, double weight) {
    	if(weight > 0) {
    		PhysicalObject sourcePerson = null;
        	for(PhysicalObject person : graph.vertices()) {
        		if(person.getName().equals(sourceName)) {
        			sourcePerson = person;
        			System.out.println("1");
        		}
        	}
        	
        	PhysicalObject targetPerson = null;
        	for(PhysicalObject person : graph.vertices()) {
        		if(person.getName().equals(targetName)) {
        			sourcePerson = person;
        		}
        	}
        	if(sourcePerson!=null && targetPerson!=null)
        	graph.set(sourcePerson, targetPerson, weight);
        	graph.set(targetPerson, sourcePerson, weight);
    	}
    }
    

	@SuppressWarnings("unchecked")
	public void generateOrbitSystem() {
		orbitMap = new TreeMap<Track, ArrayList<E>>();
    	if(centralObject != null && graph.vertices().contains(centralObject)) {
    		Queue<PhysicalObject> queue = new LinkedBlockingQueue<PhysicalObject>();
    		HashSet<PhysicalObject> set = new HashSet<PhysicalObject>();
    		centralObject.setRadius(0);
    		queue.add(centralObject);
    		set.add(centralObject);
    		while(!queue.isEmpty()) {
    			PhysicalObject sourceObject = queue.poll();
    			for(PhysicalObject targetObject: graph.targets(sourceObject).keySet()) {
    				if(!set.contains(targetObject)) {
    					targetObject.setRadius(sourceObject.getOrbitRadius() + 1);
    					set.add(targetObject);
    					queue.add(targetObject);
    				}
    			}
    		}
    		set.remove(centralObject);
    		for(PhysicalObject friend : set) {
//    			System.out.println(friend.toString() + " " + friend.getOrbitRadius());
    			super.addSurObject((E)friend);
//    			System.out.println(friend.toString());
//    			System.out.println(orbitMap.size());
    		}
    	}
    }
	
	public boolean hasVertix(String name) {
		for(PhysicalObject vertix : graph.vertices()) {
			if(vertix.getName().equals(name)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void addCenObject(L vertex) {
		super.addCenObject(vertex);
		graph.add(vertex);
	}

	@Override
	public void addSurObject(E vertex) {
		graph.add(vertex);
	}
	
	public void setRelation(String source, String target, double weight) {
		graph.setByName(source, target, weight);
	}
	
	








//	public void print() {
//		System.out.println(centralObject.toString());
//		System.out.println();
//		
//		graph.print();
//	}

	

	public static void main(String[] args) {
		
	}

}
