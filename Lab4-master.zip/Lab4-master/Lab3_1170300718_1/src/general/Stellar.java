package general;

public class Stellar implements L{
	String name;
	double radius;
	double mass;
	
	
	public Stellar(String name, double radius, double mass) {
		super();
		this.name = name;
		this.radius = radius;
		this.mass = mass;
	}

	@Override
	public String toString() {
		return name + " " + radius + " " + mass;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
