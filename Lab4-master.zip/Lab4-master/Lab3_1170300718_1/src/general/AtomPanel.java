package general;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class AtomPanel extends JPanel{
	private AtomStructure<Nucleus, Electron> atomStructure;
	private static int orbitDistance = 40;
	private static double timeOffSet = 10;

	
	public AtomPanel(AtomStructure<Nucleus, Electron> atomStructure) {
		this.atomStructure = atomStructure;
	}
	
	public void refresh(double milisecond) {
		atomStructure.refresh(milisecond);
	}
	
	
	private void paintOrbit(int orbitNumber, Graphics g) {
		g.setColor(Color.black);
		for (int i = 0; i < orbitNumber; i++) {
			g.drawOval(i * orbitDistance, i * orbitDistance, 2 *orbitDistance * (orbitNumber - i), 2 * orbitDistance * (orbitNumber - i));
		}
	}
	
	private void paintStellar(int orbitNumber, Graphics g) {
		g.setColor(Color.black);
		g.fillOval(orbitNumber * orbitDistance - (int)(orbitDistance / 4), orbitNumber * orbitDistance - (int)(orbitDistance / 4), orbitDistance / 2, orbitDistance / 2);
	}
	
	private void paintPlanet(int orbitNumer, int orbitIndex, double angle , Graphics g) {
		int X = orbitNumer * orbitDistance + (int)(orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 8);
		int Y = orbitNumer * orbitDistance + (int)(- orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI) - orbitDistance / 8);
		int planetDiameter = (int)(orbitDistance / 4);
		g.setColor(Color.green);
		g.fillOval(X, Y, planetDiameter, planetDiameter);
	}
	
	private void paintSystem(AtomStructure<Nucleus, Electron> atomStructure, Graphics g) {
		int orbitNumber = atomStructure.getOrbitNumber();
		TreeMap<Track, ArrayList<Electron>> treeMap = atomStructure.getOrbitMap();
		
		paintStellar(orbitNumber, g);
		paintOrbit(orbitNumber, g);
		int i = 0;
		for(Track track : treeMap.keySet()) {
			++i;
			for(Electron electron : treeMap.get(track)) {
				paintPlanet(orbitNumber, i, electron.getCurAngle(), g);
			}
		}
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		g.setColor(Color.gray);
		paintSystem(atomStructure, g);
		
//		paintOrbit(10, g);
//		paintStellar(10, g);
//		paintPlanet(10, 4, angle, g);
//		g.drawOval(0, 0, 1000, 1000);
//		g.drawOval(100, 100, 800, 800);
//		g.drawOval(200, 200, 600, 600);
//		g.drawOval(300, 300, 400, 400);
//		g.drawOval(400, 400, 200, 200);
//		g.fillOval(475, 475, 50, 50);
	}

	public static void main(String[] args) throws IOException {
		JFrame myFrame = new JFrame();
		AtomPanel myPenel = new AtomPanel(AtomParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\AtomicStructure_Medium.txt"));
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		myPenel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(myPenel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);
//		for (int i = 0; i < 100; i++) {
//			myPenel.angle += 1;
//			myPenel.repaint();
//		}
		
		new Thread(new Runnable() {
			
			
			@Override
			public void run() {
				while(true) {
					myPenel.refresh(timeOffSet);
					myPenel.repaint();
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}
		).run();
	}


}
