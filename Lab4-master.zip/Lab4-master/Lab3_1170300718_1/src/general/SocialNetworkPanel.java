package general;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class SocialNetworkPanel extends JPanel {
	
	private SocialNetworkCircle<Person, Person> networkCircle;
	private int orbitDistance = 100;
	

	
	public SocialNetworkPanel(SocialNetworkCircle<Person, Person> networkCircle) {
		this.networkCircle = networkCircle;
	}
	
	public void refresh(double milisecond) {
		networkCircle.refresh(milisecond);
	}
	
	
	private void paintOrbit(int orbitNumber, Graphics g) {
		g.setColor(Color.black);
		for (int i = 0; i < orbitNumber; i++) {
			g.drawOval(i * orbitDistance, i * orbitDistance, 2 *orbitDistance * (orbitNumber - i), 2 * orbitDistance * (orbitNumber - i));
		}
	}
	
	private int getXPosition(int orbitNumber, Person person) {
		if(person.equals(networkCircle.centralObject)) {
			return orbitNumber * orbitDistance;
		}
		else return (int)(orbitNumber * orbitDistance + orbitDistance * person.getOrbitRadius() * Math.cos(person.getCurAngle() * Math.PI / 180));
	}
	
	private int getYPosition(int orbitNumber, Person person) {
		if(person.equals(networkCircle.centralObject)) {
			return orbitNumber * orbitDistance;
		} 
		else return (int)(orbitNumber * orbitDistance - orbitDistance * person.getOrbitRadius() * Math.sin(person.getCurAngle() * Math.PI / 180));
	}
	
	private void paintRelation(int orbitNumber, Graphics g) {
		g.setColor(Color.red);
		for(Edge edge : networkCircle.graph.getEdges()) {
			if(networkCircle.containPerson((Person)edge.getSource()) && networkCircle.containPerson((Person)edge.getTarget())) {
				g.drawLine(getXPosition(orbitNumber, (Person)edge.getSource()), getYPosition(orbitNumber, (Person)edge.getSource()), getXPosition(orbitNumber, (Person)edge.getTarget()), getYPosition(orbitNumber, (Person)edge.getTarget()));
			}
			
		}
	}
	
	
	private void paintStellar(int orbitNumber, Graphics g) {
		g.setColor(Color.gray);
		g.fillOval(orbitNumber * orbitDistance - (int)(orbitDistance / 4), orbitNumber * orbitDistance - (int)(orbitDistance / 4), orbitDistance / 2, orbitDistance / 2);
	}
	
	private void paintPlanet(int orbitNumer, int orbitIndex, double angle , Graphics g) {
		int X = orbitNumer * orbitDistance + (int)(orbitIndex * orbitDistance * Math.cos(angle / 180 * Math.PI) - orbitDistance / 20);
		int Y = orbitNumer * orbitDistance + (int)(- orbitIndex * orbitDistance * Math.sin(angle / 180 * Math.PI) - orbitDistance / 20);
		int planetDiameter = (int)(orbitDistance / 10);
		g.setColor(Color.blue);
		g.fillOval(X, Y, planetDiameter, planetDiameter);
	}
	
	private void paintSystem(SocialNetworkCircle<Person, Person> networkCircle, Graphics g) {
		int orbitNumber = networkCircle.getOrbitNumber();
		TreeMap<Track, ArrayList<Person>> treeMap = networkCircle.getOrbitMap();
		
		paintStellar(orbitNumber, g);
		paintOrbit(orbitNumber, g);
		int i = 0;
		for(Track track : treeMap.keySet()) {
			++i;
			for(Person person : treeMap.get(track)) {
				paintPlanet(orbitNumber, i, person.getCurAngle(), g);
			}
		}
		paintRelation(orbitNumber, g);
	}
	
	
	
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		g.setColor(Color.gray);
		paintSystem(networkCircle, g);
		
//		paintOrbit(10, g);
//		paintStellar(10, g);
//		paintPlanet(10, 4, angle, g);
//		g.drawOval(0, 0, 1000, 1000);
//		g.drawOval(100, 100, 800, 800);
//		g.drawOval(200, 200, 600, 600);
//		g.drawOval(300, 300, 400, 400);
//		g.drawOval(400, 400, 200, 200);
//		g.fillOval(475, 475, 50, 50);
	}

	public static void main(String[] args) throws IOException {
		JFrame myFrame = new JFrame();
		SocialNetworkPanel myPenel = new SocialNetworkPanel(SocialNetworkParser.parse("C:\\Users\\97504\\Documents\\Java_workplace\\Lab3_1170300211\\src\\txt\\SocialNetworkCircle_Medium.txt"));
		
		Dimension preferSizeDimension = new Dimension(100000, 100000);
		myPenel.setPreferredSize(preferSizeDimension);
		JScrollPane myPane = new JScrollPane(myPenel);
		myPane.setSize(800, 800);
		myFrame.setSize(900, 900);
		myFrame.add(myPane);
		myFrame.setVisible(true);
		
		new Thread(new Runnable() {
			@Override
			public void run() {
//				while(true) {
					myPenel.refresh(1);
					myPenel.repaint();
//					try {
//						Thread.sleep(100);
//					} catch (Exception e) {
						// TODO: handle exception
//					}
//				}
			}
		}
		).run();
	}




}
