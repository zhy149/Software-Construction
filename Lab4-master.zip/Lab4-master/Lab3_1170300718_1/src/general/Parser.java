package general;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
	
	
	protected static String getContent(String filePath) throws IOException{
		List<String> stringList = new ArrayList<String>();
		stringList = Files.readAllLines(Paths.get(filePath));
		StringBuilder stringBuilder = new StringBuilder();
		for(String s : stringList) {
			stringBuilder.append(s + "\n");
		}
		String contentString = stringBuilder.toString();
		return contentString;
	}
	
	protected static boolean isNumber(String numberString) {
		String numberRegex1 = "([1-9]\\d{0,3}|0)(\\.\\d+)?";
		String numberRegex2 = "[1-9](\\.\\d+)?e([4-9]|[1-9][0-9]+)";
		Pattern numberPattern1 = Pattern.compile(numberRegex1);
		Pattern numberPattern2 = Pattern.compile(numberRegex2);
		Matcher numberMatcher1 = numberPattern1.matcher(numberString);
		Matcher numberMatcher2 = numberPattern2.matcher(numberString);
		if(numberMatcher1.matches() | numberMatcher2.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

	}

}
