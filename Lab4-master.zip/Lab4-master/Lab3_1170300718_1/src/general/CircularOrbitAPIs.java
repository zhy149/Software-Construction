package general;


public class CircularOrbitAPIs {
	
	public static <C extends L, O extends PhysicalObject> double getDistributionEntropy(ConcreteCircularOrbit<C, O> circularOrbit) {
		double entropy = 0;
		int surObjNumber = circularOrbit.getSurObjectNumber();
		for(Track track : circularOrbit.orbitMap.keySet()) {
			double p = ((double)circularOrbit.orbitMap.get(track).size()) / surObjNumber;
			if(p - 0 < 1e-7) {
				continue;
			} else {
				entropy -= p * Math.log(p) / Math.log(2);
			}
		}
		return entropy;
	}
	
	public static <C extends L, O extends PhysicalObject> int getPhysicalDistance(ConcreteCircularOrbit<C, O> circularOrbit, PhysicalObject e1, PhysicalObject e2) {
		double x1 = e1.getOrbitRadius() * Math.cos(e1.getCurAngle() * Math.PI / 180);
		double x2 = e2.getOrbitRadius() * Math.cos(e2.getCurAngle() * Math.PI / 180);
		double y1 = e1.getOrbitRadius() * Math.sin(e1.getCurAngle() * Math.PI / 180);
		double y2 = e2.getOrbitRadius() * Math.sin(e2.getCurAngle() * Math.PI / 180);
		return (int)Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
	}
	
	public static <C extends L, O extends PhysicalObject> int getLogicalDistance(ConcreteCircularOrbit<C, O> circularOrbit, PhysicalObject e1, PhysicalObject e2) {
		
		int i = 0;
		int e1TrackNumber = 0;
		int e2TrackNumber = 0;
		for(Track track : circularOrbit.orbitMap.keySet()) {
			i++;
			if(circularOrbit.orbitMap.get(track).contains(e1)) {
				e1TrackNumber = i;
			}
			if(circularOrbit.orbitMap.get(track).contains(e1)) {
				e2TrackNumber = i;
			}
		}
		if(e1TrackNumber > 0 && e2TrackNumber > 0) {
			return Math.abs(e1TrackNumber - e2TrackNumber);
		} 
		else return -1;
	}
}

