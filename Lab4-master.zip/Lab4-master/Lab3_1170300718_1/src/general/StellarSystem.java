package general;

import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

public class StellarSystem<L, E extends PhysicalObject> extends ConcreteCircularOrbit<L, E> {
	
	
	
	public static void main(String[] args) {
	

	}

}
