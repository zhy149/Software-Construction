package general;

public interface PhysicalObject {
	public void setCurAngle(double curAngel);
	public double getCurAngle();
	public String getName();
	public void setNextAngle(double milisecond);
	public double getNextAngle(double milisecond);
	public double getOrbitRadius();
	public void setRadius(double radius);
}
