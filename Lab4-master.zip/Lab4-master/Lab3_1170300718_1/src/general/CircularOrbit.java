package general;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeMap;

public interface CircularOrbit <L, E> {
	
	public CircularOrbit<L, E> emptyCircularOrbit();
	public TreeMap<Track, ArrayList<E>> getOrbitMap();
	public void addOrbit(Track track);
	public void deleteOrbit(Track track);
	public void deleteOrbitByRadius(double radius);
	public int getOrbitNumber();
	public void addCenObject(L object);
	public void addSurObject(Track track, E object);
	public void addSurObject(E object);
	public void addCenRelation();
	public void addSurRelation();
	public void constructCirOrbit();
	public void refresh(double milisecond);
	

}
